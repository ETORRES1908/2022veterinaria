@extends('adminlte::page')

@section('title')

@section('content_header')

@stop

@section('content')
    aaaaaaaaaaa
@stop
