@extends('layouts.app')

@section('content')
{{$token}}
@endsection
