<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-xs-12 col-md-6 col-sm-6 mb-4">
        <div class="h1 mb-3 py-3">
            <?php echo e(__('Contact us')); ?>

        </div>

        <div class="h5"><?php echo e(__('Phone Number')); ?>: </div>
        <div class="h6 fw-lighter"><strong>(01)</strong> 444 4444</div>


        <div class="h5"><?php echo e(__('Mobile Phone Number')); ?>: </div>
        <div class="h6 fw-lighter">999-999-999 / 999-999-999</div>

        <div class="h5"><?php echo e(__('E-Mail Address')); ?>: </div>
        <a class="h6 fw-lighter" href="#">Example@gmail.com</a>

        <div class="h5 fw-lighter text-start">
            <?php echo e(__('If additional questions arise, our entire staff will be extremely happy to answer you!')); ?>

        </div>
    </div>
    <div class="col-xs-12 col-md-6 col-sm-6 py-auto">
        <img src="<?php echo e(url('storage/img/dogcorrea.jpg')); ?>" class="img-fluid" alt="...">
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>