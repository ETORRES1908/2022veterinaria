<?php $__env->startSection('head'); ?>
    <!-- Styles -->
    <link rel="stylesheet" href="<?php echo e(asset('css/lightbox/icons/css/animation.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/lightbox/icons/css/mhfontello.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/lightbox/icons/css/mhfontello-embedded.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/lightbox/icons/css/mhfontello-codes.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/lightbox/icons/css/mhfontello-ie7-codes.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/lightbox/icons/css/mhfontello-ie7.css')); ?>">
    
    <style type="text/css">
        #html5lightbox-watermark {
            display: none !important;
        }

        .lightboxcontainer {
            width: 100%;
            height: 100%;
            text-align: left;
        }

    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="card bg-black">
        <?php if(session('mensaje')): ?>
            <div class="alert alert-success">
                <?php echo e(session('mensaje')); ?>

            </div>
        <?php endif; ?>
        <div class="row">
            <div class="col-md-5">
                <div class="text-center">
                    <div class="mb-3">
                        <img class="img-fluid" src="<?php echo e(asset(Auth::user()->foto)); ?>"><br>
                    </div>
                    <div class="mb-3"><?php echo e(Auth::user()->name); ?></div>
                    <div class="mb-3"><?php echo e(Auth::user()->email); ?></div>
                    <form class="text-uppercase" method="POST"
                        action="<?php echo e(route('profile.update', ['id' => Auth::user()->id])); ?>">
                        <?php echo csrf_field(); ?>

                        <?php echo e(method_field('PUT')); ?>

                        <input type="text" name="typec" value="1" hidden>
                        <div class="row mb-3">
                            <label class="col-sm-7 col-form-label"><?php echo e(__('User') . ' /' . __('Name Social')); ?></label>
                            <div class="col-sm-5">
                                <input type="name" name="name" class="form-control" maxlength="12" required autofocus
                                    value="<?php echo e(Auth::user()->name); ?>" <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->denies('chngs')): ?> readonly <?php endif; ?>>
                            </div>
                        </div>
                        <div class="row mb-3">
                            <label class="col-sm-7 col-form-label"><?php echo e(__('Password')); ?></label>
                            <div class="col-sm-5">
                                <input type="password" name="password" class="form-control" maxlength="8" required
                                    autofocus pattern="^(?=\D*\d)(?=.*?[a-zA-Z]).{8}">
                            </div>
                        </div>
                        <div class="row mb-3">
                            <div class="col-sm-offset-2 col-sm-10">
                                <button type="submit"
                                    class="btn btn-primary"><?php echo e(__('Change username and password')); ?></button>
                            </div>
                        </div>
                    </form>
                </div>
            </div><br><br>
            <div class="col-md-7">
                <div class="row">
                    <div class="col-6 mb">
                        <label class="col-form-label fw-bold"><?php echo e(__('Name')); ?></label>
                        <input type="text" class="form-control" value="<?php echo e(Auth::user()->nombre); ?>" readonly>
                    </div>
                    <div class="col-6 mb">
                        <label class="col-form-label fw-bold"><?php echo e(__('Surname')); ?></label>
                        <input type="text" class="form-control" value="<?php echo e(Auth::user()->apellido); ?>" readonly>
                    </div>
                    <div class="col-6">
                        <label class="col-form-label fw-bold"><?php echo e(__('Disability')); ?></label>
                        <select class="form-control mb" disabled style="-webkit-appearance: none;">
                            <option value="No" <?php if(Auth::user()->discapacidad == 'No'): ?> selected <?php endif; ?>>
                                <?php echo e(__('No')); ?>

                            </option>
                            <option value="Visual" <?php if(Auth::user()->discapacidad == 'Visual'): ?> selected <?php endif; ?>>
                                <?php echo e(__('Visual')); ?>

                            </option>
                            <option value="Fisica" <?php if(Auth::user()->discapacidad == 'Fisica'): ?> selected <?php endif; ?>>
                                <?php echo e(__('Physical')); ?>

                            </option>
                            <option value="Auditiva" <?php if(Auth::user()->discapacidad == 'Auditiva'): ?> selected <?php endif; ?>>
                                <?php echo e(__('Auditory')); ?></option>
                            <option value="Verbal" <?php if(Auth::user()->discapacidad == 'Verbal'): ?> selected <?php endif; ?>>
                                <?php echo e(__('Verbal')); ?>

                            </option>
                            <option value="Mental" <?php if(Auth::user()->discapacidad == 'Mental'): ?> selected <?php endif; ?>>
                                <?php echo e(__('Mental')); ?>

                            </option>
                        </select>
                    </div>
                    <div class="col-6 mb"><label class="col-form-label fw-bold"><?php echo e(__('DNI')); ?></label>
                        <input type="text" class="form-control" value="<?php echo e(Auth::user()->dni); ?>" readonly>
                    </div>
                    <?php if(isset(Auth::user()->fdpt)): ?>
                        <div class="col-6 mb text-capitalize text-center center-block">
                            <label class="col-form-label fw-bold"><?php echo e(__('document') . ' ' . __('Disability')); ?></label>
                            <a href="<?php echo e(asset(Auth::user()->fdpt)); ?>"
                                target="blank"><?php echo e(__('document')); ?><br><?php echo e(__('Disability')); ?></a>
                        </div>
                    <?php endif; ?>
                    <?php if(isset(Auth::user()->sdpt)): ?>
                        <div class="col-6 mb text-center">
                            <label class="col-form-label fw-bold"><?php echo e(__('Photo') . ' ' . __('Disability')); ?></label>
                            <img class="img-responsive center-block" src="<?php echo e(asset(Auth::user()->sdpt)); ?>" width="100%">
                        </div>
                    <?php endif; ?>
                    <div class="col-6 mb"><label class="col-form-label fw-bold"><?php echo e(__('Galpon')); ?></label>
                        <input type="text" class="form-control" value="<?php echo e(Auth::user()->galpon); ?>" readonly>
                    </div>
                    <div class="col-6 mb"><label class="col-form-label fw-bold"> <?php echo e(__('Preparer')); ?></label>
                        <input type="text" class="form-control" value="<?php echo e(Auth::user()->prepa); ?>" readonly>
                    </div>
                    <div class="col-6 mb"><label class="col-form-label fw-bold"> <?php echo e(__('Operator')); ?></label>
                        <input type="text" class="form-control" value="<?php echo e(Auth::user()->company); ?>" readonly>
                    </div>
                    <div class="col-6 mb"><label class="col-form-label fw-bold"> <?php echo e(__('Phone')); ?></label>
                        <input type="text" class="form-control" value="<?php echo e(Auth::user()->celular); ?>" readonly>
                    </div>
                    <div class="col-4 mb"><label class="col-form-label fw-bold"> <?php echo e(__('Country')); ?></label>
                        <input type="text" class="form-control" value="<?php echo e(Auth::user()->country); ?>" readonly>
                    </div>
                    <div class="col-4 mb"><label class="col-form-label fw-bold"> <?php echo e(__('State')); ?></label>
                        <input type="text" class="form-control" value="<?php echo e(Auth::user()->state); ?>" readonly>
                    </div>
                    <div class="col-4 mb"><label class="col-form-label fw-bold"> <?php echo e(__('District')); ?></label>
                        <input type="text" class="form-control" value="<?php echo e(Auth::user()->district); ?>" readonly>
                    </div>
                    <div class="col-lg-7 mb"><label class="col-form-label fw-bold"> <?php echo e(__('Direction')); ?></label>
                        <input type="text" class="form-control" value="<?php echo e(Auth::user()->direction); ?>" readonly>
                    </div>
                    <div class="col-lg-5 mb"><label class="col-form-label fw-bold">
                            <?php echo e(__('Profession or Trade')); ?></label>
                        <input type="text" class="form-control" value="<?php echo e(Auth::user()->job); ?>" readonly>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script type="text/javascript">
        //HIDE
        setTimeout(function() {
            $('.alert').fadeOut(3000);
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>