<?php $__env->startSection('content'); ?>
    <div class="card bg-black text-white mx-auto border border-danger mb-3">
        <div class="card-body border border-danger">
            <div class="row mx-auto">
                <div class="col-6 col-md-3 mb-3">
                    <img src="<?php if(!empty(Auth::user()->foto)): ?> <?php echo e(asset(Auth::user()->foto)); ?>

                    <?php else: ?><?php echo e(asset('storage/img/pata.jpg')); ?> <?php endif; ?>"
                        class="img-fluid d-block mx-auto">
                </div>
                <div class="col-6 col-md-3 my-auto">
                    <ul class="list-unstyled">
                        <li>
                            <h6> <?php echo e(__('USER')); ?>: <?php echo e(Auth::user()->name); ?></h6>
                        </li>
                        <li>
                            <h6><?php echo e(__('GALPON')); ?>: <?php echo e(Auth::user()->galpon); ?></h6>
                        </li>
                        <li>
                            <h6><?php echo e(__('COUNTRY')); ?>: <?php echo e(Auth::user()->country); ?></h6>
                        </li>
                        <li>
                            <h6><?php echo e(__('STATE')); ?>: <?php echo e(Auth::user()->state); ?></h6>
                        </li>
                    </ul>
                </div>
                <div class="col-6 col-md-3 my-auto">
                    <img src="<?php if(!empty(
    Auth::user()->mascotas[0]->fotos->where('nfoto', 1)->first()
)): ?> <?php echo e(asset(Auth::user()->mascotas[0]->fotos->where('nfoto', 1)->first()->ruta)); ?>

                    <?php else: ?><?php echo e(asset('storage/img/pata.jpg')); ?> <?php endif; ?>"
                        class="img-fluid d-block mx-auto">
                </div>
                <div class="col-6 col-sm-3 my-auto">
                    <img src="<?php if(!empty(
    Auth::user()->mascotas[1]->fotos->where('nfoto', 1)->first()
)): ?> <?php echo e(asset(Auth::user()->mascotas[1]->fotos->where('nfoto', 1)->first()->ruta)); ?>

                    <?php else: ?><?php echo e(asset('storage/img/pata.jpg')); ?> <?php endif; ?>"
                        class="img-fluid d-block mx-auto">
                </div>
            </div>
        </div>
    </div>

    <form class="form-horizontal" method="POST" action="<?php echo e(route('Events.store')); ?>" enctype="multipart/form-data"
        autocomplete="off">
        <?php echo e(csrf_field()); ?>

        <div class="card mx-auto bg-black text-white border border-danger mb-3">
            <div class="card-body border border-danger">
                <div class="row">
                    
                    <input id="organizador_id" type="text" name="organizador_id" value="<?php echo e(Auth::user()->id); ?>" hidden>
                    
                    <div class="col-sm-12 mb-3">
                        <label for="jueza_id" class="col-form-label fw-bold">
                            <?php echo e(__('Add dates')); ?>

                            <a class="btn btn-success" id="adddates">+</a>
                            <a class="btn btn-danger" id="removedate">-</a>

                            <?php if($errors->has('fechas.*') || $errors->has('fechas')): ?>
                                <span class="text-danger text-fs6">
                                    <?php echo e(__('Get the dates right')); ?>

                                </span>
                            <?php endif; ?>
                        </label>
                        <div class="form_dates row g-3">
                        </div>
                    </div>
                    
                    <div class="col-sm-4 mb-3 form-group<?php echo e($errors->has('coliseo_id') ? ' has-error' : ''); ?>">
                        <label for="coliseo_id" class="col-form-label fw-bold">
                            <?php echo e(__('Coliseum')); ?>

                        </label>
                        <div class="col-auto text-danger">
                            <select class="select2 form-select" name="coliseo_id" placeholder="<?php echo e(__('Coliseum')); ?>"
                                required autofocus>
                                <?php $__currentLoopData = $coliseos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $coliseo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($coliseo->id); ?>"><?php echo e($coliseo->nombre); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>

                            <?php if($errors->has('coliseo_id')): ?>
                                <span class="text-danger text-fs6">
                                    <?php echo e($errors->first('coliseo_id')); ?>

                                </span>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                    <div class="col-sm-4 mb-3 form-group<?php echo e($errors->has('tevent') ? ' has-error' : ''); ?>">
                        <label for="tevent" class="col-form-label fw-bold">
                            <?php echo e(__('Type Event')); ?>

                        </label>
                        <div class="col-auto">
                            <select class="form-select text-danger fw-bold" id="tevent" name="tevent"
                                value="<?php echo e(old('tevent')); ?>" required autofocus>
                                <option value="cmp">
                                    <?php echo e(__('Championship')); ?>

                                </option>
                                <option value="cct">
                                    <?php echo e(__('Concentration')); ?>

                                </option>
                                <option value="chk">
                                    <?php echo e(__('Chuzbk')); ?>

                                </option>
                                <option value="drb">
                                    <?php echo e(__('Derby')); ?>

                                </option>
                                <option value="prt">
                                    <?php echo e(__('Party')); ?>

                                </option>
                                <option value="thr">
                                    <?php echo e(__('Other')); ?>

                                </option>
                            </select>

                            <?php if($errors->has('tevent')): ?>
                                <span class="text-danger text-fs6">
                                    <?php echo e($errors->first('tevent')); ?>

                                </span>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                    <div class="col-sm-4 mb-3 form-group<?php echo e($errors->has('trl') ? ' has-error' : ''); ?>">
                        <label for="trl" class="col-form-label fw-bold">
                            <?php echo e(__('Regulation')); ?>

                        </label>
                        <div class="col-auto">
                            <select class="form-control form-select text-danger fw-bold" id="trl" name="trl"
                                value="<?php echo e(old('trl')); ?>" required autofocus>
                                <option class="text-danger fw-bold" value="cls"
                                    <?php if(old('trl') == 'cls'): ?> selected <?php endif; ?>><?php echo e(__('Coliseum')); ?></option>
                                <option class="text-danger fw-bold" value="dpt"
                                    <?php if(old('trl') == 'dpt'): ?> selected <?php endif; ?>><?php echo e(__('Departmental')); ?></option>
                                <option class="text-danger fw-bold" value="nac"
                                    <?php if(old('trl') == 'nac'): ?> selected <?php endif; ?>><?php echo e(__('National')); ?> </option>
                                <option class="text-danger fw-bold" value="inc"
                                    <?php if(old('trl') == 'inc'): ?> selected <?php endif; ?>><?php echo e(__('International')); ?> </option>
                            </select>
                            <?php if($errors->has('trl')): ?>
                                <span class="text-danger text-fs6">
                                    <?php echo e($errors->first('trl')); ?>

                                </span>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                    <div class="col-6 col-md-2 mb-3 form-group<?php echo e($errors->has('spl') ? ' has-error' : ''); ?>">
                        <label for="spl" class="col-form-label fw-bold">
                            <?php echo e(__('ESPUELAS')); ?>

                        </label>
                        <div class="col-auto">
                            <div class="form-check form-switch">
                                <input class="form-check-input" type="checkbox" value="lbr" name="spl[]"
                                    <?php if(is_array(old('spl')) && in_array('lbr', old('spl'))): ?> checked <?php endif; ?>>
                                <label class="form-check-label" for="switch"><?php echo e(__('Free')); ?></label>
                            </div>
                            <div class="form-check form-switch">
                                <input class="form-check-input" type="checkbox" value="fbr" name="spl[]"
                                    <?php if(is_array(old('spl')) && in_array('fbr', old('spl'))): ?> checked <?php endif; ?>>
                                <label class="form-check-label" for="switch"><?php echo e(__('Fiber')); ?></label>
                            </div>
                            <div class="form-check form-switch">
                                <input class="form-check-input" type="checkbox" value="plt" name="spl[]"
                                    <?php if(is_array(old('spl')) && in_array('plt', old('spl'))): ?> checked <?php endif; ?>>
                                <label class="form-check-label" for="switch"><?php echo e(__('Plastic')); ?></label>
                            </div>
                            <div class="form-check form-switch">
                                <input class="form-check-input" type="checkbox" value="cry" name="spl[]"
                                    <?php if(is_array(old('spl')) && in_array('cry', old('spl'))): ?> checked <?php endif; ?>>
                                <label class="form-check-label" for="switch"><?php echo e(__('Shell')); ?></label>
                            </div>
                            <div class="form-check form-switch">
                                <input class="form-check-input" type="checkbox" value="spn" name="spl[]"
                                    <?php if(is_array(old('spl')) && in_array('spn', old('spl'))): ?> checked <?php endif; ?>>
                                <label class="form-check-label" for="switch"><?php echo e(__('Thorn')); ?></label>
                            </div>
                            <?php if($errors->has('spl')): ?>
                                <span class="text-danger text-fs6">
                                    <?php echo e($errors->first('spl')); ?>

                                </span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="row col-6 col-md-2">
                        
                        <div class="form-group<?php echo e($errors->has('sz') ? ' has-error' : ''); ?>">
                            <label for="sz" class="col-form-label fw-bold">
                                <?php echo e(__('Size')); ?>

                            </label>
                            <div class="col-auto">
                                <select class="form-control form-select text-danger fw-bold" id="sz" name="sz"
                                    value="<?php echo e(old('sz')); ?>" required autofocus>
                                    <option class="text-danger fw-bold" value="5"
                                        <?php if(old('sz') == '5'): ?> selected <?php endif; ?>>5</option>
                                    <option class="text-danger fw-bold" value="8"
                                        <?php if(old('sz') == '8'): ?> selected <?php endif; ?>>8 </option>
                                    <option class="text-danger fw-bold" value="lbr"
                                        <?php if(old('sz') == 'lbr'): ?> selected <?php endif; ?>>Libre</option>
                                </select>
                                <?php if($errors->has('sz')): ?>
                                    <span class="text-danger text-fs6">
                                        <?php echo e($errors->first('sz')); ?>

                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        
                        <div class="form-group<?php echo e($errors->has('time') ? ' has-error' : ''); ?>">
                            <label for="time" class="col-form-label fw-bold">
                                <?php echo e(__('Time')); ?>

                            </label>
                            <div class="col-auto">
                                <select class="form-control form-select text-danger fw-bold" id="time" name="time"
                                    value="<?php echo e(old('time')); ?>" required autofocus>
                                    <option class="text-danger fw-bold" value="4"
                                        <?php if(old('sz') == '4'): ?> selected <?php endif; ?>>4</option>
                                    <option class="text-danger fw-bold" value="6"
                                        <?php if(old('sz') == '6'): ?> selected <?php endif; ?>>6 </option>
                                    <option class="text-danger fw-bold" value="8"
                                        <?php if(old('sz') == '8'): ?> selected <?php endif; ?>>8</option>
                                    <option class="text-danger fw-bold" value="10"
                                        <?php if(old('sz') == '10'): ?> selected <?php endif; ?>>10</option>
                                </select>
                                <?php if($errors->has('time')): ?>
                                    <span class="text-danger text-fs6">
                                        <?php echo e($errors->first('time')); ?>

                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-sm-12 col-md-8">
                        <div class="row">
                            <div
                                class="col-sm-12 col-md-5  form-group<?php echo e($errors->has('miw') || $errors->has('maw') ? ' has-error' : ''); ?>">
                                <label for="weight" class="col-form-label fw-bold">
                                    <?php echo e(__('Weight')); ?>

                                </label>
                                <div class="col-auto">
                                    <div class="input-group">
                                        <span class="input-group-text">
                                            Min
                                            <input type="number" class="form-control text-danger" min="1" id="miw"
                                                name="miw" onKeyPress="if(this.value.length==3) return false;"
                                                onkeydown="return event.keyCode !== 69 && event.keyCode !== 189"
                                                value="<?php echo e(old('miw')); ?>" required autofocus />
                                            Max
                                            <input type="number" class="form-control text-danger" min="1" id="maw"
                                                name="maw" onKeyPress="if(this.value.length==3) return false;"
                                                onkeydown="return event.keyCode !== 69 && event.keyCode !== 189"
                                                value="<?php echo e(old('maw')); ?>" required autofocus />
                                        </span>
                                    </div>
                                    <?php if($errors->has('miw') || $errors->has('maw')): ?>
                                        <span class="text-danger text-fs6">
                                            <?php echo e(__('Enter correct Weights')); ?>

                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div
                                class="col-6 col-sm-6 col-md-3  form-group<?php echo e($errors->has('ctr') ? ' has-error' : ''); ?>">
                                <label for="ctr" class="col-form-label fw-bold">
                                    <?php echo e(__('Country')); ?>

                                </label>
                                <div class="col-auto">
                                    <div class="input-group">
                                        <select class="form-control form-select text-danger fw-bold" id="ctr" name="ctr"
                                            value="<?php echo e(old('ctr')); ?>" required autofocus>
                                            <option class="text-danger fw-bold" value="PE"
                                                <?php if(old('ctr') == 'PE'): ?> selected <?php endif; ?>>Perú</option>
                                            <option class="text-danger fw-bold" value="ARG"
                                                <?php if(old('ctr') == 'ARG'): ?> selected <?php endif; ?>>Argentina</option>
                                            <option class="text-danger fw-bold" value="EC"
                                                <?php if(old('ctr') == 'EC'): ?> selected <?php endif; ?>>Ecuador</option>
                                            <option class="text-danger fw-bold" value="CL"
                                                <?php if(old('ctr') == 'CL'): ?> selected <?php endif; ?>>Chile</option>
                                        </select>
                                    </div>
                                    <?php if($errors->has('ctr')): ?>
                                        <span class="text-danger text-fs6">
                                            <?php echo e($errors->first('ctr')); ?>

                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div
                                class="col-6 col-sm-6 col-md-4  form-group<?php echo e($errors->has('stt') ? ' has-error' : ''); ?>">
                                <label for="stt" class="col-form-label fw-bold">
                                    <?php echo e(__('State')); ?>

                                </label>
                                <div class="col-auto">
                                    <div class="input-group">
                                        <input id="stt" type="text" class="form-control text-danger fw-bold" name="stt"
                                            value="<?php echo e(old('stt')); ?>" minlength="4" maxlength="10" required autofocus>
                                    </div>
                                    <?php if($errors->has('stt')): ?>
                                        <span class="text-danger text-fs6">
                                            <?php echo e($errors->first('stt')); ?>

                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="col-sm-12  form-group<?php echo e($errors->has('drc') ? ' has-error' : ''); ?>">
                                <label for="drc" class="col-form-label fw-bold">
                                    <?php echo e(__('Direction')); ?>

                                </label>
                                <div class="col-auto">
                                    <div class="input-group">
                                        <input id="drc" type="text" class="form-control text-danger fw-bold" name="drc"
                                            value="<?php echo e(old('drc')); ?>" minlength="10" maxlength="80" required autofocus>
                                    </div>
                                    <?php if($errors->has('drc')): ?>
                                        <span class="text-danger text-fs6">
                                            <?php echo e($errors->first('drc')); ?>

                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-4 form-group<?php echo e($errors->has('ftw') ? ' has-error' : ''); ?>">
                        <label for="ftw" class="col-form-label fw-bold">
                            <?php echo e(__('First Time Weight')); ?>

                        </label>
                        <div class="col-auto">
                            <select class="form-control form-select text-danger fw-bold" id="ftw" name="ftw"
                                value="<?php echo e(old('ftw')); ?>" required autofocus>
                                <option class="text-danger fw-bold" value="10:00"
                                    <?php if(old('ftw') == '10:00'): ?> selected <?php endif; ?>>10:00 a.m</option>
                                <option class="text-danger fw-bold" value="11:00"
                                    <?php if(old('ftw') == '11:00'): ?> selected <?php endif; ?>>11:00 a.m</option>
                                <option class="text-danger fw-bold" value="12:00"
                                    <?php if(old('ftw') == '12:00'): ?> selected <?php endif; ?>>12:00 p.m</option>
                                <option class="text-danger fw-bold" value="13:00"
                                    <?php if(old('ftw') == '13:00'): ?> selected <?php endif; ?>>1:00 p.m</option>
                                <option class="text-danger fw-bold" value="14:00"
                                    <?php if(old('ftw') == '14:00'): ?> selected <?php endif; ?>>2:00 p.m</option>
                                <option class="text-danger fw-bold" value="15:00"
                                    <?php if(old('ftw') == '15:00'): ?> selected <?php endif; ?>>3:00 p.m</option>
                                <option class="text-danger fw-bold" value="16:00"
                                    <?php if(old('ftw') == '16:00'): ?> selected <?php endif; ?>>4:00 p.m</option>
                                <option class="text-danger fw-bold" value="17:00"
                                    <?php if(old('ftw') == '17:00'): ?> selected <?php endif; ?>>5:00 p.m</option>
                                <option class="text-danger fw-bold" value="18:00"
                                    <?php if(old('ftw') == '18:00'): ?> selected <?php endif; ?>>6:00 p.m</option>
                                <option class="text-danger fw-bold" value="18:00"
                                    <?php if(old('ftw') == '19:00'): ?> selected <?php endif; ?>>7:00 p.m</option>
                                <option class="text-danger fw-bold" value="18:00"
                                    <?php if(old('ftw') == '20:00'): ?> selected <?php endif; ?>>8:00 p.m</option>
                                <option class="text-danger fw-bold" value="18:00"
                                    <?php if(old('ftw') == '21:00'): ?> selected <?php endif; ?>>9:00 p.m</option>
                                <option class="text-danger fw-bold" value="18:00"
                                    <?php if(old('ftw') == '22:00'): ?> selected <?php endif; ?>>10:00 p.m</option>
                            </select>
                            <?php if($errors->has('ftw')): ?>
                                <span class="text-danger text-fs6">
                                    <?php echo e($errors->first('ftw')); ?>

                                </span>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                    <div class="col-4 form-group<?php echo e($errors->has('stw') ? ' has-error' : ''); ?>">
                        <label for="stw" class="col-form-label fw-bold">
                            <?php echo e(__('Second Time Weight')); ?>

                        </label>
                        <div class="col-auto">
                            <select class="form-control form-select text-danger fw-bold" id="stw" name="stw"
                                value="<?php echo e(old('stw')); ?>" required autofocus>
                                <option class="text-danger fw-bold" value="10:00"
                                    <?php if(old('stw') == '10:00'): ?> selected <?php endif; ?>>10:00 a.m</option>
                                <option class="text-danger fw-bold" value="11:00"
                                    <?php if(old('stw') == '11:00'): ?> selected <?php endif; ?>>11:00 a.m</option>
                                <option class="text-danger fw-bold" value="12:00"
                                    <?php if(old('stw') == '12:00'): ?> selected <?php endif; ?>>12:00 p.m</option>
                                <option class="text-danger fw-bold" value="13:00"
                                    <?php if(old('stw') == '13:00'): ?> selected <?php endif; ?>>1:00 p.m</option>
                                <option class="text-danger fw-bold" value="14:00"
                                    <?php if(old('stw') == '14:00'): ?> selected <?php endif; ?>>2:00 p.m</option>
                                <option class="text-danger fw-bold" value="15:00"
                                    <?php if(old('stw') == '15:00'): ?> selected <?php endif; ?>>3:00 p.m</option>
                                <option class="text-danger fw-bold" value="16:00"
                                    <?php if(old('stw') == '16:00'): ?> selected <?php endif; ?>>4:00 p.m</option>
                                <option class="text-danger fw-bold" value="17:00"
                                    <?php if(old('stw') == '17:00'): ?> selected <?php endif; ?>>5:00 p.m</option>
                                <option class="text-danger fw-bold" value="18:00"
                                    <?php if(old('stw') == '18:00'): ?> selected <?php endif; ?>>6:00 p.m</option>
                                <option class="text-danger fw-bold" value="18:00"
                                    <?php if(old('stw') == '19:00'): ?> selected <?php endif; ?>>7:00 p.m</option>
                                <option class="text-danger fw-bold" value="18:00"
                                    <?php if(old('stw') == '20:00'): ?> selected <?php endif; ?>>8:00 p.m</option>
                                <option class="text-danger fw-bold" value="18:00"
                                    <?php if(old('stw') == '21:00'): ?> selected <?php endif; ?>>9:00 p.m</option>
                                <option class="text-danger fw-bold" value="18:00"
                                    <?php if(old('stw') == '22:00'): ?> selected <?php endif; ?>>10:00 p.m</option>
                            </select>

                            <?php if($errors->has('stw')): ?>
                                <span class="text-danger text-fs6">
                                    <?php echo e($errors->first('stw')); ?>

                                </span>
                            <?php endif; ?>
                        </div>
                        <?php if($errors->has('time')): ?>
                            <span class="text-danger text-fs6">
                                <?php echo e($errors->first('time')); ?>

                            </span>
                        <?php endif; ?>
                    </div>
                    
                    <div class="col-4 form-group<?php echo e($errors->has('hstart') ? ' has-error' : ''); ?>">
                        <label for="hstart" class="col-form-label fw-bold">
                            <?php echo e(__('Time Start')); ?>

                        </label>
                        <div class="col-auto">
                            <input id="hstart" type="time" step='1' class="form-control text-danger fw-bold" name="hstart"
                                value="<?php echo e(old('hstart')); ?>" required autofocus>

                            <?php if($errors->has('hstart')): ?>
                                <span class="text-danger text-fs6">
                                    <?php echo e($errors->first('hstart')); ?>

                                </span>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                    
                    <div class="col-4 form-group<?php echo e($errors->has('mcontrol_id') ? ' has-error' : ''); ?>">
                        <label for="mcontrol_id" class="col-form-label fw-bold">
                            <?php echo e(__('Control desk')); ?>

                        </label>
                        <div class="col-auto">
                            <select class="form-select text-danger fw-bold" id="mcontrol_id" name="mcontrol_id"
                                value="<?php echo e(old('mcontrol_id')); ?>" required autofocus>
                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mcontrol): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($mcontrol->id); ?>"
                                        <?php if(old('mcontrol_id') == $mcontrol->id): ?> selected <?php endif; ?>>
                                        <?php echo e($mcontrol->nombre . ' ' . $mcontrol->apellido); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php if($errors->has('mcontrol_id')): ?>
                                <span class="text-danger text-fs6">
                                    <?php echo e($errors->first('mcontrol_id')); ?>

                                </span>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                    <div class="col-4 form-group<?php echo e($errors->has('judge_id') ? ' has-error' : ''); ?>">
                        <label for="judge_id" class="col-form-label fw-bold">
                            <?php echo e(__('Judge')); ?>

                        </label>
                        <div class="col-auto">
                            <select class="form-select text-danger fw-bold" id="judge_id" name="judge_id"
                                value="<?php echo e(old('judge_id')); ?>" required autofocus>
                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $judge): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($judge->id); ?>"
                                        <?php if(old('judge_id') == $judge->id): ?> selected <?php endif; ?>>
                                        <?php echo e($judge->nombre . ' ' . $judge->apellido); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>

                            <?php if($errors->has('judge_id')): ?>
                                <span class="text-danger text-fs6">
                                    <?php echo e($errors->first('judge_id')); ?>

                                </span>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                    <div class="col-4 form-group<?php echo e($errors->has('assistent_id') ? ' has-error' : ''); ?>">
                        <label for="assistent_id" class="col-form-label fw-bold">
                            <?php echo e(__('Assistant')); ?>

                        </label>
                        <div class="col-auto">
                            <select class="form-select text-danger fw-bold" id="assistent_id" name="assistent_id"
                                value="<?php echo e(old('assistent_id')); ?>" required autofocus>
                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $assisten): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($assisten->id); ?>"
                                        <?php if(old('assistent_id') == $assisten->id): ?> selected <?php endif; ?>>
                                        <?php echo e($assisten->nombre . ' ' . $assisten->apellido); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>

                            <?php if($errors->has('assistent_id')): ?>
                                <span class="text-danger text-fs6">
                                    <?php echo e($errors->first('assistent_id')); ?>

                                </span>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="card mx-auto text-dark border border-danger mb-3">
            <div class="card-body border border-danger">
                
                <div id="carouselExampleInterval" class="carousel slide" data-bs-ride="carousel">
                    <div class="carousel-inner">
                        <div class="carousel-item active" data-bs-interval="2000">
                            <a href="http://www.google.com">
                                <img src="<?php echo e(url('storage/img/shampoo.jpg')); ?>" class="d-block mx-auto" height="380vh">
                            </a>
                        </div>
                        <div class="carousel-item" data-bs-interval="2000">
                            <a href="http://www.google.com">
                                <img src="<?php echo e(url('storage/img/pata.jpg')); ?>" class="d-block mx-auto" height="380vh">
                            </a>
                        </div>
                        <div class="carousel-item" data-bs-interval="2000">
                            <a href="http://www.google.com">
                                <img src="<?php echo e(url('storage/img/dogcorrea.jpg')); ?>" class="d-block mx-auto"
                                    height="380vh">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="card mx-auto bg-black text-white border border-danger mb-3">
            <div class="card-body border border-danger">
                <div class="row">
                    
                    <div class="col-6 col-md-3 mb-3 form-group<?php echo e($errors->has('awards') ? ' has-error' : ''); ?>">
                        <label for="awards" class="col-form-label fw-bold">
                            <?php echo e(__('Awards')); ?>

                        </label>
                        <div class="col-auto">
                            <div class="input-group">
                                <div class="input-group-text">S/.</div>
                                <input id="awards" type="number" class="form-control text-danger fw-bold" name="awards"
                                    value="<?php echo e(old('awards')); ?>" required autofocus min="0"
                                    onKeyPress="if(this.value.length==3) return false;"
                                    onkeydown="return event.keyCode !== 69 && event.keyCode !== 189" />
                                <?php if($errors->has('awards')): ?>
                                    <span class="text-danger text-fs6">
                                        <?php echo e($errors->first('awards')); ?>

                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-6 col-md-2 mb-3 form-group<?php echo e($errors->has('trophys') ? ' has-error' : ''); ?>">
                        <label for="trophys" class="col-form-label fw-bold">
                            <?php echo e(__('Trophys')); ?>

                        </label>
                        <div class="col-auto">
                            <input id="trophys" type="number" class="form-control text-danger fw-bold" name="trophys"
                                value="<?php echo e(old('trophys')); ?>" required autofocus min="0"
                                onKeyPress="if(this.value.length==3) return false;"
                                onkeydown="return event.keyCode !== 69 && event.keyCode !== 189" />

                            <?php if($errors->has('trophys')): ?>
                                <span class="text-danger text-fs6">
                                    <?php echo e($errors->first('trophys')); ?>

                                </span>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                    <div class="col-6 col-md-4 mb-3 form-group<?php echo e($errors->has('rooster') ? ' has-error' : ''); ?>">
                        <label for="rooster" class="col-form-label fw-bold">
                            <?php echo e(__('Rooster')); ?>

                        </label>
                        <div class="col-auto">
                            <div class="input-group">
                                <div class="input-group-text">S/.</div>
                                <input id="rooster" type="number" class="form-control text-danger fw-bold" name="rooster"
                                    value="0" required autofocus min="0" onKeyPress="if(this.value.length==4) return false;"
                                    onkeydown="return event.keyCode !== 69 && event.keyCode !== 189" />
                                <select class="form-select text-danger fw-bold" id="trooster" name="trooster"
                                    value="<?php echo e(old('trooster')); ?>" required autofocus>
                                    <option value="30">30 <?php echo e(__('seconds')); ?></option>
                                    <option value="60">60 <?php echo e(__('seconds')); ?></option>
                                </select>

                                <?php if($errors->has('rooster')): ?>
                                    <span class="text-danger text-fs6">
                                        <?php echo e($errors->first('rooster')); ?>

                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-6 col-md-3 my-auto mb-3 form-group<?php echo e($errors->has('rten') ? ' has-error' : ''); ?>">
                        <label for="rten" class="col-form-label fw-bold">
                            <?php echo e(__('Rooster')); ?> 10 <?php echo e(__('seconds')); ?>

                        </label>
                        <div class="col-auto">
                            <div class="input-group">
                                <div class="input-group-text">S/.</div>
                                <input id="rten" type="number" class="form-control text-danger fw-bold" name="rten"
                                    value="0" required autofocus min="0" onKeyPress="if(this.value.length==4) return false;"
                                    onkeydown="return event.keyCode !== 69 && event.keyCode !== 189">

                                <?php if($errors->has('rten')): ?>
                                    <span class="text-danger text-fs6">
                                        <?php echo e($errors->first('rten')); ?>

                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-6 col-md-3 mb-3 form-group<?php echo e($errors->has('fft') ? ' has-error' : ''); ?>">
                        <label for="fft" class="col-form-label fw-bold">
                            <?php echo e(__('1er Frente')); ?>

                        </label>
                        <div class="col-auto">
                            <div class="input-group">
                                <div class="input-group-text">S/.</div>
                                <input id="fft" type="number" class="form-control text-danger fw-bold" name="fft" value="0"
                                    required autofocus min="0" onKeyPress="if(this.value.length==4) return false;"
                                    onkeydown="return event.keyCode !== 69 && event.keyCode !== 189" />

                                <?php if($errors->has('fft')): ?>
                                    <span class="text-danger text-fs6">
                                        <?php echo e($errors->first('fft')); ?>

                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-6 col-md-3 mb-3 form-group<?php echo e($errors->has('sft') ? ' has-error' : ''); ?>">
                        <label for="sft" class="col-form-label fw-bold">
                            <?php echo e(__('2do Frente')); ?>

                        </label>
                        <div class="col-auto">
                            <div class="input-group">
                                <div class="input-group-text">S/.</div>
                                <input id="sft" type="number" class="form-control text-danger fw-bold" name="sft" value="0"
                                    required autofocus min="0" onKeyPress="if(this.value.length==4) return false;"
                                    onkeydown="return event.keyCode !== 69 && event.keyCode !== 189" />

                                <?php if($errors->has('sft')): ?>
                                    <span class="text-danger text-fs6">
                                        <?php echo e($errors->first('sft')); ?>

                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-6 col-md-3 mb-3 form-group<?php echo e($errors->has('tft') ? ' has-error' : ''); ?>">
                        <label for="tft" class="col-form-label fw-bold">
                            <?php echo e(__('3er Frente')); ?>

                        </label>
                        <div class="col-auto">
                            <div class="input-group">
                                <div class="input-group-text">S/.</div>
                                <input id="tft" type="number" class="form-control text-danger fw-bold" name="tft" value="0"
                                    required autofocus min="0" onKeyPress="if(this.value.length==4) return false;"
                                    onkeydown="return event.keyCode !== 69 && event.keyCode !== 189" />

                                <?php if($errors->has('tft')): ?>
                                    <span class="text-danger text-fs6">
                                        <?php echo e($errors->first('tft')); ?>

                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-6 col-md-3 col-md-3 mb-3 form-group<?php echo e($errors->has('fcd') ? ' has-error' : ''); ?>">
                        <label for="fcd" class="col-form-label fw-bold">
                            <?php echo e(__('Fight quality')); ?>

                        </label>
                        <div class="col-auto">
                            <div class="input-group">
                                <div class="input-group-text">S/.</div>
                                <input id="fcd" type="number" class="form-control text-danger fw-bold" name="fcd" value="0"
                                    required autofocus min="0" onKeyPress="if(this.value.length==4) return false;"
                                    onkeydown="return event.keyCode !== 69 && event.keyCode !== 189" />

                                <?php if($errors->has('fcd')): ?>
                                    <span class="text-danger text-fs6">
                                        <?php echo e($errors->first('fcd')); ?>

                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-6 col-md-3 col-lg-2 mb-3 form-group<?php echo e($errors->has('pvs') ? ' has-error' : ''); ?>">
                        <label for="pvs" class="col-form-label fw-bold">
                            <?php echo e(__('Turkeys')); ?>

                        </label>
                        <div class="col-auto">
                            <input id="pvs" type="number" class="form-control text-danger fw-bold" name="pvs"
                                value="<?php echo e(old('pvs')); ?>" required autofocus min="0"
                                onKeyPress="if(this.value.length==1) return false;"
                                onkeydown="return event.keyCode !== 69 && event.keyCode !== 189" />

                            <?php if($errors->has('pvs')): ?>
                                <span class="text-danger text-fs6">
                                    <?php echo e($errors->first('pvs')); ?>

                                </span>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                    <div class="col-6 col-md-3 col-lg-4 mb-3 form-group<?php echo e($errors->has('lch') ? ' has-error' : ''); ?>">
                        <label for="lch" class="col-form-label fw-bold">
                            <?php echo e(__('Piglets')); ?>

                        </label>
                        <div class="col-auto">
                            <input id="lch" type="number" class="form-control text-danger fw-bold" name="lch"
                                value="<?php echo e(old('lch')); ?>" required autofocus min="0"
                                onKeyPress="if(this.value.length==1) return false;" }
                                onkeydown="return event.keyCode !== 69 && event.keyCode !== 189" />

                            <?php if($errors->has('lch')): ?>
                                <span class="text-danger text-fs6">
                                    <?php echo e($errors->first('lch')); ?>

                                </span>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                    <div class="col-5 col-md-3 mb-3 form-group<?php echo e($errors->has('cnt') ? ' has-error' : ''); ?>">
                        <label for="cnt" class="col-form-label fw-bold">
                            <?php echo e(__('Baskets')); ?>

                        </label>
                        <div class="col-auto">
                            <input id="cnt" type="number" class="form-control text-danger fw-bold" name="cnt"
                                value="<?php echo e(old('cnt')); ?>" required autofocus min="0"
                                onKeyPress="if(this.value.length==1) return false;"
                                onkeydown="return event.keyCode !== 69 && event.keyCode !== 189" />

                            <?php if($errors->has('cnt')): ?>
                                <span class="text-danger text-fs6">
                                    <?php echo e($errors->first('cnt')); ?>

                                </span>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                    <div class="col-7 col-md-3 mb-3 form-group<?php echo e($errors->has('skg') ? ' has-error' : ''); ?>">
                        <label for="skg" class="col-form-label fw-bold">
                            <?php echo e(__('Bags')); ?>

                        </label>
                        <div class="row">
                            <div class="input-group">
                                <div class="input-group-text">N°</div>
                                <input id="skg" type="number" class="col form-control text-danger fw-bold" name="skg"
                                    value="<?php echo e(old('skg')); ?>" required autofocus min="0"
                                    onKeyPress="if(this.value.length==1) return false;"
                                    onkeydown="return event.keyCode !== 69 && event.keyCode !== 189" />
                                <?php if($errors->has('skg')): ?>
                                    <span class="text-danger text-fs6">
                                        <?php echo e($errors->first('skg')); ?>

                                    </span>
                                <?php endif; ?>
                                <div class="input-group-text">KG</div>
                                <input id="ws" type="number" class="form-control text-danger fw-bold" name="ws"
                                    value="<?php echo e(old('ws')); ?>" required autofocus min="0"
                                    onKeyPress="if(this.value.length==2) return false;"
                                    onkeydown="return event.keyCode !== 69 && event.keyCode !== 189" />
                                <?php if($errors->has('ws')): ?>
                                    <span class="text-danger text-fs6">
                                        <?php echo e($errors->first('ws')); ?>

                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="card mx-auto bg-black text-white border border-danger mb-3">
            <div class="card-body border border-danger">
                <div class="row">
                    
                    <label for="egn" class="col-form-label fw-bold text-uppercase">
                        <?php echo e(__('Tickets')); ?>

                    </label>
                    
                    <div class="col-6 col-md-3 mb-3 form-group<?php echo e($errors->has('egn') ? ' has-error' : ''); ?>">
                        <label for="egn" class="col-form-label fw-bold">
                            <?php echo e(__('GENERAL')); ?>

                        </label>
                        <div class="col-auto">
                            <div class="input-group">
                                <div class="input-group-text">S/.</div>
                                <input id="egn" type="number" class="form-control text-danger fw-bold" name="egn"
                                    value="<?php echo e(old('egn')); ?>" required autofocus min="0"
                                    onKeyPress="if(this.value.length==3) return false;"
                                    onkeydown="return event.keyCode !== 69 && event.keyCode !== 189" />
                            </div>

                            <?php if($errors->has('egn')): ?>
                                <span class="text-danger text-fs6">
                                    <?php echo e($errors->first('egn')); ?>

                                </span>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                    <div class="col-6 col-md-3 mb-3 form-group<?php echo e($errors->has('evp') ? ' has-error' : ''); ?>">
                        <label for="evp" class="col-form-label fw-bold">
                            <?php echo e(__('VIP')); ?>

                        </label>
                        <div class="col-auto">
                            <div class="input-group">
                                <div class="input-group-text">S/.</div>
                                <input id="evp" type="number" class="form-control text-danger fw-bold" name="evp"
                                    value="<?php echo e(old('evp')); ?>" required autofocus min="0"
                                    onKeyPress="if(this.value.length==3) return false;"
                                    onkeydown="return event.keyCode !== 69 && event.keyCode !== 189" />
                            </div>
                            <?php if($errors->has('evp')): ?>
                                <span class="text-danger text-fs6">
                                    <?php echo e($errors->first('evp')); ?>

                                </span>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                    <div class="col-6 col-md-3 mb-3 form-group<?php echo e($errors->has('pct') ? ' has-error' : ''); ?>">
                        <label for="pct" class="col-form-label fw-bold">
                            <?php echo e(__('Pact')); ?>

                        </label>
                        <div class="col-auto">
                            <div class="input-group">
                                <div class="input-group-text">S/.</div>
                                <input id="pct" type="number" class="form-control text-danger fw-bold" name="pct"
                                    value="<?php echo e(old('pct')); ?>" required autofocus min="0"
                                    onKeyPress="if(this.value.length==3) return false;"
                                    onkeydown="return event.keyCode !== 69 && event.keyCode !== 189" />
                            </div>
                            <?php if($errors->has('pct')): ?>
                                <span class="text-danger text-fs6">
                                    <?php echo e($errors->first('pct')); ?>

                                </span>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                    <div class="col-6 col-md-3 mb-3 form-group<?php echo e($errors->has('bs') ? ' has-error' : ''); ?>">
                        <label for="bs" class="col-form-label fw-bold">
                            <?php echo e(__('BASE')); ?>

                        </label>
                        <div class="col-auto">
                            <input id="bs" type="number" class="form-control text-danger fw-bold" name="bs"
                                value="<?php echo e(old('bs')); ?>" required autofocus min="0"
                                onKeyPress="if(this.value.length==4) return false;"
                                onkeydown="return event.keyCode !== 69 && event.keyCode !== 189" />

                            <?php if($errors->has('bs')): ?>
                                <span class="text-danger text-fs6">
                                    <?php echo e($errors->first('bs')); ?>

                                </span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <label for="ift" class="col-form-label fw-bold text-uppercase">
                        <?php echo e(__('inscriptions')); ?>

                    </label>
                    
                    
                    <div class="col-md-3 mb-3 form-group<?php echo e($errors->has('ift') ? ' has-error' : ''); ?>">
                        <label for="ift" class="col-form-label fw-bold">
                            <?php echo e(__('FRENTE')); ?>

                        </label>
                        <div class="col-auto">
                            <div class="input-group">
                                <div class="input-group-text">S/.</div>
                                <input id="ift" type="number" class="form-control text-danger fw-bold" name="ift"
                                    value="<?php echo e(old('ift')); ?>" required autofocus min="0"
                                    onKeyPress="if(this.value.length==4) return false;" />
                            </div>
                            <?php if($errors->has('ift')): ?>
                                <span class="text-danger text-fs6">
                                    <?php echo e($errors->first('ift')); ?>

                                </span>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                    <div class="col-md-3 mb-3 form-group<?php echo e($errors->has('gll') ? ' has-error' : ''); ?>">
                        <label for="gll" class="col-form-label fw-bold">
                            <?php echo e(__('Cock')); ?>

                        </label>
                        <div class="col-auto">
                            <div class="input-group">
                                <div class="input-group-text">S/.</div>
                                <input id="gll" type="number" class="form-control text-danger fw-bold" name="gll"
                                    value="<?php echo e(old('gll')); ?>" required autofocus min="0"
                                    onKeyPress="if(this.value.length==4) return false;"
                                    onkeydown="return event.keyCode !== 69 && event.keyCode !== 189" />
                            </div>
                            <?php if($errors->has('gll')): ?>
                                <span class="text-danger text-fs6">
                                    <?php echo e($errors->first('gll')); ?>

                                </span>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                    <div class="col-md-3 mb-3 form-group<?php echo e($errors->has('glp') ? ' has-error' : ''); ?>">
                        <label for="glp" class="col-form-label fw-bold">
                            <?php echo e(__('Shed')); ?>

                        </label>
                        <div class="col-auto">
                            <div class="input-group">
                                <div class="input-group-text">S/.</div>
                                <input id="glp" type="number" class="form-control text-danger fw-bold" name="glp"
                                    value="<?php echo e(old('glp')); ?>" required autofocus min="0"
                                    onKeyPress="if(this.value.length==4) return false;"
                                    onkeydown="return event.keyCode !== 69 && event.keyCode !== 189" />
                            </div>
                            <?php if($errors->has('glp')): ?>
                                <span class="text-danger text-fs6">
                                    <?php echo e($errors->first('glp')); ?>

                                </span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="col-md-12 mb-3">
                        <h6>*<?php echo e(__('People with disabilities and women pass free')); ?></h6>
                        
                        <h6>*<?php echo e(__('Old people just pay 50')); ?>%</h6>
                    </div>
                    
                    <div class="col-md-12 ">
                        <div class="mx-auto">
                            <button type="submit" class="btn btn-primary">
                                <?php echo e(__('Add Event')); ?>

                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </form>

    <script src="<?php echo e(asset('js/jquery-3.6.0.js')); ?>"></script>
    <script type="text/javascript">
        /* ADD DATE */
        $("#adddates").click(function() {
            $(".form_dates").append(
                '<div id="dfechas" class="col-6 col-md"><input id="fechas" type="date" class="form-control text-danger fw-bold" name="fechas[]" required autofocus ></div>'
            );
        });
        /* DELETE DATE */
        $("#removedate").click(function() {
            $('#dfechas').last().remove();
        });
        /* AWARDS */
        /* function Sum() {
            var rtr = $('#rooster').val();
            var rten = $('#rten').val();
            var fft = $('#fft').val();
            var sft = $('#sft').val();
            var tft = $('#tft').val();
            var fcd = $('#fcd').val();
            var sum = parseInt(rtr) + parseInt(rten) + parseInt(fft) + parseInt(sft) + parseInt(tft) + parseInt(fcd);
            console.log(sum);
            $('#awards').val(sum);
        }
        $("#rooster").change(Sum);
        $("#rten").change(Sum);
        $("#1ft").change(Sum);
        $("#2ft").change(Sum);
        $("#3ft").change(Sum);
        $("#fcd").change(Sum);
        Sum(); */
        /*  SOLO NUMEROS */
        $(document).ready(function() {
            $('input').bind('copy paste', function(e) {
                e.preventDefault();
            });
        });
    </script>

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" />
    <link rel="stylesheet"
        href="https://cdn.jsdelivr.net/npm/select2-bootstrap-5-theme@1.2.0/dist/select2-bootstrap-5-theme.min.css" />

    <!-- Scripts -->
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
    <script>
        $('.select2').select2({
            theme: 'bootstrap-5'
        });
    </script>
    <style>
        .select2-container {
            color: rgb(210, 0, 0);
        }

    </style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>