<?php $__env->startSection('title'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1><?php echo e(__('Coliseum')); ?></h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <form action="<?php echo e(route('mcoliseos.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>

            <?php echo e(method_field('POST')); ?>

            <div class="form-group">
                <label class="form-label"><?php echo e(__('Name')); ?></label>
                <input type="text" class="form-control" name="nombre" id="nombre" minlength="5" maxlength="30">
            </div>
            <div class="form-inline form-group">
                <div class="form-group">
                    <label for="country"><?php echo e(__('Country')); ?></label>
                    <select class="form-control text-danger fw-bold" id="country" name="country" value="<?php echo e(old('country')); ?>" required
                        autofocus>
                        <option class="text-danger fw-bold" value="PER" <?php if(old('country') == 'PER'): ?> selected <?php endif; ?>>
                            PER - Perú
                        </option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="state"><?php echo e(__('State')); ?></label>
                    <select class="form-control text-danger fw-bold" name="state" id="state" value="<?php echo e(old('state')); ?>" required
                        autofocus>
                        <option data="PER" class="text-danger fw-bold" value="AM"
                            <?php if(old('state') == 'AM'): ?> selected <?php endif; ?>>
                            AM - Amazonas</option>
                        <option data="PER" class="text-danger fw-bold" value="AN"
                            <?php if(old('state') == 'AN'): ?> selected <?php endif; ?>>
                            AN - Ancash
                        </option>
                        <option data="PER" class="text-danger fw-bold" value="AP"
                            <?php if(old('state') == 'AP'): ?> selected <?php endif; ?>>
                            AP - Apurímac
                        </option>
                        <option data="PER" class="text-danger fw-bold" value="AR"
                            <?php if(old('state') == 'AR'): ?> selected <?php endif; ?>>
                            AR - Arequipa
                        </option>
                        <option data="PER" class="text-danger fw-bold" value="AY"
                            <?php if(old('state') == 'AY'): ?> selected <?php endif; ?>>
                            AY - Ayacucho
                        </option>
                        <option data="PER" class="text-danger fw-bold" value="CJ"
                            <?php if(old('state') == 'CJ'): ?> selected <?php endif; ?>>
                            CJ - Cajamarca
                        </option>
                        <option data="PER" class="text-danger fw-bold" value="CZ"
                            <?php if(old('state') == 'CZ'): ?> selected <?php endif; ?>>
                            CZ - Cuzco
                        </option>
                        <option data="PER" class="text-danger fw-bold" value="HC"
                            <?php if(old('state') == 'HC'): ?> selected <?php endif; ?>>
                            HC - Huancavelica</option>
                        <option data="PER" class="text-danger fw-bold" value="HU"
                            <?php if(old('state') == 'HU'): ?> selected <?php endif; ?>>
                            HU - Huánuco
                        </option>
                        <option data=" PER" class="text-danger fw-bold" value="IC"
                            <?php if(old('state') == 'IC'): ?> selected <?php endif; ?>>
                            IC - Ica
                        </option>
                        <option data="PER" class="text-danger fw-bold" value="JU"
                            <?php if(old('state') == 'JU'): ?> selected <?php endif; ?>>
                            JU - Junín
                        </option>
                        <option data=" PER" class="text-danger fw-bold" value="LL"
                            <?php if(old('state') == 'LL'): ?> selected <?php endif; ?>>
                            LL - La Libertad</option>
                        <option data="PER" class="text-danger fw-bold" value="LB"
                            <?php if(old('state') == 'LB'): ?> selected <?php endif; ?>>
                            LB - Lambayeque</option>
                        <option data="PER" class="text-danger fw-bold" value="LM"
                            <?php if(old('state') == 'LM'): ?> selected <?php endif; ?> selected>
                            LM - Lima
                        </option>
                        <option data="PER" class="text-danger fw-bold" value="LO"
                            <?php if(old('state') == 'LO'): ?> selected <?php endif; ?>>
                            LO - Loreto
                        </option>
                        <option data="PER" class="text-danger fw-bold" value="MD"
                            <?php if(old('state') == 'MD'): ?> selected <?php endif; ?>>
                            MD - Madre de Dios</option>
                        <option data="PER" class="text-danger fw-bold" value="MQ"
                            <?php if(old('state') == 'MQ'): ?> selected <?php endif; ?>>
                            MQ - Moquegua</option>
                        <option data="PER" class="text-danger fw-bold" value="PA"
                            <?php if(old('state') == 'PA'): ?> selected <?php endif; ?>>
                            PA - Pasco
                        </option>
                        <option data="PER" class="text-danger fw-bold" value="PI"
                            <?php if(old('state') == 'PI'): ?> selected <?php endif; ?>>
                            PI - Piura
                        </option>
                        <option data="PER" class="text-danger fw-bold" value="PU"
                            <?php if(old('state') == 'PU'): ?> selected <?php endif; ?>>
                            PU - Puno
                        </option>
                        <option data="PER" class="text-danger fw-bold" value="SM"
                            <?php if(old('state') == 'SM'): ?> selected <?php endif; ?>>
                            SM - San Martín</option>
                        <option data="PER" class="text-danger fw-bold" value="TA"
                            <?php if(old('state') == 'TA'): ?> selected <?php endif; ?>>
                            TA - Tacna
                        </option>
                        <option data="PER" class="text-danger fw-bold" value="TU"
                            <?php if(old('state') == 'TU'): ?> selected <?php endif; ?>>
                            TU - Tumbes
                        </option>
                        <option data=" PER" class="text-danger fw-bold" value="UC"
                            <?php if(old('state') == 'UC'): ?> selected <?php endif; ?>>
                            UC - Ucayali</option>
                    </select>
                    <div class="form-group">
                        <label class="form-label"><?php echo e(__('District')); ?></label>
                        <input type="text" class="form-control" name="district" id="district" minlength="3" maxlength="30">
                    </div>
                </div>
            </div>
            <div class="form-group">
                <label class="form-label"><?php echo e(__('Reference')); ?></label>
                <input type="text" class="form-control" name="reference" id="rfr" minlength="5" maxlength="60" placeholder="REF. ó ALT.">
            </div>
            <div class="form-group">
                <button type="submit" class="btn btn-primary"><?php echo e(__('Add coliseum')); ?></button>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>