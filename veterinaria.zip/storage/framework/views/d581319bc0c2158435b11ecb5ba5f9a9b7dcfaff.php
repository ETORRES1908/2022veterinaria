<?php $__env->startSection('content'); ?>
    <div class="mx-auto w-75">
        <div class="mb-5">
            <a href="<?php echo e(route('Mascotas.create')); ?>" class="fw-bold text-uppercase btn btn-outline-danger px-5">
                <?php echo e(__('Add Pet')); ?>

            </a>
        </div>

        <div class="row row-cols-1 row-cols-sm-2 g-4">
            <?php $__currentLoopData = $mascotas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mascota): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col">
                    <div class="card border-dark mb-3">
                        <div class="row g-0">
                            <div class="col-md-4 my-auto">
                                <img src="<?php if(!empty($mascota->fotos->where('nfoto', 1)->first())): ?> <?php echo e(asset($mascota->fotos->where('nfoto', 1)->first()->ruta)); ?>

                                <?php else: ?>
                                <?php echo e(asset('storage/img/pata.jpg')); ?> <?php endif; ?>"
                                    class="img-fluid rounded-start" alt="...">
                            </div>
                            <div class="col-md-8">
                                <div class="card-body">
                                    <h5 class="card-title">
                                        <a href="<?php echo e(route('Mascotas.show', $mascota->id)); ?>"
                                            class="fw-bold nav-link link-danger text-uppercase"><?php echo e($mascota->REGGAL); ?>

                                        </a>
                                    </h5>
                                    <div class="card-text">
                                        <ul class="list-group list-group-flush">
                                            <li class="list-group-item">
                                                <div><?php echo e(__('Name')); ?>: <?php echo e($mascota->nombre); ?></div>
                                            </li>
                                            <li class="list-group-item">
                                                <div><?php echo e(__('Birthday')); ?>: <?php echo e($mascota->fnac); ?></div>
                                            </li>
                                            <li class="list-group-item">
                                                <div><?php echo e(__('Weight')); ?>: <?php echo e($mascota->sss); ?></div>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>