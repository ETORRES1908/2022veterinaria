<?php $__env->startSection('title'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1 class="text-uppercase"><?php echo e($user->nombre); ?> <?php echo e($user->apellido); ?></h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <?php if(session('mensaje')): ?>
            <div class="alert alert-success">
                <?php echo e(session('mensaje')); ?>

            </div>
        <?php endif; ?>
        <div class="row bg-black" style="padding:5vh 0 10vh 0;font-size: 1.3em">
            <div class="col-md-5">
                <div class="text-center">
                    <div class="mb">
                        <img width="100%" src="<?php echo e(asset($user->foto)); ?>"><br>
                    </div>
                    <div class="mb"><?php echo e($user->name); ?></div>
                    <div class="mb"><?php echo e($user->email); ?></div>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('chngs')): ?>
                        <?php if(Auth::user()->usert == 'webmaster'): ?>
                            <form class="form-horizontal text-uppercase" method="POST"
                                action="<?php echo e(route('usuarios.update', ['id' => $user->id])); ?>">
                                <?php echo csrf_field(); ?>

                                <?php echo e(method_field('PUT')); ?>

                                <input type="text" name="typec" value="0" hidden>
                                <div class="form-group">
                                    <label class="col-sm-7 control-label"><?php echo e(__('Status') . ' ' . __('Account')); ?>:</label>
                                    <div class="col-sm-5">
                                        <select class="form-control text-danger" name="status">
                                            <option value="0" <?php if($user->status == '0'): ?> selected <?php endif; ?>>
                                                <?php echo e(__('Inactived')); ?>

                                            </option>
                                            <option value="1" <?php if($user->status == '1'): ?> selected <?php endif; ?>>
                                                <?php echo e(__('Actived')); ?>

                                            </option>
                                            <option value="2" <?php if($user->status == '2'): ?> selected <?php endif; ?>>
                                                <?php echo e(__('Suspended')); ?>

                                            </option>
                                            <option value="3" <?php if($user->status == '3'): ?> selected <?php endif; ?>>
                                                <?php echo e(__('Cancelled')); ?>

                                            </option>
                                        </select>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="col-sm-offset-2 col-sm-10">
                                        <button type="submit" class="btn btn-primary"><?php echo e(__('Change status')); ?></button>
                                    </div>
                                </div>

                            </form>
                            <form class="form-horizontal text-uppercase" method="POST"
                                action="<?php echo e(route('usuarios.update', ['id' => $user->id])); ?>">
                                <?php echo csrf_field(); ?>

                                <?php echo e(method_field('PUT')); ?>

                                <input type="text" name="typec" value="1" hidden>

                                <div class="form-group">
                                    <label class="col-sm-7 control-label"><?php echo e(__('User') . ' /' . __('Name Social')); ?></label>
                                    <div class="col-sm-5">
                                        <input type="name" name="name" class="form-control" maxlength="12" required autofocus
                                            value="<?php echo e($user->name); ?>">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-sm-7 control-label"><?php echo e(__('Password')); ?></label>
                                    <div class="col-sm-5">
                                        <input type="password" name="password" class="form-control" maxlength="8" required
                                            autofocus>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="col-sm-offset-2 col-sm-10">
                                        <button type="submit"
                                            class="btn btn-primary"><?php echo e(__('Change username and password')); ?></button>
                                    </div>
                                </div>
                            </form>
                            <form class="formulario-eliminar form-horizontal text-uppercase" method="POST"
                                action="<?php echo e(route('usuarios.destroy', ['id' => $user->id])); ?>">
                                <?php echo csrf_field(); ?>

                                <?php echo e(method_field('DELETE')); ?>

                                <button type="submit" id="delete" class="btn btn-danger"><?php echo e(__('Delete')); ?></button>
                            </form>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
            </div>
            <div class="col-md-6">
                <div class="row">
                    <div class="col-xs-6 mb">
                        <label><?php echo e(__('Name')); ?></label>
                        <input type="text" class="form-control" value="<?php echo e($user->nombre); ?>" readonly>
                    </div>
                    <div class="col-xs-6 mb">
                        <label><?php echo e(__('Surname')); ?></label>
                        <input type="text" class="form-control" value="<?php echo e($user->apellido); ?>" readonly>
                    </div>
                    <div class="col-xs-6">
                        <label><?php echo e(__('Disability')); ?></label>
                        <select class="form-control mb" disabled style="-webkit-appearance: none;">
                            <option value="No" <?php if($user->discapacidad == 'No'): ?> selected <?php endif; ?>>
                                <?php echo e(__('No')); ?>

                            </option>
                            <option value="Visual" <?php if($user->discapacidad == 'Visual'): ?> selected <?php endif; ?>>
                                <?php echo e(__('Visual')); ?>

                            </option>
                            <option value="Fisica" <?php if($user->discapacidad == 'Fisica'): ?> selected <?php endif; ?>>
                                <?php echo e(__('Physical')); ?>

                            </option>
                            <option value="Auditiva" <?php if($user->discapacidad == 'Auditiva'): ?> selected <?php endif; ?>>
                                <?php echo e(__('Auditory')); ?></option>
                            <option value="Verbal" <?php if($user->discapacidad == 'Verbal'): ?> selected <?php endif; ?>>
                                <?php echo e(__('Verbal')); ?>

                            </option>
                            <option value="Mental" <?php if($user->discapacidad == 'Mental'): ?> selected <?php endif; ?>>
                                <?php echo e(__('Mental')); ?>

                            </option>
                        </select>
                    </div>
                    <div class="col-xs-6 mb"><label><?php echo e(__('DNI')); ?></label>
                        <input type="text" class="form-control" value="<?php echo e($user->dni); ?>" readonly>
                    </div>
                    <?php if(isset($user->fdpt)): ?>
                        <div class="col-xs-6 text-capitalize text-center">
                            <a href="<?php echo e(asset($user->fdpt)); ?>"
                                target="blank"><?php echo e(__('document')); ?><br><?php echo e(__('Disability')); ?></a>
                        </div>
                    <?php endif; ?>
                    <?php if(isset($user->sdpt)): ?>
                        <div class="col-xs-6 text-center">
                            <img class="img-responsive center-block" src="<?php echo e(asset($user->sdpt)); ?>" width="100%">
                        </div>
                    <?php endif; ?>
                    <div class="col-xs-6 mb"><label><?php echo e(__('Galpon')); ?></label>
                        <input type="text" class="form-control" value="<?php echo e($user->galpon); ?>" readonly>
                    </div>
                    <div class="col-xs-6 mb"><label> <?php echo e(__('Preparer')); ?></label>
                        <input type="text" class="form-control" value="<?php echo e($user->prepa); ?>" readonly>
                    </div>
                    <div class="col-xs-6 mb"><label> <?php echo e(__('Operator')); ?></label>
                        <input type="text" class="form-control" value="<?php echo e($user->company); ?>" readonly>
                    </div>
                    <div class="col-xs-6 mb"><label> <?php echo e(__('Phone')); ?></label>
                        <input type="text" class="form-control" value="<?php echo e($user->celular); ?>" readonly>
                    </div>
                    <div class="col-xs-4 mb"><label> <?php echo e(__('Country')); ?></label>
                        <input type="text" class="form-control" value="<?php echo e($user->country); ?>" readonly>
                    </div>
                    <div class="col-xs-8 col-lg-4 mb"><label> <?php echo e(__('State')); ?></label>
                        <input type="text" class="form-control" value="<?php echo e($user->state); ?>" readonly>
                    </div>
                    <div class=" col-lg-4 mb"><label> <?php echo e(__('District')); ?></label>
                        <input type="text" class="form-control" value="<?php echo e($user->district); ?>" readonly>
                    </div>
                    <div class="col-lg-7 mb"><label> <?php echo e(__('Direction')); ?></label>
                        <input type="text" class="form-control" value="<?php echo e($user->direction); ?>" readonly>
                    </div>
                    <div class="col-lg-5 mb"><label> <?php echo e(__('Profession or Trade')); ?></label>
                        <input type="text" class="form-control" value="<?php echo e($user->job); ?>" readonly>
                    </div>
                </div>
            </div>
        </div>
    </div>

    
    <style>
        .form-control {
            color: rgb(210, 0, 0);
        }

        .mb {
            margin-bottom: 1vh;
        }

        .swal2-popup {
            height: 100%;
            font-size: 100%
        }

    </style>
    <script src="<?php echo e(asset('js/jquery-3.6.0.js')); ?>"></script>
    
    <script>
        /* ALERT */
        setTimeout(function() {
            $('.alert').fadeOut('slow');
        }, 5000);
    </script>
    
    <script>
        $('.formulario-eliminar').submit(function(e) {
            e.preventDefault();
            Swal.fire({
                title: '<?php echo e(__('Are you sure?')); ?>',
                text: '<?php echo e(__('All records will be related to this user will be deleted. This action is irreversible.')); ?>',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: '<?php echo e(__('Yes I agree!')); ?>',
                cancelButtonText: '<?php echo e(__('Cancel')); ?>'
            }).then((result) => {
                if (result.isConfirmed) {
                    this.submit();
                }
            })
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>