<?php $__env->startSection('content'); ?>
    <?php if(session('mensaje')): ?>
        <div class="alert btn alert-success">
            <?php echo e(session('mensaje')); ?>

        </div>
    <?php endif; ?>

    <div class="card bg-black border border-danger">
        <div class="card-header border border-danger">
            <a class="btn btn-dark" href="<?php echo e(route('events.show', $evento->id)); ?>">
                <?php echo e(__('Event')); ?>

            </a>
            <?php if($evento->mcontrol_id == Auth::user()->id): ?>
                <?php if(count($duelos) <= 150 && $evento->mcontrol_id == Auth::user()->id): ?>
                    <button type="button" class="btn btn-dark" data-bs-toggle="modal" data-bs-target="#AddDeal">
                        <?php echo e(__('Add Deal')); ?>

                    </button>
                    <?php if($errors->has('fcc') || $errors->has('scc ')): ?>
                        <span class="alert fs-6 text-danger" id="Message">
                            <?php echo e(__('Change the tapes.')); ?>

                        </span>
                    <?php endif; ?>
                    <?php if($errors->has('pmascota_id') || $errors->has('smascota_id')): ?>
                        <span class="alert fs-6 text-danger" id="Message">
                            <?php echo e(__('The pets must be different.')); ?>

                        </span>
                    <?php endif; ?>
                <?php endif; ?>
                <?php if(session('mensaje')): ?>
                    <span class="alert fs-6 text-danger">
                        <?php echo e(session('mensaje')); ?>

                    </span>
                <?php endif; ?>
            <?php endif; ?>
        </div>
        <div class="card-body table-responsive border border-danger">
            <table id="datatable" class="table table-dark table-hover nowrap" style="width:100%">
                <thead class="text-center">
                    <tr>
                        <th class="text-uppercase"><?php echo e(__('Shed')); ?></th>
                        <th class="text-uppercase"><?php echo e(__('Pet')); ?> 1</th>
                        <th></th>
                        <th class="text-uppercase"><?php echo e(__('Pet')); ?> 2</th>
                        <th class="text-uppercase"><?php echo e(__('Shed')); ?></th>
                        <th class="text-uppercase"><?php echo e(__('Time')); ?></th>
                        <th class="text-uppercase"><?php echo e(__('Result')); ?></th>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('sentence')): ?>
                            <th></th>
                        <?php endif; ?>
                    </tr>
                </thead>
                <tbody class="text-center">
                    <?php $__currentLoopData = $duelos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $duel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($duel->pmascota->user->galpon); ?></td>
                            <td><?php echo e($duel->pmascota->nombre); ?></td>
                            <td><button type="button" class="btn btn-danger" data-bs-toggle="modal"
                                    data-bs-target="#VS<?php echo e($duel->id); ?>">
                                    <?php echo e(__('Deal')); ?>

                                </button>
                                <!-- Modal VS-->
                                <div class="modal fade" id="VS<?php echo e($duel->id); ?>" tabindex="-1">
                                    <div class="modal-dialog modal-dialog-centered modal-xl">
                                        <div class="modal-content bg-black border border-danger text-white">
                                            <div class="modal-header border-danger">
                                                <div class="justify-content-between">
                                                    <a class="btn btn-primary" onclick="window.print();">
                                                        <?php echo e(__('Print')); ?>

                                                    </a>
                                                    <label class="btn btn-primary">
                                                        <?php echo e(__('Fight')); ?>: <?php echo e($duel->npelea); ?>

                                                    </label>
                                                    <label class="btn btn-primary">
                                                        <?php echo e(__('Field')); ?>: <?php echo e($duel->cch); ?>

                                                    </label>
                                                    <label class="btn btn-primary">
                                                        <?php echo e(__('Accordance')); ?>: <?php echo e($duel->pactada); ?>

                                                    </label>
                                                </div>
                                                <button type="button" class="btn btn-danger bg-danger btn-close"
                                                    data-bs-dismiss="modal" aria-label="Close"></button>
                                            </div>
                                            <div class="modal-body">
                                                <div class="row row-cols-2 g-2">
                                                    
                                                    <div class="col-6">
                                                        <div class="card-body card bg-black border border-danger">
                                                            <div class="col-sm-6 mx-auto my-2">
                                                                <figure class="figure">
                                                                    <img src="<?php if(!empty($duel->pmascota->fotos->where('nfoto', 1)->first())): ?> <?php echo e(asset($duel->pmascota->fotos->where('nfoto', 1)->first()->ruta)); ?> <?php else: ?><?php echo e(asset('storage/img/pata.jpg')); ?> <?php endif; ?>"
                                                                        class="figure-img d-block mx-auto" width="120"
                                                                        height="140">
                                                                </figure>
                                                            </div>
                                                            <div class="row">
                                                                <div class="col-sm-6 mb-3">
                                                                    <label class="form-label fw-bold">
                                                                        <?php echo e(__('REGANI')); ?>

                                                                    </label>
                                                                    <div class="col-auto">
                                                                        <input value="<?php echo e($duel->pmascota->REGANI); ?>"
                                                                            class="form-control text-danger" readonly>
                                                                    </div>
                                                                </div>
                                                                <div class="col-sm-6 mb-3">
                                                                    <label class="form-label fw-bold">
                                                                        <?php echo e(__('Galpon')); ?>

                                                                    </label>
                                                                    <div class="col-auto">
                                                                        <input
                                                                            value="<?php echo e($duel->pmascota->user->galpon); ?>"
                                                                            class="form-control text-danger" readonly>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="row">
                                                                <div class="col-sm-4 mb-3">
                                                                    <label class="form-label fw-bold">
                                                                        <?php echo e(__('Color')); ?>

                                                                    </label>
                                                                    <div class="col-auto">
                                                                        <input value="<?php echo e($duel->pmascota->plu); ?>"
                                                                            class="form-control text-danger" readonly>
                                                                    </div>
                                                                </div>
                                                                <div class="col-sm-4 mb-3">
                                                                    <label class="form-label fw-bold">
                                                                        <?php echo e(__('Weight')); ?>

                                                                    </label>
                                                                    <div class="col-auto">
                                                                        <input value="<?php echo e($duel->pmascota->sss); ?>"
                                                                            class="form-control text-danger" readonly>
                                                                    </div>
                                                                </div>
                                                                <div class="col-sm-4 mb-3">
                                                                    <label class="form-label fw-bold">
                                                                        <?php echo e(__('Cinta')); ?>

                                                                    </label>
                                                                    <div class="col-auto">
                                                                        <input value="<?php echo e($duel->fcc); ?>"
                                                                            class="form-control text-danger" readonly>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="row">
                                                                <div class="col-sm-6 mb-3">
                                                                    <label class="form-label fw-bold">
                                                                        <?php echo e(__('Country')); ?>

                                                                    </label>
                                                                    <div class="col-auto">
                                                                        <input
                                                                            value="<?php echo e($duel->pmascota->user->country); ?>"
                                                                            class="form-control text-danger" readonly>
                                                                    </div>
                                                                </div>
                                                                <div class="col-sm-6 mb-3">
                                                                    <label class="form-label fw-bold">
                                                                        <?php echo e(__('State')); ?>

                                                                    </label>
                                                                    <div class="col-auto">
                                                                        <input value="<?php echo e($duel->pmascota->user->state); ?>"
                                                                            class="form-control text-danger" readonly>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="row">
                                                                <div class="col-sm-6 mb-3">
                                                                    <label class="form-label fw-bold">
                                                                        <?php echo e(__('Disability')); ?>

                                                                    </label>
                                                                    <div class="col-auto">
                                                                        <select class="form-control text-danger"
                                                                            value="<?php echo e($duel->pmascota->des); ?>" disabled>
                                                                            <option
                                                                                <?php if($duel->pmascota->des == '0'): ?> selected <?php endif; ?>>
                                                                                <?php echo e(__('No')); ?></option>
                                                                            <option
                                                                                <?php if($duel->pmascota->des == '1'): ?> selected <?php endif; ?>>
                                                                                <?php echo e(__('Visual')); ?></option>
                                                                            <option
                                                                                <?php if($duel->pmascota->des == '2'): ?> selected <?php endif; ?>>
                                                                                <?php echo e(__('Physical')); ?></option>
                                                                            <option
                                                                                <?php if($duel->pmascota->des == '3'): ?> selected <?php endif; ?>>
                                                                                <?php echo e(__('Other')); ?></option>
                                                                        </select>
                                                                    </div>
                                                                </div>
                                                                <div class="col-sm-6 mb-3">
                                                                    <label class="form-label fw-bold">
                                                                        <?php echo e(__('Seal')); ?>

                                                                    </label>
                                                                    <div class="col-auto">
                                                                        <input value="<?php echo e($duel->pmascota->seal); ?>"
                                                                            class="form-control text-danger" readonly>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    
                                                    <div class="col-6">
                                                        <div class="card-body bg-black border border-danger">
                                                            <div class="col-sm-6 mx-auto my-2">
                                                                <figure class="figure">
                                                                    <img src="<?php if(!empty($duel->smascota->fotos->where('nfoto', 1)->first())): ?> <?php echo e(asset($duel->smascota->fotos->where('nfoto', 1)->first()->ruta)); ?> <?php else: ?><?php echo e(asset('storage/img/pata.jpg')); ?> <?php endif; ?>"
                                                                        class="figure-img d-block mx-auto" width="120"
                                                                        height="140">
                                                                </figure>
                                                            </div>
                                                            <div class="row">
                                                                <div class="col-sm-6 mb-3">
                                                                    <label class="form-label fw-bold">
                                                                        <?php echo e(__('REGANI')); ?>

                                                                    </label>
                                                                    <div class="col-auto">
                                                                        <input value="<?php echo e($duel->smascota->REGANI); ?>"
                                                                            class="form-control text-danger" readonly>
                                                                    </div>
                                                                </div>
                                                                <div class="col-sm-6 mb-3">
                                                                    <label class="form-label fw-bold">
                                                                        <?php echo e(__('Galpon')); ?>

                                                                    </label>
                                                                    <div class="col-auto">
                                                                        <input
                                                                            value="<?php echo e($duel->smascota->user->galpon); ?>"
                                                                            class="form-control text-danger" readonly>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="row">
                                                                <div class="col-sm-4 mb-3">
                                                                    <label class="form-label fw-bold">
                                                                        <?php echo e(__('Colour')); ?>

                                                                    </label>
                                                                    <div class="col-auto">
                                                                        <input value="<?php echo e($duel->smascota->plu); ?>"
                                                                            class="form-control text-danger" readonly>
                                                                    </div>
                                                                </div>
                                                                <div class="col-sm-4 mb-3">
                                                                    <label class="form-label fw-bold">
                                                                        <?php echo e(__('Weight')); ?>

                                                                    </label>
                                                                    <div class="col-auto">
                                                                        <input value="<?php echo e($duel->smascota->sss); ?>"
                                                                            class="form-control text-danger" readonly>
                                                                    </div>
                                                                </div>
                                                                <div class="col-sm-4 mb-3">
                                                                    <label class="form-label fw-bold">
                                                                        <?php echo e(__('Cinta')); ?>

                                                                    </label>
                                                                    <div class="col-auto">
                                                                        <input value="<?php echo e($duel->scc); ?>"
                                                                            class="form-control text-danger" readonly>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="row">
                                                                <div class="col-sm-6 mb-3">
                                                                    <label class="form-label fw-bold">
                                                                        <?php echo e(__('Country')); ?>

                                                                    </label>
                                                                    <div class="col-auto">
                                                                        <input
                                                                            value="<?php echo e($duel->smascota->user->country); ?>"
                                                                            class="form-control text-danger" readonly>
                                                                    </div>
                                                                </div>
                                                                <div class="col-sm-6 mb-3">
                                                                    <label class="form-label fw-bold">
                                                                        <?php echo e(__('State')); ?>

                                                                    </label>
                                                                    <div class="col-auto">
                                                                        <input value="<?php echo e($duel->smascota->user->state); ?>"
                                                                            class="form-control text-danger" readonly>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="row">
                                                                <div class="col-sm-6 mb-3">
                                                                    <label class="form-label fw-bold">
                                                                        <?php echo e(__('Disability')); ?>

                                                                    </label>
                                                                    <div class="col-auto">
                                                                        <select class="form-control text-danger"
                                                                            value="<?php echo e($duel->smascota->des); ?>" disabled>
                                                                            <option
                                                                                <?php if($duel->smascota->des == '0'): ?> selected <?php endif; ?>>
                                                                                <?php echo e(__('No')); ?></option>
                                                                            <option
                                                                                <?php if($duel->smascota->des == '1'): ?> selected <?php endif; ?>>
                                                                                <?php echo e(__('Visual')); ?></option>
                                                                            <option
                                                                                <?php if($duel->smascota->des == '2'): ?> selected <?php endif; ?>>
                                                                                <?php echo e(__('Physical')); ?></option>
                                                                            <option
                                                                                <?php if($duel->smascota->des == '3'): ?> selected <?php endif; ?>>
                                                                                <?php echo e(__('Other')); ?></option>
                                                                        </select>
                                                                    </div>
                                                                </div>
                                                                <div class="col-sm-6 mb-3">
                                                                    <label class="form-label fw-bold">
                                                                        <?php echo e(__('Seal')); ?>

                                                                    </label>
                                                                    <div class="col-auto">
                                                                        <input value="<?php echo e($duel->smascota->seal); ?>"
                                                                            class="form-control text-danger" readonly>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </td>
                            <td><?php echo e($duel->smascota->nombre); ?></td>
                            <td><?php echo e($duel->smascota->user->galpon); ?></td>
                            <form class="text-uppercase" method="POST"
                                action="<?php echo e(route('pactados.update', $duel->id)); ?>">
                                <?php echo csrf_field(); ?>

                                <?php echo e(method_field('PUT')); ?>

                                <td>
                                    <div class="input-group mb-3">
                                        <input type="text" class="form-control" placeholder="00"
                                            value="<?php echo e($duel->dm); ?>" name="dm" <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->denies('sentence')): ?> readonly <?php endif; ?>>
                                        <span class="input-group-text">:</span>
                                        <input type="text" class="form-control" placeholder="00"
                                            value="<?php echo e($duel->ds); ?>" name="ds" <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->denies('sentence')): ?> readonly <?php endif; ?>>
                                    </div>
                                </td>
                                <td class="text-black fs-5 fw-bolder">
                                    <select name="result" class="form-control" <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->denies('sentence')): ?> disabled <?php endif; ?>>
                                        <option <?php if($duel->result == 'waiting'): ?> selected <?php endif; ?> value="waiting" hidden>
                                            <?php echo e(__('Waiting')); ?></option>
                                        <option <?php if($duel->result == $duel->pmascota->id): ?> selected <?php endif; ?>
                                            value="<?php echo e($duel->pmascota->id); ?>">
                                            <?php echo e($duel->pmascota->nombre); ?>

                                        </option>
                                        <option <?php if($duel->result == $duel->smascota->id): ?> selected <?php endif; ?>
                                            value="<?php echo e($duel->smascota->id); ?>"><?php echo e($duel->smascota->nombre); ?>

                                        </option>
                                        <option <?php if($duel->result == 'draw'): ?> selected <?php endif; ?> value="draw">
                                            <?php echo e(__('Draw')); ?></option>
                                    </select>
                                </td>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('sentence')): ?>
                                    <td><input type="submit" class="btn btn-success" value="<?php echo e(__('sentence')); ?>"></td>
                                <?php endif; ?>
                            </form>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- MODAL ADD -->
    <div class="modal fade" id="AddDeal" aria-hidden="true" aria-labelledby="AddDeal" tabindex="-1">
        <div class="modal-dialog modal-xl">
            <div class="modal-content bg-black border border-danger">
                <div class="modal-header border border-danger">
                    <div class="modal-title fw-bold text-uppercase"><?php echo e(__('Choose pets')); ?></div>
                    <button type="button" class="btn btn-danger bg-danger btn-close" data-bs-dismiss="modal"
                        aria-label="Close"></button>
                </div>
                <form class="text-uppercase" method="POST" action="<?php echo e(route('pactados.store')); ?>">
                    <?php echo csrf_field(); ?>

                    
                    <input type="text" id="evento_id" name="evento_id" value="<?php echo e($evento->id); ?>" hidden>

                    <div class="modal-body border border-danger">
                        <div class="row">
                            
                            <div class="col-lg-5 m-auto border border-danger">
                                
                                <div class="mb-3">
                                    <label class="form-label">MASCOTA 1:</label>
                                    <select class="form-select" id="pmascota_id" name="pmascota_id"
                                        value="<?php echo e(old('pmascota_id')); ?>" required>
                                        <option value="" selected disabled>Seleccionar mascota</option>
                                        <?php $__currentLoopData = $participantes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $participante): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option class="text-black" value="<?php echo e($participante->mascota->id); ?>"
                                                <?php if(old('pmascota_id') == $participante->mascota->id): ?> selected <?php endif; ?>>
                                                <?php echo e($participante->mascota->nombre); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="mb-3">
                                    <div class="row">
                                        <div class="col-sm-7">
                                            <label class="form-label fw-bold">
                                                <?php echo e(__('REGANI')); ?>

                                            </label>
                                            <div class="col-auto">
                                                <input id="REGANI" type="text" class="form-control text-danger" readonly>
                                            </div>
                                        </div>

                                        <div class="col-sm-5">
                                            <label for="fcc" class="form-label fw-bold">
                                                <?php echo e(__('Cinta')); ?>

                                            </label>
                                            <div class="col-auto">
                                                <select name="fcc" id="fcc" class="form-select text-danger" required
                                                    autofocus>
                                                    <option value="" hidden></option>
                                                    <option value="Roja"
                                                        <?php if(old('fcc') == 'Roja'): ?> selected <?php endif; ?>>
                                                        Roja</option>
                                                    <option value="Blanca"
                                                        <?php if(old('fcc') == 'Blanca'): ?> selected <?php endif; ?>>Blanca</option>
                                                    <option value="Amarilla"
                                                        <?php if(old('fcc') == 'Amarilla'): ?> selected <?php endif; ?>>
                                                        Amarilla</option>
                                                    <option value="Azul"
                                                        <?php if(old('fcc') == 'Azul'): ?> selected <?php endif; ?>>
                                                        Azul</option>
                                                    <option value="Negra"
                                                        <?php if(old('fcc') == 'Negra'): ?> selected <?php endif; ?>>Negra</option>
                                                    <option value="Verde"
                                                        <?php if(old('fcc') == 'Verde'): ?> selected <?php endif; ?>>
                                                        Verde</option>
                                                    <option value="Gris"
                                                        <?php if(old('fcc') == 'Gris'): ?> selected <?php endif; ?>>Gris</option>
                                                </select>
                                                <?php if($errors->has('fcc')): ?>
                                                    <span class="text-danger text-fs6">
                                                        Elija otra cinta
                                                    </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="mb-3">
                                    <div class="row">
                                        <div class="col-sm-6">
                                            <label for="plu" class="form-label fw-bold">
                                                <?php echo e(__('Color')); ?>

                                            </label>
                                            <div class="col-auto">
                                                <input id="plu" type="text" class="form-control text-danger" readonly>
                                            </div>
                                        </div>
                                        <div class="col-sm-6">
                                            <label for="sss" class="form-label fw-bold">
                                                <?php echo e(__('Weight')); ?>

                                            </label>
                                            <div class="col-auto">
                                                <input id="sss" type="text" class="form-control text-danger" readonly>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="mb-3">
                                    <div class="row">
                                        <div class="col-sm-6">
                                            <label for="des" class="form-label fw-bold">
                                                <?php echo e(__('Disability')); ?>

                                            </label>
                                            <div class="col-auto">
                                                <input id="des" type="text" class="form-control text-danger" value=""
                                                    readonly>
                                            </div>
                                        </div>
                                        <div class="col-sm-6">
                                            <label for="seal" class="form-label fw-bold">
                                                <?php echo e(__('Seal')); ?>

                                            </label>
                                            <div class="col-auto">
                                                <input id="seal" type="text" class="form-control text-danger" readonly>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="col-lg-5 m-auto border border-danger">
                                
                                <div class="mb-3">
                                    <label class="form-label">MASCOTA 2:</label>
                                    <select class="form-select" id="smascota_id" name="smascota_id"
                                        value="<?php echo e(old('smascota_id')); ?>" required>
                                        <option value="" selected disabled>Seleccionar mascota</option>
                                        <?php $__currentLoopData = $participantes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $participante): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option class="text-black" value="<?php echo e($participante->mascota->id); ?>"
                                                <?php if(old('smascota_id') == $participante->mascota->id): ?> selected <?php endif; ?>>
                                                <?php echo e($participante->mascota->nombre); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="mb-3">
                                    <div class="row">
                                        <div class="col-sm-7">
                                            <label class="form-label fw-bold">
                                                <?php echo e(__('REGANI')); ?>

                                            </label>
                                            <div class="col-auto">
                                                <input id="PREGANI" type="text" class="form-control text-danger" readonly>
                                            </div>
                                        </div>
                                        <div class="col-sm-5">
                                            <label for="scc" class="form-label fw-bold">
                                                <?php echo e(__('Cinta')); ?>

                                            </label>
                                            <div class="col-auto">
                                                <select name="scc" id="scc" class="form-select text-danger" required
                                                    autofocus>
                                                    <option value="" hidden></option>
                                                    <option value="Roja"
                                                        <?php if(old('fcc') == 'Roja'): ?> selected <?php endif; ?>>
                                                        Roja</option>
                                                    <option value="Blanca"
                                                        <?php if(old('fcc') == 'Blanca'): ?> selected <?php endif; ?>>Blanca</option>
                                                    <option value="Amarilla"
                                                        <?php if(old('fcc') == 'Amarilla'): ?> selected <?php endif; ?>>
                                                        Amarilla</option>
                                                    <option value="Azul"
                                                        <?php if(old('fcc') == 'Azul'): ?> selected <?php endif; ?>>
                                                        Azul</option>
                                                    <option value="Negra"
                                                        <?php if(old('fcc') == 'Negra'): ?> selected <?php endif; ?>>Negra</option>

                                                    <option value="Verde"
                                                        <?php if(old('fcc') == 'Verde'): ?> selected <?php endif; ?>>
                                                        Verde</option>
                                                    <option value="Gris"
                                                        <?php if(old('fcc') == 'Gris'): ?> selected <?php endif; ?>>Gris</option>
                                                </select>
                                                <?php if($errors->has('scc')): ?>
                                                    <span class="text-danger text-fs6">
                                                        Elija otra cinta
                                                    </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="mb-3">
                                    <div class="row">
                                        <div class="col-sm-6">
                                            <label for="pplu" class="form-label fw-bold">
                                                <?php echo e(__('Color')); ?>

                                            </label>
                                            <div class="col-auto">
                                                <input id="pplu" type="text" class="form-control text-danger" readonly>
                                            </div>
                                        </div>
                                        <div class="col-sm-6">
                                            <label for="psss" class="form-label fw-bold">
                                                <?php echo e(__('Weight')); ?>

                                            </label>
                                            <div class="col-auto">
                                                <input id="psss" type="text" class="form-control text-danger" readonly>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="mb-3">
                                    <div class="row">
                                        <div class="col-sm-6">
                                            <label for="pdes" class="form-label fw-bold">
                                                <?php echo e(__('Disability')); ?>

                                            </label>
                                            <div class="col-auto">
                                                <input id="pdes" type="text" class="form-control text-danger" readonly>
                                            </div>
                                        </div>
                                        <div class="col-sm-6">
                                            <label for="pseal" class="form-label fw-bold">
                                                <?php echo e(__('Seal')); ?>

                                            </label>
                                            <div class="col-auto">
                                                <input id="pseal" type="text" class="form-control text-danger" readonly>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="w-50 mx-auto mt-1">
                            <div class="row">
                                <div class="col-sm-4 mx-auto">
                                    <label for="pmad" class="form-label fw-bold">
                                        <?php echo e(__('Accordance')); ?>

                                    </label>
                                    <div class="col-auto">
                                        <input type="number" class="form-control text-danger" name="pactada"
                                            onKeyPress="if(this.value.length==4) return false;" required
                                            onkeydown="return event.keyCode !== 69 && event.keyCode !== 189" min="0"
                                            value="<?php echo e(old('pactada')); ?>" placeholder="0000">
                                    </div>
                                </div>
                                <div class="col-sm-4 mx-auto">
                                    <label for="pmad" class="form-label fw-bold">
                                        <?php echo e(__('Field')); ?>

                                    </label>
                                    <div class="col-auto">
                                        <select name="cch" id="cch" class="form-select text-danger" required autofocus>
                                            <option value="" hidden></option>
                                            <option value="A" <?php if(old('cch') == 'A'): ?> selected <?php endif; ?>>A</option>
                                            <option value="B" <?php if(old('cch') == 'B'): ?> selected <?php endif; ?>>B</option>
                                        </select>
                                    </div>
                                </div>
                                
                                <div class="col-sm-4 mx-auto">
                                    <label for="npelea" class="form-label fw-bold">
                                        <?php echo e(__('Fight')); ?>

                                    </label>
                                    <div class="col-auto">
                                        <input id="npelea" name="npelea" type="text" class="form-control text-danger"
                                            value="<?php echo e(count($duelos) + 1); ?>" readonly>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer bg-black border-top border-danger">
                        <a class="btn btn-primary mx-auto" onclick="window.print();">
                            <?php echo e(__('Print')); ?>

                        </a>
                        <input type="submit" class="btn btn-primary mx-auto" value="<?php echo e(__('Add Deal')); ?>">
                    </div>
                </form>
            </div>
        </div>
    </div>


    
    <link rel="stylesheet" href="<?php echo e(asset('css/datatable/dataTables.bootstrap5.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/datatable/buttons.dataTables.min.css')); ?>">
    
    <script src="<?php echo e(asset('js/datatable/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/datatable/dataTables.bootstrap5.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/datatable/dataTables.buttons.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/ajax/jszip.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/ajax/pdfmake.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/ajax/vfs_fonts.js')); ?>"></script>
    <script src="<?php echo e(asset('js/datatable/buttons.html5.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/datatable/buttons.print.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/datatable/buttons.print.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/datatable/sorting/date-eu.js')); ?>"></script>

    
    
    <script>
        $(document).ready(function() {
            function getLanguage() {
                var lang = $('html').attr('lang');
                if (lang == 'es') {
                    lng = "es-ES";
                } else if (lang == 'en') {
                    lng = "en-GB";
                }
                var result = null;
                var path = 'https://cdn.datatables.net/plug-ins/1.11.5/i18n/';
                result = path + lng + ".json";
                return result;
            }
            // Build Datatable
            $('#datatable').DataTable({
                language: {
                    "url": getLanguage()
                },
                bInfo: false,
                lengthChange: false,
                pageLength: 10,
                lengthMenu: [
                    [10],
                    [10]
                ]
            });
        });
        /*  MASCOTA */
        function displayVals1() {
            var id = $('#pmascota_id').val();
            $.ajax({
                type: 'GET', //THIS NEEDS TO BE GET
                url: '/participants/' + id,
                dataType: 'json',
                success: function(data) {
                    console.log(data);
                    $.each(data, function(i, item) {
                        $("#REGANI").val(item.REGANI);
                        $("#plu").val(item.plu);
                        $("#sss").val(item.sss);
                        $("#country").val(item.country);
                        $("#state").val(item.state);
                        $("#des").val(item.des);
                        $("#seal").val(item.seal);
                        $("#pad").val(item.pad);
                        $("#mad").val(item.mad);
                    });
                },
                error: function() {
                    console.log(data);
                }
            });
        }
        $("#pmascota_id").change(displayVals1);

        /* MASCOTA 2 */
        function displayVals2() {
            var id = $('#smascota_id').val();
            $.ajax({
                type: 'GET', //THIS NEEDS TO BE GET
                url: '/participants/' + id,
                dataType: 'json',
                success: function(data) {
                    console.log(data);
                    $.each(data, function(i, item) {
                        $("#PREGANI").val(item.REGANI);
                        $("#pplu").val(item.plu);
                        $("#psss").val(item.sss);
                        $("#pcountry").val(item.country);
                        $("#pstate").val(item.state);
                        $("#pdes").val(item.des);
                        $("#pseal").val(item.seal);
                        $("#ppad").val(item.pad);
                        $("#pmad").val(item.mad);
                    });
                },
                error: function() {
                    console.log(data);
                }
            });
        }
        $("#smascota_id").change(displayVals2);

        /*  DONT COPY OR PASTE*/
        $(document).ready(function() {
            $('input').bind('copy paste', function(e) {
                e.preventDefault();
            });
        });
        //HIDE
        setTimeout(function() {
            $('.alert').fadeOut(2000);
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>