<?php $__env->startSection('title'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Mantenimiento de Eventos</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="table-responsive">
        <table id="datatable" class="table table-hover nowrap" style="width:100%">
            <thead>
                <tr>
                    <th><?php echo e(__('Date')); ?></th>
                    <th><?php echo e(__('Coliseum')); ?></th>
                    <th><?php echo e(__('Organizer')); ?></th>
                    <th><?php echo e(__('Control desk')); ?></th>
                    <th><?php echo e(__('Judge')); ?></th>
                    <th><?php echo e(__('Assistant')); ?></th>
                    <th><?php echo e(__('Awards')); ?></th>
                    <th><?php echo e(__('Status')); ?></th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $eventos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $evento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($evento->fechas[0]); ?></td>
                        <td><?php echo e($evento->coliseum->nombre); ?></td>
                        <td><?php echo e($evento->organizador->nombre . ' ' . $evento->organizador->apellido); ?></td>
                        <td><?php echo e($evento->mcontrol->nombre . ' ' . $evento->mcontrol->apellido); ?></td>
                        <td><?php echo e($evento->judge->nombre . ' ' . $evento->judge->apellido); ?></td>
                        <td><?php echo e($evento->assistent->nombre . ' ' . $evento->assistent->apellido); ?></td>
                        <td><?php echo e($evento->awards); ?></td>
                        <td>
                            <?php if($evento->status == 0): ?>
                                <span class="btn btn-primary"><?php echo e(__('Inactived')); ?></span>
                            <?php elseif($evento->status == 1): ?>
                                <span class="btn btn-success"><?php echo e(__('Actived')); ?></span>
                            <?php elseif($evento->status == 2): ?>
                                <span class="btn btn-warning"><?php echo e(__('Suspended')); ?></span>
                            <?php endif; ?>
                        </td>
                        <td><a href="<?php echo e(route('meventos.edit', $evento->id)); ?>"><?php echo e(__('View')); ?></a></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
            <tfoot>
                <tr>
                    <th><?php echo e(__('Date')); ?></th>
                    <th><?php echo e(__('Coliseum')); ?></th>
                    <th><?php echo e(__('Organizer')); ?></th>
                    <th><?php echo e(__('Control desk')); ?></th>
                    <th><?php echo e(__('Judge')); ?></th>
                    <th><?php echo e(__('Assistant')); ?></th>
                    <th><?php echo e(__('Awards')); ?></th>
                    <th><?php echo e(__('Status')); ?></th>
                    <th></th>
                </tr>
            </tfoot>
        </table>
    </div>
    
    <script type="text/javascript">
        $(document).ready(function() {
            function getLanguage() {
                var lang = $('html').attr('lang');
                if (lang == 'es') {
                    lng = "es-ES";
                } else if (lang == 'en') {
                    lng = "en-GB";
                }
                var result = null;
                var path = 'https://cdn.datatables.net/plug-ins/1.11.5/i18n/';
                result = path + lng + ".json";
                return result;
            }
            // Build Datatable
            $('#datatable').DataTable({
                language: {
                    "url": getLanguage()
                }
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.datatable', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('adminlte::page', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>