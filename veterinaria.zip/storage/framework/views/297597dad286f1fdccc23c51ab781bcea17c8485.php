<?php $__env->startSection('content'); ?>
    <div class="card mx-auto bg-black border border-danger">
        <div class="card-header fs-4 border border-danger">
            <?php echo e(__('Add Exemplar')); ?>

        </div>
        <div class="card-body border border-danger">
            <form class="form-horizontal" method="POST" action="<?php echo e(route('mascotas.store')); ?>"
                enctype="multipart/form-data" autocomplete="off">
                <?php echo csrf_field(); ?>

                
                <input id="user_id" type="text" name="user_id" value="<?php echo e(Auth::user()->id); ?>" hidden>
                <div class="card bg-black border border-danger">
                    <div class="card-body border border-danger">
                        
                        <div class="row">
                            <div class="row col-lg-8">
                                
                                <div
                                    class="col-6 col-md-4 mb-3 form-group<?php echo e($errors->has('nombre') ? ' has-error' : ''); ?>">
                                    <label for="nombre" class="col-form-label fw-bold">
                                        <?php echo e(__('Name')); ?>

                                    </label>
                                    <div class="col-auto">
                                        <input id="nombre" type="text" class="form-control text-danger" name="nombre"
                                            value="<?php echo e(old('nombre')); ?>" maxlength="18" required autofocus}>

                                        <?php if($errors->has('nombre')): ?>
                                            <span class="text-danger text-fs6">
                                                <?php echo e($errors->first('nombre')); ?>

                                            </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                
                                <div
                                    class="col-6 col-md-4 mb-3 form-group<?php echo e($errors->has('gender') ? ' has-error' : ''); ?>">
                                    <label for="gender" class="col-form-label fw-bold text-capitalize">
                                        <?php echo e(__('gender')); ?>

                                    </label>
                                    <div class="col-auto">
                                        <select id="gender" name="gender" class="form-select text-capitalize text-danger">
                                            <option value="male" <?php if(old('gender') == 'male'): ?> selected <?php endif; ?>>
                                                <?php echo e(__('male')); ?></option>
                                            <option value="female" <?php if(old('gender') == 'female'): ?> selected <?php endif; ?>>
                                                <?php echo e(__('female')); ?></option>
                                        </select>
                                        <?php if($errors->has('gender')): ?>
                                            <span class="text-danger text-fs6">
                                                <?php echo e($errors->first('gender')); ?>

                                            </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                
                                <div
                                    class="col-6 col-md-4 mb-3 form-group<?php echo e($errors->has('fnac') ? ' has-error' : ''); ?>">
                                    <label for="fnac" class="col-form-label fw-bold">
                                        <?php echo e(__('Birthday')); ?>

                                    </label>
                                    <div class="col-auto">
                                        <input id="fnac" type="date" class="form-control text-danger" name="fnac"
                                            value="<?php echo e(old('fnac')); ?>" required autofocus
                                            max="<?php echo e(\Carbon\Carbon::now()->format('Y-m-d')); ?>">
                                        <?php if($errors->has('fnac')): ?>
                                            <span class="text-danger text-fs6">
                                                <?php echo e($errors->first('fnac')); ?>

                                            </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                
                                <div
                                    class="col-6 col-md-4 mb-3 form-group<?php echo e($errors->has('size') ? ' has-error' : ''); ?>">
                                    <label for="size" class="col-form-label fw-bold">
                                        <?php echo e(__('Size')); ?>

                                    </label>
                                    <div class="col-auto">
                                        <select class="form-select text-danger" name="size" value="<?php echo e(old('size')); ?>">
                                            <option value="smll" <?php if(old('size')): ?> selected <?php endif; ?>>
                                                <?php echo e(__('Small')); ?></option>
                                            <option value="mdm" <?php if(old('size')): ?> selected <?php endif; ?>>
                                                <?php echo e(__('Medium')); ?></option>
                                            <option value="lrg" <?php if(old('size')): ?> selected <?php endif; ?>>
                                                <?php echo e(__('Large')); ?></option>
                                        </select>
                                        <?php if($errors->has('size')): ?>
                                            <span class="text-danger text-fs6">
                                                <?php echo e($errors->first('size')); ?>

                                            </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                
                                
                                <div class="col-6 col-md-4 mb-3 form-group<?php echo e($errors->has('plc') ? ' has-error' : ''); ?>">
                                    <label for="plc" class="col-form-label fw-bold">
                                        <?php echo e(__('Seal')); ?>

                                    </label>
                                    <div class="col-auto">
                                        <input id="plc" type="number" class="form-control text-danger" name="plc"
                                            value="<?php echo e(old('plc')); ?>" required autofocus
                                            onKeyPress="if(this.value.length==6) return false;"
                                            onkeydown="return event.keyCode !== 69 && event.keyCode !== 189" min="0">

                                        <?php if($errors->has('plc')): ?>
                                            <span class="text-danger text-fs6">
                                                <?php echo e($errors->first('plc')); ?>

                                            </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                
                                <div class="col-6 col-md-4 mb-3 form-group<?php echo e($errors->has('lck') ? ' has-error' : ''); ?>">
                                    <label for="lck" class="col-form-label fw-bold">
                                        <?php echo e(__('Locker')); ?>

                                    </label>
                                    <div class="col-auto">
                                        <input id="lck" type="number" class="form-control text-danger" name="lck"
                                            value="<?php echo e(old('lck')); ?>" required autofocus
                                            onKeyPress="if(this.value.length==3) return false;"
                                            onkeydown="return event.keyCode !== 69 && event.keyCode !== 189" min="0">

                                        <?php if($errors->has('lck')): ?>
                                            <span class="text-danger text-fs6">
                                                <?php echo e($errors->first('lck')); ?>

                                            </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                
                                <div class="col-12 mb-3 form-group<?php echo e($errors->has('plu') ? ' has-error' : ''); ?>">
                                    <label for="plu" class="col-form-label fw-bold">
                                        <?php echo e(__('Colour')); ?>

                                    </label>
                                    <div class="col-auto">
                                        <input id="plu" type="text" class="form-control text-danger" name="plu"
                                            value="<?php echo e(old('plu')); ?>" required autofocus maxlength="18">

                                        <?php if($errors->has('plu')): ?>
                                            <span class="text-danger text-fs6">
                                                <?php echo e($errors->first('plu')); ?>

                                            </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                
                                
                                <div class="col-6 mb-3 form-group<?php echo e($errors->has('pad') ? ' has-error' : ''); ?>">
                                    <label for="pad" class="col-form-label fw-bold">
                                        <?php echo e(__('Father')); ?>

                                    </label>
                                    <div class="col-auto">
                                        <select class="select2 form-select" name="pad" autofocus>
                                            <option selected value="">
                                                <?php echo e(__('Choose exemplar')); ?>...
                                            </option>
                                            <?php $__currentLoopData = $mascotas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mascota): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option <?php if(old('pad') == $mascota->id): ?> selected <?php endif; ?>
                                                    value="<?php echo e($mascota->id); ?>"><?php echo e($mascota->nombre); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <?php if($errors->has('pad')): ?>
                                            <span class="text-danger text-fs6">
                                                <?php echo e($errors->first('pad')); ?>

                                            </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                
                                <div class="col-6 mb-3 form-group<?php echo e($errors->has('mad') ? ' has-error' : ''); ?>">
                                    <label for="mad" class="col-form-label fw-bold">
                                        <?php echo e(__('Mother')); ?>

                                    </label>
                                    <div class="col-auto">
                                        <select class="select2 form-select" name="mad" autofocus>
                                            <option selected value="">
                                                <?php echo e(__('Choose exemplar')); ?>...
                                            </option>
                                            <?php $__currentLoopData = $mascotas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mascota): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option <?php if(old('mad') == $mascota->id): ?> selected <?php endif; ?>
                                                    value="<?php echo e($mascota->id); ?>"><?php echo e($mascota->nombre); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <?php if($errors->has('mad')): ?>
                                            <span class="text-danger text-fs6">
                                                <?php echo e($errors->first('mad')); ?>

                                            </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                
                                <div class="col-6 mb-3 form-group<?php echo e($errors->has('des') ? ' has-error' : ''); ?>">
                                    <label for="des" class="col-form-label fw-bold">
                                        <?php echo e(__('Disability')); ?>

                                    </label>
                                    <div class="col-auto">
                                        <select class="form-select text-danger" id="des" name="des"
                                            value="<?php echo e(old('des')); ?>" required>
                                            <option value="0" <?php if(old('des') == '0'): ?> selected <?php endif; ?>>
                                                <?php echo e(__('No')); ?></option>
                                            <option value="1" <?php if(old('des') == '1'): ?> selected <?php endif; ?>>
                                                <?php echo e(__('Visual')); ?></option>
                                            <option value="2" <?php if(old('des') == '2'): ?> selected <?php endif; ?>>
                                                <?php echo e(__('Physical')); ?></option>
                                            <option value="3" <?php if(old('des') == '3'): ?> selected <?php endif; ?>>
                                                <?php echo e(__('Other')); ?></option>
                                        </select>

                                        <?php if($errors->has('des')): ?>
                                            <span class="text-danger text-fs6">
                                                <?php echo e($errors->first('des')); ?>

                                            </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                
                                <div class="col-6 mb-3 form-group<?php echo e($errors->has('sena') ? ' has-error' : ''); ?>">
                                    <label for="sena" class="col-form-label fw-bold">
                                        <?php echo e(__('SENASA')); ?>

                                    </label>
                                    <div class="col-auto">
                                        <input id="sena" type="text" class="form-control text-danger" name="sena"
                                            value="<?php echo e(old('sena')); ?>" autofocus maxlength="30">

                                        <?php if($errors->has('sena')): ?>
                                            <span class="text-danger text-fs6">
                                                <?php echo e($errors->first('sena')); ?>

                                            </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                
                                <div id="ficbc"
                                    class="col-6 mb-3 form-group<?php echo e($errors->has('icbc') ? ' has-error' : ''); ?>">
                                    <label for="icbc" class="col-form-label fw-bold">
                                        <?php echo e(__('Incubation')); ?>

                                    </label>
                                    <div class="col-auto">
                                        <input id="icbc" type="date" class="form-control text-danger" name="icbc"
                                            value="<?php echo e(old('icbc')); ?>" autofocus
                                            max="<?php echo e(\Carbon\Carbon::now()->format('Y-m-d')); ?>">

                                        <?php if($errors->has('icbc')): ?>
                                            <span class="text-danger text-fs6">
                                                <?php echo e($errors->first('icbc')); ?>

                                            </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                
                                <div id="fhvs"
                                    class="col-3 mb-3 form-group<?php echo e($errors->has('hvs') ? ' has-error' : ''); ?>">
                                    <label for="hvs" class="col-form-label fw-bold">
                                        <?php echo e(__('Eggs')); ?>

                                    </label>
                                    <div class="col-auto">
                                        <input id="hvs" type="number" class="form-control text-danger" name="hvs"
                                            value="<?php echo e(old('hvs')); ?>" autofocus
                                            onKeyPress="if(this.value.length==2) return false;"
                                            onkeydown="return event.keyCode !== 69 && event.keyCode !== 189" min="0">

                                        <?php if($errors->has('hvs')): ?>
                                            <span class="text-danger text-fs6">
                                                <?php echo e($errors->first('hvs')); ?>

                                            </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                
                                <div id="fncr"
                                    class="col-3 mb-3 form-group<?php echo e($errors->has('ncr') ? ' has-error' : ''); ?>">
                                    <label for="ncr" class="col-form-label fw-bold">
                                        <?php echo e(__('Born')); ?>

                                    </label>
                                    <div class="col-auto">
                                        <input id="ncr" type="number" class="form-control text-danger" name="ncr"
                                            value="<?php echo e(old('ncr')); ?>" autofocus
                                            onKeyPress="if(this.value.length==2) return false;"
                                            onkeydown="return event.keyCode !== 69 && event.keyCode !== 189" min="0">

                                        <?php if($errors->has('ncr')): ?>
                                            <span class="text-danger text-fs6">
                                                <?php echo e($errors->first('ncr')); ?>

                                            </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                
                                <div class="col-12 mb-3 form-group<?php echo e($errors->has('vcns') ? ' has-error' : ''); ?>">
                                    <label for="vcns" class="col-form-label fw-bold">
                                        <?php echo e(__('Vaccines')); ?>

                                    </label>
                                    <div class="col-auto">
                                        <input id="addvcns" type="button" class="btn btn-success" value="+">
                                        <input id="removevcns" type="button" class="btn btn-danger" value="-">
                                        <div class="form_vcns">
                                            <div class="row mt-3">
                                                <div class="col-6 col-md-3 mb-1">
                                                    <input id="vcnsf" type="date" class="form-control text-danger fw-bold"
                                                        name="vcnsf[]" max="<?php echo e(\Carbon\Carbon::now()->format('Y-m-d')); ?>"
                                                        required autofocus>
                                                </div>
                                                <div class="col-6 col-md-3 mb-1">
                                                    <input id="vcnst" type="text" class="form-control text-danger fw-bold"
                                                        name="vcnst[]" required autofocus placeholder="<?php echo e(__('Type')); ?>"
                                                        maxlength="5">
                                                </div>
                                                <div class="col-6 col-md-3 mb-1">
                                                    <input id="vcnsm" type="text" class="form-control text-danger fw-bold"
                                                        name="vcnsm[]" required autofocus placeholder="<?php echo e(__('Brand')); ?>"
                                                        maxlength="8">
                                                </div>
                                                <div class="col-6 col-md-3 mb-1">
                                                    <input id="vcnsd" type="text" class="form-control text-danger fw-bold"
                                                        name="vcnsd[]" required autofocus placeholder="<?php echo e(__('Dose')); ?>"
                                                        maxlength="2">
                                                </div>
                                            </div>
                                        </div>

                                        <?php if($errors->has('vcns')): ?>
                                            <span class="text-danger text-fs6">
                                                <?php echo e($errors->first('vcns')); ?>

                                            </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                
                                <div class="col-12 mb-3 form-group<?php echo e($errors->has('vcns') ? ' has-error' : ''); ?>">
                                    <label for="vcns" class="col-form-label fw-bold">
                                        <?php echo e(__('Moves')); ?>

                                    </label>
                                    <div class="col-auto">
                                        <div class="row">
                                            <div class="col-6 col-md-3 mb-1">
                                                <input type="date" class="form-control text-danger fw-bold" name="mvf"
                                                    required autofocus
                                                    max="<?php echo e(\Carbon\Carbon::now()->format('Y-m-d')); ?>">
                                            </div>
                                            <div class="col-6 col-md-3 mb-1">
                                                <div class="input-group">
                                                    <input type="number" class="form-control text-danger" name="mm"
                                                        onKeyPress="if(this.value.length==2) return false;" required
                                                        onkeydown="return event.keyCode !== 69 && event.keyCode !== 189"
                                                        min="0" max="59" value="<?php echo e(old('mm')); ?>" placeholder="00">
                                                    <div class="input-group-text">:</div>
                                                    <input type="number" class="form-control text-danger" name="ms"
                                                        onKeyPress="if(this.value.length==2) return false;" required
                                                        onkeydown="return event.keyCode !== 69 && event.keyCode !== 189"
                                                        min="0" max="59" value="<?php echo e(old('ms')); ?>" placeholder="00">
                                                </div>
                                            </div>
                                            <div class="col-6 col-md-3 mb-1">
                                                <input type="text" class="form-control text-danger fw-bold" name="mvtp"
                                                    required autofocus placeholder="<?php echo e(__('Type')); ?>" maxlength="8">
                                            </div>
                                            <div class="col-6 col-md-3 mb-1">
                                                <select name="mvr" class="form-select text-danger text-capitalize">
                                                    <option value="good"
                                                        <?php if(old('mvr') == 'good'): ?> ) selected <?php endif; ?>>
                                                        <?php echo e(__('good')); ?></option>
                                                    <option value="bad"
                                                        <?php if(old('mvr') == 'bad'): ?> ) selected <?php endif; ?>>
                                                        <?php echo e(__('bad')); ?></option>
                                                    <option value="regular"
                                                        <?php if(old('mvr') == 'regular'): ?> ) selected <?php endif; ?>>
                                                        <?php echo e(__('regular')); ?></option>
                                                </select>
                                            </div>
                                        </div>

                                        <?php if($errors->has('vcns')): ?>
                                            <span class="text-danger text-fs6">
                                                <?php echo e($errors->first('vcns')); ?>

                                            </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                
                                <div class="col-md-12 mb-3 form-group<?php echo e($errors->has('spmt') ? ' has-error' : ''); ?>">
                                    <label for="spmt" class="col-form-label fw-bold">
                                        <?php echo e(__('Supplement')); ?>

                                    </label>
                                    <div class="col-auto">
                                        <input id="spmt" class="form-control text-danger" name="spmt"
                                            value="<?php echo e(old('spmt')); ?>" maxlength="20" required autofocus>

                                        <?php if($errors->has('spmt')): ?>
                                            <span class="text-danger text-fs6">
                                                <?php echo e($errors->first('spmt')); ?>

                                            </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                
                                <div class="col-md-12 mb-3 form-group<?php echo e($errors->has('obs') ? ' has-error' : ''); ?>">
                                    <label for="obs" class="col-form-label fw-bold">
                                        <?php echo e(__('Observations')); ?>

                                    </label>
                                    <div class="col-auto">
                                        <textarea id="obs" class="form-control text-danger" name="obs" value="<?php echo e(old('obs')); ?>" rows="3" maxlength="200"
                                            required autofocus></textarea>
                                        <?php if($errors->has('obs')): ?>
                                            <span class="text-danger text-fs6">
                                                <?php echo e($errors->first('obs')); ?>

                                            </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-4 my-auto">
                                
                                <div class="col-md-12 mb-3 form-group<?php echo e($errors->has('foto') ? ' has-error' : ''); ?>">
                                    <label for="name" class="col-form-label fw-bold">
                                        <?php echo e(__('Photo Profile')); ?>

                                    </label>
                                    <div class="col-auto bg-dark rounded">
                                        <img id="preview" class="img-fluid mx-auto d-block bg-black"
                                            style="height: 70vh;" />
                                        <input id="foto" type="file" class="form-control text-danger form-control-md"
                                            name="foto" value="<?php echo e(old('foto')); ?>" required autofocus accept="image/*">
                                    </div>
                                    <?php if($errors->has('foto')): ?>
                                        <span class="text-danger fs-6">
                                            <?php echo e($errors->first('foto')); ?>

                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                        
                        <div class="mx-auto">
                            <button type="submit" class="btn btn-primary">
                                <?php echo e(__('Add Exemplar')); ?>

                            </button>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>

    
    <script>
        /* PASTE AND COPY */
        $(document).ready(function() {
            $('input').bind('copy paste', function(e) {
                e.preventDefault();
            });
        });

        /* FOTO */
        foto.onchange = evt => {
            const [file] = foto.files
            if (file) {
                preview.src = URL.createObjectURL(file)
            }
        }
        /* ADD VCNS */
        $("#addvcns").click(function() {
            $(".form_vcns").append(
                '<div id="vcns" class="row mt-3"><div class="col-6 col-md-3 mb-1"><input id="vcnsf" type="date" max="<?php echo e(\Carbon\Carbon::now()->format('Y-m-d')); ?>" class="form-control text-danger fw-bold"name="vcnsf[]" required autofocus></div><div class="col-6 col-md-3 mb-1"><input id="vcnst" type="text" class="form-control text-danger fw-bold"name="vcnst[]" required autofocus placeholder="<?php echo e(__('Type')); ?>" maxlength="5"> </div><div class="col-6 col-md-3 mb-1"><input id="vcnsm" type="text" class="form-control text-danger fw-bold"name="vcnsm[]" required autofocus placeholder="<?php echo e(__('Brand')); ?>" maxlength="8"></div><div class="col-6 col-md-3 mb-1"><input id="vcnsd" type="text" class="form-control text-danger fw-bold"name="vcnsd[]" required autofocus placeholder="<?php echo e(__('Dose')); ?>" maxlength="2"></div></div>'
            );
            var n = $("div[id='vcns']").length;
            if (n == 3) {
                $('#addvcns').attr('disabled', true);
                $('#addvcns').hide(500);
            }
            if (n > 1) {
                $('#removevcns').attr('disabled', false);
                $('#removevcns').show(500);
            }

        });
        $('#removevcns').hide(400); //HIDE DEFAULT
        /* DELETE VCNS */
        $("#removevcns").click(function() {
            $('#vcns').last().remove();
            var n = $("div[id='vcns']").length;
            if (n <= 3) {
                $('#addvcns').attr('disabled', false);
                $('#addvcns').show(500);
            }
            if (n < 1) {
                $('#removevcns').attr('disabled', true);
                $('#removevcns').hide(500);
            }
        });
        /* GENDER */
        $("#gender").change(function() {
            if ($("#gender").val() == 'male') {
                $('#icbc').attr("disabled", true);
                $('#ficbc').hide(600);
                $('#hvs').attr("disabled", true);
                $('#fhvs').hide(600);
                $('#ncr').attr("disabled", true);
                $('#fncr').hide(600);
            }
            if ($("#gender").val() == 'female') {
                $('#icbc').attr("disabled", false)
                $('#ficbc').show(600);
                $('#hvs').attr("disabled", false);
                $('#fhvs').show(600);
                $('#ncr').attr("disabled", false);
                $('#fncr').show(600);
            }
        }).change();
    </script>

    <!-- STYLES -->
    <link rel="stylesheet" href="<?php echo e(asset('css/select2/select2.min.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('css/select2/select2-bootstrap-5-theme.min.css')); ?>" />

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/select2/select2.min.js')); ?>"></script>
    <script>
        $('.select2').select2({
            theme: 'bootstrap-5',
            width: "resolve"
        });
    </script>
    <style>
        .select2-container {
            color: rgb(210, 0, 0);
        }

    </style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>