<?php $__env->startSection('content'); ?>
    <div class="card mx-auto bg-black border border-danger">
        <div class="card-header fs-4 border border-danger">
            <?php echo e(__('Add Pet')); ?>

        </div>
        <div class="card-body border border-danger">
            <form class="form-horizontal" method="POST" action="<?php echo e(route('Mascotas.store')); ?>"
                enctype="multipart/form-data" autocomplete="off">
                <?php echo e(csrf_field()); ?>

                
                <input id="user_id" type="text" name="user_id" value="<?php echo e(Auth::user()->id); ?>" hidden>
                <div class="card bg-black border border-danger">
                    <div class="card-body border border-danger">
                        
                        <div class="row">
                            
                            <div class="col-sm-5 mb-3 form-group<?php echo e($errors->has('nombre') ? ' has-error' : ''); ?>">
                                <label for="nombre" class="col-form-label fw-bold">
                                    <?php echo e(__('Name')); ?>

                                </label>
                                <div class="col-auto">
                                    <input id="nombre" type="text" class="form-control text-danger" name="nombre"
                                        value="<?php echo e(old('nombre')); ?>" maxlength="18" required autofocus}>

                                    <?php if($errors->has('nombre')): ?>
                                        <span class="text-danger text-fs6">
                                            <?php echo e($errors->first('nombre')); ?>

                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            
                            <div class="col-sm-3 mb-3 form-group<?php echo e($errors->has('fnac') ? ' has-error' : ''); ?>">
                                <label for="fnac" class="col-form-label fw-bold">
                                    <?php echo e(__('Birthday')); ?>

                                </label>

                                <div class="col-auto">
                                    <input id="fnac" type="date" class="form-control text-danger" name="fnac"
                                        value="<?php echo e(old('fnac')); ?>" required autofocus>

                                    <?php if($errors->has('fnac')): ?>
                                        <span class="text-danger text-fs6">
                                            <?php echo e($errors->first('fnac')); ?>

                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            
                            <div class="col-sm-4 mb-3 form-group<?php echo e($errors->has('sss') ? ' has-error' : ''); ?>">
                                <label for="sss" class="col-form-label fw-bold">
                                    <?php echo e(__('Weight')); ?>

                                </label>
                                <div class="col-auto">
                                    <input id="sss" type="number" class="form-control text-danger" name="sss"
                                        value="<?php echo e(old('sss')); ?>" onKeyPress="if(this.value.length==4) return false;"
                                        onkeydown="return event.keyCode !== 69 && event.keyCode !== 189" required autofocus
                                        min="300" max="505">

                                    <?php if($errors->has('sss')): ?>
                                        <span class="text-danger text-fs6">
                                            <?php echo e($errors->first('sss')); ?>

                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                        
                        <div class="row mx-auto">
                            <div class="row col-sm-8">
                                
                                <div class="col-6 col-md-6 mb-3 form-group<?php echo e($errors->has('plc') ? ' has-error' : ''); ?>">
                                    <label for="plc" class="col-form-label fw-bold">
                                        <?php echo e(__('Seal')); ?>

                                    </label>
                                    <div class="col-auto">
                                        <input id="plc" type="number" class="form-control text-danger" name="plc"
                                            value="<?php echo e(old('plc')); ?>" required autofocus
                                            onKeyPress="if(this.value.length==4) return false;"
                                            onkeydown="return event.keyCode !== 69 && event.keyCode !== 189" min="0">

                                        <?php if($errors->has('plc')): ?>
                                            <span class="text-danger text-fs6">
                                                <?php echo e($errors->first('plc')); ?>

                                            </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                
                                <div class="col-6 col-md-6 mb-3 form-group<?php echo e($errors->has('plu') ? ' has-error' : ''); ?>">
                                    <label for="plu" class="col-form-label fw-bold">
                                        <?php echo e(__('Colour')); ?>

                                    </label>
                                    <div class="col-auto">
                                        <input id="plu" type="text" class="form-control text-danger" name="plu"
                                            value="<?php echo e(old('plu')); ?>" required autofocus maxlength="18">

                                        <?php if($errors->has('plu')): ?>
                                            <span class="text-danger text-fs6">
                                                <?php echo e($errors->first('plu')); ?>

                                            </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                
                                
                                <div class="col-6 col-lg-4 mb-3 form-group<?php echo e($errors->has('pad') ? ' has-error' : ''); ?>">
                                    <label for="pad" class="col-form-label fw-bold">
                                        <?php echo e(__('Father')); ?>

                                    </label>
                                    <div class="col-auto">
                                        <input id="pad" type="text" class="form-control text-danger" name="pad"
                                            value="<?php echo e(old('pad')); ?>" maxlength="30" required autofocus>

                                        <?php if($errors->has('pad')): ?>
                                            <span class="text-danger text-fs6">
                                                <?php echo e($errors->first('pad')); ?>

                                            </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                
                                <div class="col-6 col-lg-4 mb-3 form-group<?php echo e($errors->has('mad') ? ' has-error' : ''); ?>">
                                    <label for="mad" class="col-form-label fw-bold">
                                        <?php echo e(__('Mother')); ?>

                                    </label>
                                    <div class="col-auto">
                                        <input id="mad" type="text" class="form-control text-danger" name="mad"
                                            value="<?php echo e(old('mad')); ?>" maxlength="30" required autofocus>

                                        <?php if($errors->has('mad')): ?>
                                            <span class="text-danger text-fs6">
                                                <?php echo e($errors->first('mad')); ?>

                                            </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                
                                <div class="col col-lg-4 mb-3 form-group<?php echo e($errors->has('des') ? ' has-error' : ''); ?>">
                                    <label for="des" class="col-form-label fw-bold">
                                        <?php echo e(__('Disability')); ?>

                                    </label>
                                    <div class="col-auto">
                                        <select class="form-select text-danger" id="des" name="des"
                                            value="<?php echo e(old('des')); ?>" required>
                                            <option selected value="No"><?php echo e(__('No')); ?></option>
                                            <option value="Visual"><?php echo e(__('Visual')); ?></option>
                                            <option value="Fisica"><?php echo e(__('Physical')); ?></option>
                                            <option value="Auditiva"><?php echo e(__('Auditory')); ?></option>
                                            <option value="Verbal"><?php echo e(__('Verbal')); ?></option>
                                            <option value="Mental"><?php echo e(__('Mental')); ?></option>
                                        </select>

                                        <?php if($errors->has('des')): ?>
                                            <span class="text-danger text-fs6">
                                                <?php echo e($errors->first('des')); ?>

                                            </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                
                                <div class="col-sm-12 mb-3 form-group<?php echo e($errors->has('obs') ? ' has-error' : ''); ?>">
                                    <label for="obs" class="col-form-label fw-bold">
                                        <?php echo e(__('Observations')); ?>

                                    </label>
                                    <div class="col-auto">
                                        <textarea id="obs" class="form-control text-danger" name="obs"
                                            value="<?php echo e(old('obs')); ?>" rows="3" maxlength="200" required
                                            autofocus></textarea>

                                        <?php if($errors->has('obs')): ?>
                                            <span class="text-danger text-fs6">
                                                <?php echo e($errors->first('obs')); ?>

                                            </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-4 mx-auto">
                                
                                <div class="col-sm-12 mb-3 form-group<?php echo e($errors->has('foto') ? ' has-error' : ''); ?>">
                                    <label for="name" class="col-form-label fw-bold">
                                        <?php echo e(__('Photo Profile')); ?>

                                    </label>
                                    <div class="col-auto bg-dark rounded">
                                        <img id="preview" class="mx-auto d-block bg-black" width="136vh" height="200vh"
                                            style="max-width: 220px;" />
                                        <input id="foto" type="file" class="form-control text-danger form-control-sm"
                                            name="foto" value="<?php echo e(old('foto')); ?>" required autofocus accept="image/*">
                                    </div>

                                    <?php if($errors->has('foto')): ?>
                                        <span class="text-danger fs-6">
                                            <?php echo e($errors->first('foto')); ?>

                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                        
                        <div class="mx-auto">
                            <button type="submit" class="btn btn-primary">
                                <?php echo e(__('Add Pet')); ?>

                            </button>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>

    
    <script src="<?php echo e(asset('js/jquery-3.6.0.js')); ?>"></script>
    <script>
        /* PASTE AND COPY */
        $(document).ready(function() {
            $('input').bind('copy paste', function(e) {
                e.preventDefault();
            });
        });
        /* FOTO */
        foto.onchange = evt => {
            const [file] = foto.files
            if (file) {
                preview.src = URL.createObjectURL(file)
            }
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>