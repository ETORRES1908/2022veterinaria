<?php $__env->startSection('content'); ?>
    <div class="card mx-auto bg-black border border-danger">
        <div class="card-header fs-4 border border-danger">
            <?php echo e(__('Add Exemplar')); ?>

        </div>
        <div class="card-body border border-danger">
            <form class="text-uppercase" method="POST" action="<?php echo e(route('mascotas.store')); ?>" enctype="multipart/form-data"
                autocomplete="off">
                <?php echo csrf_field(); ?>

                
                <input id="user_id" type="text" name="user_id" value="<?php echo e(Auth::user()->id); ?>" hidden>
                <div class="card bg-black border border-danger">
                    <div class="card-body border border-danger">
                        
                        <div class="row">
                            <div class="row col-lg-8">
                                
                                <div
                                    class="col-6 col-md-4 mb-3 form-group<?php echo e($errors->has('nombre') ? ' has-error' : ''); ?>">
                                    <label for="nombre" class="col-form-label fw-bold">
                                        <?php echo e(__('Name')); ?> <?php echo e(__('pet')); ?>

                                    </label>
                                    <div class="col-auto">
                                        <input id="nombre" type="text" class="form-control text-danger" name="nombre"
                                            value="<?php echo e(old('nombre')); ?>" maxlength="18" required autofocus}>

                                        <?php if($errors->has('nombre')): ?>
                                            <span class="text-danger text-fs6">
                                                <?php echo e($errors->first('nombre')); ?>

                                            </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                
                                <div
                                    class="col-6 col-md-4 mb-3 form-group<?php echo e($errors->has('gender') ? ' has-error' : ''); ?>">
                                    <label for="gender" class="col-form-label fw-bold">
                                        <?php echo e(__('gender')); ?>

                                    </label>
                                    <div class="col-auto">
                                        <select id="gender" name="gender" class="form-select text-capitalize text-danger">
                                            <option value="male" <?php if(old('gender') == 'male'): ?> selected <?php endif; ?>>
                                                <?php echo e(__('male')); ?></option>
                                            <option value="female" <?php if(old('gender') == 'female'): ?> selected <?php endif; ?>>
                                                <?php echo e(__('female')); ?></option>
                                        </select>
                                        <?php if($errors->has('gender')): ?>
                                            <span class="text-danger text-fs6">
                                                <?php echo e($errors->first('gender')); ?>

                                            </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                
                                <div
                                    class="col-6 col-md-4 mb-3 form-group<?php echo e($errors->has('fnac') ? ' has-error' : ''); ?>">
                                    <label for="fnac" class="col-form-label fw-bold">
                                        <?php echo e(__('Birthday')); ?>

                                    </label>
                                    <div class="col-auto">
                                        <input id="fnac" type="date" class="form-control text-danger" name="fnac"
                                            value="<?php echo e(old('fnac')); ?>" required autofocus
                                            max="<?php echo e(\Carbon\Carbon::now()->format('Y-m-d')); ?>">
                                        <?php if($errors->has('fnac')): ?>
                                            <span class="text-danger text-fs6">
                                                <?php echo e($errors->first('fnac')); ?>

                                            </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                
                                <div
                                    class="col-6 col-md-4 mb-3 form-group<?php echo e($errors->has('size') ? ' has-error' : ''); ?>">
                                    <label for="size" class="col-form-label fw-bold">
                                        <?php echo e(__('Size')); ?>

                                    </label>
                                    <div class="col-auto">
                                        <select class="form-select text-danger" name="size" value="<?php echo e(old('size')); ?>">
                                            <option value="smll" <?php if(old('size')): ?> selected <?php endif; ?>>
                                                <?php echo e(__('Small')); ?></option>
                                            <option value="mdm" <?php if(old('size')): ?> selected <?php endif; ?>>
                                                <?php echo e(__('Medium')); ?></option>
                                            <option value="lrg" <?php if(old('size')): ?> selected <?php endif; ?>>
                                                <?php echo e(__('Large')); ?></option>
                                        </select>
                                        <?php if($errors->has('size')): ?>
                                            <span class="text-danger text-fs6">
                                                <?php echo e($errors->first('size')); ?>

                                            </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                
                                
                                <div class="col-6 col-md-4 mb-3 form-group<?php echo e($errors->has('plc') ? ' has-error' : ''); ?>">
                                    <label for="plc" class="col-form-label fw-bold">
                                        <?php echo e(__('plaque')); ?>

                                    </label>
                                    <div class="col-auto">
                                        <input id="plc" type="number" class="form-control text-danger" name="plc"
                                            value="<?php echo e(old('plc')); ?>" required autofocus
                                            onKeyPress="if(this.value.length==4) return false;"
                                            onkeydown="return event.keyCode !== 69 && event.keyCode !== 189" min="0">

                                        <?php if($errors->has('plc')): ?>
                                            <span class="text-danger text-fs6">
                                                <?php echo e($errors->first('plc')); ?>

                                            </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                
                                <div class="col-6 col-md-4 mb-3 form-group<?php echo e($errors->has('lck') ? ' has-error' : ''); ?>">
                                    <label for="lck" class="col-form-label fw-bold">
                                        <?php echo e(__('Locker')); ?>

                                    </label>
                                    <div class="col-auto">
                                        <input id="lck" type="number" class="form-control text-danger" name="lck"
                                            value="<?php echo e(old('lck')); ?>" required autofocus
                                            onKeyPress="if(this.value.length==3) return false;"
                                            onkeydown="return event.keyCode !== 69 && event.keyCode !== 189" min="0">

                                        <?php if($errors->has('lck')): ?>
                                            <span class="text-danger text-fs6">
                                                <?php echo e($errors->first('lck')); ?>

                                            </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                
                                <div class="col-12 mb-3 form-group<?php echo e($errors->has('plu') ? ' has-error' : ''); ?>">
                                    <label for="plu" class="col-form-label fw-bold">
                                        <?php echo e(__('Colour')); ?>

                                    </label>
                                    <div class="col-auto">
                                        <input id="plu" type="text" class="form-control text-danger" name="plu"
                                            value="<?php echo e(old('plu')); ?>" required autofocus maxlength="18">

                                        <?php if($errors->has('plu')): ?>
                                            <span class="text-danger text-fs6">
                                                <?php echo e($errors->first('plu')); ?>

                                            </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                
                                
                                <div class="col-6 mb-3 form-group<?php echo e($errors->has('pad') ? ' has-error' : ''); ?>">
                                    <label for="pad" class="col-form-label fw-bold">
                                        <?php echo e(__('Father')); ?>

                                    </label>
                                    <div class="col-auto">
                                        <select class="select2 form-select" name="pad" autofocus>
                                            <option value="" hidden>
                                                <?php echo e(__('Choose exemplar')); ?>...
                                            </option>
                                            <?php $__currentLoopData = $pads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mascota): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option <?php if(old('pad') == $mascota->id): ?> selected <?php endif; ?>
                                                    value="<?php echo e($mascota->id); ?>"><?php echo e($mascota->nombre); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <?php if($errors->has('pad')): ?>
                                            <span class="text-danger text-fs6">
                                                <?php echo e($errors->first('pad')); ?>

                                            </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                
                                <div class="col-6 mb-3 form-group<?php echo e($errors->has('mad') ? ' has-error' : ''); ?>">
                                    <label for="mad" class="col-form-label fw-bold">
                                        <?php echo e(__('Mother')); ?>

                                    </label>
                                    <div class="col-auto">
                                        <select class="select2 form-select" name="mad" autofocus>
                                            <option value="" hidden>
                                                <?php echo e(__('Choose exemplar')); ?>...
                                            </option>
                                            <?php $__currentLoopData = $mads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mascota): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option <?php if(old('mad') == $mascota->id): ?> selected <?php endif; ?>
                                                    value="<?php echo e($mascota->id); ?>"><?php echo e($mascota->nombre); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <?php if($errors->has('mad')): ?>
                                            <span class="text-danger text-fs6">
                                                <?php echo e($errors->first('mad')); ?>

                                            </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                
                                <div class="col-6 mb-3 form-group<?php echo e($errors->has('des') ? ' has-error' : ''); ?>">
                                    <label for="des" class="col-form-label fw-bold">
                                        <?php echo e(__('Disability')); ?>

                                    </label>
                                    <div class="col-auto">
                                        <select class="form-select text-danger" id="des" name="des"
                                            value="<?php echo e(old('des')); ?>" required>
                                            <option value="0" <?php if(old('des') == '0'): ?> selected <?php endif; ?>>
                                                <?php echo e(__('No')); ?></option>
                                            <option value="1" <?php if(old('des') == '1'): ?> selected <?php endif; ?>>
                                                <?php echo e(__('Visual')); ?></option>
                                            <option value="2" <?php if(old('des') == '2'): ?> selected <?php endif; ?>>
                                                <?php echo e(__('Physical')); ?></option>
                                            <option value="3" <?php if(old('des') == '3'): ?> selected <?php endif; ?>>
                                                <?php echo e(__('Other')); ?></option>
                                        </select>

                                        <?php if($errors->has('des')): ?>
                                            <span class="text-danger text-fs6">
                                                <?php echo e($errors->first('des')); ?>

                                            </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                
                                <div class="col-6 mb-3 form-group<?php echo e($errors->has('sena') ? ' has-error' : ''); ?>">
                                    <label for="sena" class="col-form-label fw-bold">
                                        <?php echo e(__('SENASA')); ?>

                                    </label>
                                    <div class="col-auto">
                                        <input id="sena" type="text" class="form-control text-danger" name="sena"
                                            value="<?php echo e(old('sena')); ?>" autofocus maxlength="30">

                                        <?php if($errors->has('sena')): ?>
                                            <span class="text-danger text-fs6">
                                                <?php echo e($errors->first('sena')); ?>

                                            </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                
                                <div id="ficbc"
                                    class="col-6 mb-3 form-group<?php echo e($errors->has('icbc') ? ' has-error' : ''); ?>">
                                    <label for="icbc" class="col-form-label fw-bold">
                                        <?php echo e(__('Incubation')); ?>

                                    </label>
                                    <div class="col-auto">
                                        <input id="icbc" type="date" class="form-control text-danger" name="icbc"
                                            value="<?php echo e(old('icbc')); ?>" autofocus
                                            max="<?php echo e(\Carbon\Carbon::now()->format('Y-m-d')); ?>">

                                        <?php if($errors->has('icbc')): ?>
                                            <span class="text-danger text-fs6">
                                                <?php echo e($errors->first('icbc')); ?>

                                            </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                
                                <div id="fhvs"
                                    class="col-3 mb-3 form-group<?php echo e($errors->has('hvs') ? ' has-error' : ''); ?>">
                                    <label for="hvs" class="col-form-label fw-bold">
                                        <?php echo e(__('Eggs')); ?>

                                    </label>
                                    <div class="col-auto">
                                        <input id="hvs" type="number" class="form-control text-danger" name="hvs"
                                            value="<?php echo e(old('hvs')); ?>" autofocus
                                            onKeyPress="if(this.value.length==2) return false;"
                                            onkeydown="return event.keyCode !== 69 && event.keyCode !== 189" min="0">

                                        <?php if($errors->has('hvs')): ?>
                                            <span class="text-danger text-fs6">
                                                <?php echo e($errors->first('hvs')); ?>

                                            </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                
                                <div id="fncr"
                                    class="col-3 mb-3 form-group<?php echo e($errors->has('ncr') ? ' has-error' : ''); ?>">
                                    <label for="ncr" class="col-form-label fw-bold">
                                        <?php echo e(__('Born')); ?>

                                    </label>
                                    <div class="col-auto">
                                        <input id="ncr" type="number" class="form-control text-danger" name="ncr"
                                            value="<?php echo e(old('ncr')); ?>" autofocus
                                            onKeyPress="if(this.value.length==2) return false;"
                                            onkeydown="return event.keyCode !== 69 && event.keyCode !== 189" min="0">

                                        <?php if($errors->has('ncr')): ?>
                                            <span class="text-danger text-fs6">
                                                <?php echo e($errors->first('ncr')); ?>

                                            </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                
                                <div
                                    class="col-12 mb-3 border border-danger rounded form-group<?php echo e($errors->has('vcns') ? ' has-error' : ''); ?>">
                                    <label for="vcns" class="col-form-label fw-bold">
                                        <?php echo e(__('Vaccines')); ?>

                                    </label>
                                    <div class="col-auto">
                                        <input id="addvcns" type="button" class="btn btn-success mb-3" value="+">
                                        <input id="removevcns" type="button" class="btn btn-danger mb-3" value="-">
                                        <div class="form_vcns">

                                        </div>

                                        <?php if($errors->has('vcns')): ?>
                                            <span class="text-danger text-fs6">
                                                <?php echo e($errors->first('vcns')); ?>

                                            </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                
                                <div
                                    class="col-12 mb-3 border border-danger rounded form-group<?php echo e($errors->has('mvs') ? ' has-error' : ''); ?>">
                                    <label for="mvs" class="col-form-label fw-bold">
                                        <?php echo e(__('Moves')); ?>

                                    </label>
                                    <div class="col-auto">
                                        <input id="addmvs" type="button" class="btn btn-success mb-3" value="+">
                                        <input id="removemvs" type="button" class="btn btn-danger mb-3" value="-">
                                        <div class="form_mvs">

                                        </div>
                                    </div>
                                    <?php if($errors->has('mvs')): ?>
                                        <span class="text-danger text-fs6">
                                            <?php echo e($errors->first('mvs')); ?>

                                        </span>
                                    <?php endif; ?>
                                </div>
                                
                                <div
                                    class="col-md-12 mb-3 border border-danger form-group<?php echo e($errors->has('spmt') ? ' has-error' : ''); ?>">
                                    <label for="spmt" class="col-form-label fw-bold">
                                        <?php echo e(__('Supplement')); ?>

                                    </label>
                                    <div class="col-auto">
                                        <input id="addsmpt" type="button" class="btn btn-success mb-3" value="+">
                                        <input id="removesmpt" type="button" class="btn btn-danger mb-3" value="-">
                                        <div class="form_smpt">
                                        </div>

                                        <?php if($errors->has('spmt')): ?>
                                            <span class="text-danger text-fs6">
                                                <?php echo e($errors->first('spmt')); ?>

                                            </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                
                                <div class="col-md-12 mb-3 form-group<?php echo e($errors->has('obs') ? ' has-error' : ''); ?>">
                                    <label for="obs" class="col-form-label fw-bold">
                                        <?php echo e(__('Observations')); ?>

                                    </label>
                                    <div class="col-auto">
                                        <textarea id="obs" class="form-control text-danger" name="obs" value="<?php echo e(old('obs')); ?>" rows="3" maxlength="200"
                                            autofocus></textarea>
                                        <?php if($errors->has('obs')): ?>
                                            <span class="text-danger text-fs6">
                                                <?php echo e($errors->first('obs')); ?>

                                            </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-4">
                                
                                <div class="col-md-12 mb-3 form-group<?php echo e($errors->has('foto') ? ' has-error' : ''); ?>">
                                    <label for="name" class="col-form-label fw-bold">
                                        <?php echo e(__('Photo Profile')); ?> <?php echo e(__('Exemplar')); ?>

                                    </label>
                                    <div class="col-auto rounded">
                                        <img id="preview" class="img-fluid mx-auto d-block bg-danger" />
                                        <div for="foto" onclick="getFile()" id="v" class="btn btn-white bg-white d-flex">
                                            <i class="bi bi-cloud-upload"></i><?php echo e(__('Upload')); ?>

                                            <div id="yourBtn" class="mx-2">...<?php echo e(__('there is no picture')); ?>

                                            </div>
                                        </div>
                                        <input id="foto" type="file" name="foto" value="<?php echo e(old('foto')); ?>" required
                                            autofocus accept="image/*" onchange="sub(this)" hidden>
                                        <script>
                                            function getFile() {
                                                document.getElementById("foto").click();

                                            }

                                            function sub(obj) {
                                                var file = obj.value;
                                                var fileName = file.split("\\");
                                                document.getElementById("yourBtn").innerHTML = fileName[fileName.length - 1];
                                                event.preventDefault();
                                                /* FOTO */
                                                if (foto.files) {
                                                    preview.src = URL.createObjectURL(foto.files[0])
                                                }
                                            }
                                        </script>
                                    </div>
                                    <?php if($errors->has('foto')): ?>
                                        <span class="text-danger fs-6">
                                            <?php echo e($errors->first('foto')); ?>

                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                        
                        <div class="mx-auto">
                            <button type="submit" class="btn btn-primary">
                                <?php echo e(__('Add Exemplar')); ?>

                            </button>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>

    
    <script>
        /* PASTE AND COPY */
        $(document).ready(function() {
            $('input').bind('copy paste', function(e) {
                e.preventDefault();
            });
        });

        /* ADD VCNS */
        $("#addvcns").click(function() {
            $(".form_vcns").append(
                '<div id="vcns" class="row mb-3"><div class="col-6 col-md-3 mb-1"><input id="vcnsf" type="date" max="<?php echo e(\Carbon\Carbon::now()->format('Y-m-d')); ?>" class="form-control text-danger fw-bold"name="vcnsf[]" required autofocus></div><div class="col-6 col-md-3 mb-1"><input id="vcnst" type="text" class="form-control text-danger fw-bold"name="vcnst[]" required autofocus placeholder="<?php echo e(__('Type')); ?>" pattern="[A-zÀ-ú1-9\s]+" maxlength="10"onkeydown="return /[A-zÀ-ú1-9\s]/i.test(event.key)"> </div><div class="col-6 col-md-3 mb-1"><input id="vcnsm" type="text" class="form-control text-danger fw-bold"name="vcnsm[]" required autofocus placeholder="<?php echo e(__('Brand')); ?>" pattern="[A-zÀ-ú\s]+" maxlength="10" onkeydown="return /[A-zÀ-ú\s]/i.test(event.key)"></div><div class="col-6 col-md-3 mb-1"><input id="vcnsd" type="number" class="form-control text-danger fw-bold"name="vcnsd[]" required autofocus placeholder="<?php echo e(__('Dose')); ?>"onKeyPress="if(this.value.length==2) return false;" onkeydown="return event.keyCode !== 69 && event.keyCode !== 189"> </div></div > '
            );
            var n = $("div[id='vcns']").length;
            if (n == 4) {
                $('#addvcns').attr('disabled', true);
                $('#addvcns').hide(500);
            }
            if (n >= 0) {
                $('#removevcns').attr('disabled', false);
                $('#removevcns').show(500);
            }
        });

        /* DELETE VCNS */
        $("#removevcns").click(function() {
            $('#vcns').last().remove();
            var n = $("div[id='vcns']").length;
            if (n <= 4) {
                $('#addvcns').attr('disabled', false);
                $('#addvcns').show(500);
            }
            if (n <= 0) {
                $('#removevcns').attr('disabled', true);
                $('#removevcns').hide(500);
            }
        });

        /* ADD MVS */
        $("#addmvs").click(function() {
            $(".form_mvs").append(
                '<div id="mvs" class="row mb-3"><div class="col-6 col-md-4 mb-1"><input type="date" class="form-control text-danger fw-bold" name="mvf[]"required autofocus max="<?php echo e(\Carbon\Carbon::now()->format('Y-m-d')); ?>"></div><div class="col-6 col-md-2 mb-1"><div class="input-group"><input type="number" class="form-control text-danger" name="mm[]" onKeyPress="if(this.value.length==2) return false;" required onkeydown="return event.keyCode !== 69 && event.keyCode !== 189" min="0" max="59" placeholder="00 min"></div></div><div class="col-6 col-md-3 mb-1"><input type="text" class="form-control text-danger fw-bold" name="mvtp[]" required autofocus placeholder="<?php echo e(__('Type')); ?>" maxlength="10"></div><div class="col-6 col-md-3 mb-1"><select name="mvr[]" class="form-select text-danger text-capitalize"><option value="good"<?php if(old('mvr[]') == 'good'): ?> ) selected <?php endif; ?>><?php echo e(__('good')); ?></option><option value="regular"<?php if(old('mvr[]') == 'regular'): ?> ) selected <?php endif; ?>><?php echo e(__('regular')); ?></option><option value="bad"<?php if(old('mvr[]') == 'bad'): ?> ) selected <?php endif; ?>><?php echo e(__('bad')); ?></option></select></div></div>'
            );
            var n = $("div[id='mvs']").length;
            if (n >= 4) {
                $('#addmvs').attr('disabled', true);
                $('#addmvs').hide(500);
            }
            if (n >= 0) {
                $('#removemvs').attr('disabled', false);
                $('#removemvs').show(500);
            }
        });

        /* DELETE MVS */
        $("#removemvs").click(function() {
            $('#mvs').last().remove();
            var n = $("div[id='mvs']").length;
            if (n <= 4) {
                $('#addmvs').attr('disabled', false);
                $('#addmvs').show(500);
            }
            if (n <= 0) {
                $('#removemvs').attr('disabled', true);
                $('#removemvs').hide(500);
            }
        });

        /* ADD SUPLEMENTOS */
        $("#addsmpt").click(function() {
            $(".form_smpt").append(
                '<div id="smpt" class="row mb-3"><div class="col-6"><input type="text" class="form-control text-danger" name="spmtname[]" maxlength="20" autofocus required></div><div class="col-3"><input type="date" class="form-control text-danger" name="spmtfecha[]" max="<?php echo e(\Carbon\Carbon::now()->format('Y-m-d')); ?>" autofocus required></div><div class="col-3"><input type="time" class="form-control text-danger" name="spmttime[]" autofocus required></div></div>'
            );
            var n = $("div[id='smpt']").length;
            if (n == 4) {
                $('#addsmpt').attr('disabled', true);
                $('#addsmpt').hide(500);
            }
            if (n >= 0) {
                $('#removesmpt').attr('disabled', false);
                $('#removesmpt').show(500);
            }
        });

        /* DELETE SUPLEMENTOS */
        $("#removesmpt").click(function() {
            $('#smpt').last().remove();
            var n = $("div[id='smpt']").length;
            if (n <= 4) {
                $('#addsmpt').attr('disabled', false);
                $('#addsmpt').show(500);
            }
            if (n <= 0) {
                $('#removesmpt').attr('disabled', true);
                $('#removesmpt').hide(500);
            }
        });

        /* GENDER */
        $("#gender").change(function() {
            if ($("#gender").val() == 'male') {
                $('#icbc').attr("disabled", true);
                $('#ficbc').hide(600);
                $('#hvs').attr("disabled", true);
                $('#fhvs').hide(600);
                $('#ncr').attr("disabled", true);
                $('#fncr').hide(600);
            }
            if ($("#gender").val() == 'female') {
                $('#icbc').attr("disabled", false)
                $('#ficbc').show(600);
                $('#hvs').attr("disabled", false);
                $('#fhvs').show(600);
                $('#ncr').attr("disabled", false);
                $('#fncr').show(600);
            }
        }).change();
    </script>

    <!-- STYLES -->
    <link rel="stylesheet" href="<?php echo e(asset('css/select2/select2.min.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('css/select2/select2-bootstrap-5-theme.min.css')); ?>" />

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/select2/select2.min.js')); ?>"></script>
    <script>
        $('.select2').select2({
            theme: 'bootstrap-5',
            width: "resolve"
        });
    </script>
    <style>
        .select2-container {
            color: rgb(210, 0, 0);
        }

    </style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>