    
    <link rel="stylesheet" href="<?php echo e(asset('css/datatable/dataTables.bootstrap5.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/datatable/buttons.dataTables.min.css')); ?>">
    
    <script src="<?php echo e(asset('js/jquery-3.6.0.js')); ?>"></script>
    <script src="<?php echo e(asset('js/datatable/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/datatable/dataTables.bootstrap5.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/datatable/dataTables.buttons.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/ajax/jszip.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/ajax/pdfmake.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/ajax/vfs_fonts.js')); ?>"></script>
    <script src="<?php echo e(asset('js/datatable/buttons.html5.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/datatable/buttons.print.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/datatable/buttons.print.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/datatable/sorting/date-eu.js')); ?>"></script>
