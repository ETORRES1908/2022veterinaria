<?php $__env->startSection('title'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1><?php echo e(__('Banners')); ?></h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <?php if(session('mensaje')): ?>
            <div class="alert alert-success">
                <?php echo e(session('mensaje')); ?>

            </div>
        <?php endif; ?>
        <?php if(session('error')): ?>
            <div class="alert alert-danger">
                <?php echo e(session('error')); ?>

            </div>
        <?php endif; ?>
        <div style="margin-bottom:1vh">
            <a class="btn btn-primary" href="<?php echo e(route('mbanners.create')); ?>"><?php echo e(__('Create')); ?></a>
        </div>
        <div class="table-responsive">
            <table id="datatable" class="table table-hover nowrap" style="width:100%">
                <thead>
                    <tr>
                        <th><?php echo e(__('Type')); ?></th>
                        <th><?php echo e(__('Name')); ?></th>
                        <th><?php echo e(__('Photo')); ?></th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $banners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($banner->type); ?></td>
                            <td><?php echo e($banner->name); ?></td>
                            <td><?php echo e($banner->ruta); ?></td>
                            <td>
                                <form method="POST" class="text-uppercase" action="<?php echo e(route('mbanners.destroy', $banner->id)); ?>">
                                    <?php echo method_field('delete'); ?>

                                    <?php echo csrf_field(); ?>

                                    <button type="submit" class="col btn btn-danger"><?php echo e(__('Delete')); ?></button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                <tfoot>
                    <tr>
                        <th><?php echo e(__('Type')); ?></th>
                        <th><?php echo e(__('Name')); ?></th>
                        <th><?php echo e(__('Photo')); ?></th>
                        <th></th>
                    </tr>
                </tfoot>
            </table>
        </div>
    </div>

    
    <link rel="stylesheet" href="<?php echo e(asset('css/datatable/dataTables.bootstrap5.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/datatable/buttons.dataTables.min.css')); ?>">
    
    <script src="<?php echo e(asset('js/jquery-3.6.0.js')); ?>"></script>
    <script src="<?php echo e(asset('js/datatable/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/datatable/dataTables.bootstrap5.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/datatable/dataTables.buttons.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/ajax/jszip.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/ajax/pdfmake.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/ajax/vfs_fonts.js')); ?>"></script>
    <script src="<?php echo e(asset('js/datatable/buttons.html5.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/datatable/buttons.print.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/datatable/buttons.print.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/datatable/sorting/date-eu.js')); ?>"></script>

    
    <style>
        .mb {
            margin-bottom: 4px;
        }

    </style>

    
    <script type="text/javascript">
        $(document).ready(function() {
            function getLanguage() {
                var lang = $('html').attr('lang');
                if (lang == 'es') {
                    lng = "es-ES";
                } else if (lang == 'en') {
                    lng = "en-GB";
                }
                var result = null;
                var path = 'https://cdn.datatables.net/plug-ins/1.11.5/i18n/';
                result = path + lng + ".json";
                return result;
            }
            // Build Datatable
            $('#datatable').DataTable({
                language: {
                    "url": getLanguage()
                },
                bInfo: false,
                lengthChange: false,
                pageLength: 10,
                lengthMenu: [
                    [10],
                    [10]
                ]
            });
        });
        /* ALERT */
        setTimeout(function() {
            $('.alert').fadeOut('slow');
        }, 5000);
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>