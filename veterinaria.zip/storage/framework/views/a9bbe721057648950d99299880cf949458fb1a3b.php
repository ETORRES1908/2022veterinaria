<?php $__env->startSection('content'); ?>
    <?php if(session('mensaje')): ?>
        <div class="alert btn alert-warning">
            <?php echo e(session('mensaje')); ?>

        </div>
    <?php endif; ?>
    <div class="card bg-black text-white border border-danger">
        <div class="card-header border border-danger">
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('addanimal')): ?>
                <?php if(count($listps) <= 330): ?>
                    <button type="button" class="btn btn-dark" data-bs-toggle="modal" data-bs-target="#AddExemplar">
                        <?php echo e(__('Join')); ?>

                    </button>
                <?php endif; ?>
            <?php endif; ?>
            <?php if($errors->has('mascota_id')): ?>
                <span class="alert fs-6 text-danger" id="Message">
                    <?php echo e(__('Choose other exemplar')); ?>

                </span>
            <?php endif; ?>
            <?php if(count($evento->participants) >= 2): ?>
                <a type="button" class="btn btn-dark" href="<?php echo e(route('duels.show', $evento->id)); ?>">
                    <?php echo e(__('Duels')); ?>

                </a>
            <?php endif; ?>

            <button type="button" class="btn btn-dark" data-bs-toggle="modal" data-bs-target="#Event">
                <?php echo e(__('Event')); ?>

            </button>
            <button type="button" class="btn btn-dark" data-bs-toggle="modal" data-bs-target="#Tickets">
                <?php echo e(__('Tickets')); ?>

            </button>
        </div>
        <div class="card-body border border-danger table-responsive">
            <table id="datatable" class="table table-dark table-hover nowrap">
                <thead>
                    <tr>
                        <th>REGGAL</th>
                        <th><?php echo e(__('Weight')); ?></th>
                        <th><?php echo e(__('Shed')); ?></th>
                        <th><?php echo e(__('Disability')); ?></th>
                        <th><?php echo e(__('Seal')); ?></th>
                        <th><?php echo e(__('BOX')); ?> MIN.</th>
                        <th><?php echo e(__('BOX')); ?> MAX.</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $listps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $listp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($listp->mascota->REGGAL); ?></td>
                            <td><?php echo e($listp->mascota->sss); ?></td>
                            <td><?php echo e($listp->mascota->user->galpon); ?></td>
                            <td>
                                <?php switch ($listp->mascota->des) {
                                    case '0':
                                        echo __('No');
                                        break;
                                    case '1':
                                        echo __('Visual');
                                        break;
                                    case '2':
                                        echo __('Physical');
                                        break;
                                    case '3':
                                        echo __('Other');
                                        break;
                                } ?></td>
                            <td><?php echo e($listp->mascota->plc); ?></td>
                            <td>1</td>
                            <td>2</td>
                            <td>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('chngw')): ?>
                                    <button type="button" class="btn btn-dark" data-bs-toggle="modal"
                                        data-bs-target="#CHNGW<?php echo e($listp->mascota->id); ?>">
                                        <?php echo e(__('Change weight')); ?>

                                    </button>
                                    <!-- MODAL CHANGE WEIGHT -->
                                    <div class="modal fade" id="CHNGW<?php echo e($listp->mascota->id); ?>" aria-hidden="true"
                                        aria-labelledby="CHNGW<?php echo e($listp->mascota->id); ?>" tabindex="-1">
                                        <div class="modal-dialog modal-dialog-centered">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <div class="modal-title text-black fw-bold"><?php echo e(__('Choose exemplar')); ?>

                                                    </div>
                                                    <button type="button" class="btn btn-close" data-bs-dismiss="modal"
                                                        aria-label="Close"></button>
                                                </div>
                                                <form class="form-horizontal" method="POST"
                                                    action="<?php echo e(route('participants.update', $listp->id)); ?>"
                                                    enctype="multipart/form-data" autocomplete="off">
                                                    <?php echo e(method_field('PUT')); ?>

                                                    <?php echo csrf_field(); ?>

                                                    <div class="modal-body bg-black">
                                                        
                                                        <div class="row mb-2">
                                                            <label
                                                                class="col-sm-4 col-form-label"><?php echo e(__('Exemplar')); ?>:</label>
                                                            <div class="col-sm-8">
                                                                <input class="form-control text-danger" type="text"
                                                                    value="<?php echo e($listp->mascota->nombre); ?>" readonly>
                                                            </div>
                                                        </div>
                                                        
                                                        <div>
                                                            <input type="text" id="mascota_id" name="mascota_id"
                                                                value="<?php echo e($listp->mascota->id); ?>" hidden>
                                                            <input type="text" id="evento_id" name="evento_id"
                                                                value="<?php echo e($evento->id); ?>" hidden>
                                                        </div>
                                                        
                                                        <div class="row mb-2">
                                                            <label
                                                                class="col-sm-4 col-form-label"><?php echo e(__('REGGAL')); ?>:</label>
                                                            <div class="col-sm-8">
                                                                <input class="form-control text-danger" type="text"
                                                                    value="<?php echo e($listp->mascota->REGGAL); ?>" readonly>
                                                            </div>
                                                        </div>
                                                        
                                                        <div class="row mb-2">
                                                            <label
                                                                class="col-sm-4 col-form-label"><?php echo e(__('Weight')); ?>:</label>
                                                            <div class="col-sm-8">
                                                                <input type="number" class="form-control text-danger" id="mp"
                                                                    name="peso" required min="<?php echo e($listp->evento->miw); ?>"
                                                                    max="<?php echo e($listp->evento->maw); ?>"
                                                                    onKeyPress="if(this.value.length==3) return false;"
                                                                    onkeydown="return event.keyCode !== 69 && event.keyCode !== 189">
                                                            </div>
                                                        </div>
                                                        <div class="col-sm-9 mx-auto">
                                                            
                                                            <img id="preview<?php echo e($listp->mascota->id); ?>"
                                                                class="mx-auto d-block bg-black" height="200" width="180" />
                                                            <input id="foto<?php echo e($listp->mascota->id); ?>" type="file"
                                                                class="form-control" name="foto" value="<?php echo e(old('foto')); ?>"
                                                                required autofocus accept="image/*">
                                                            <script>
                                                                /* PREVIEW */
                                                                foto<?php echo e($listp->mascota->id); ?>.onchange = evt => {
                                                                    const [file] = foto<?php echo e($listp->mascota->id); ?>.files
                                                                    if (file) {
                                                                        preview<?php echo e($listp->mascota->id); ?>.src = URL.createObjectURL(file)
                                                                    }
                                                                };
                                                            </script>
                                                        </div>
                                                    </div>
                                                    <div class="modal-footer p-0">
                                                        <button type="submit" class="btn btn-primary mx-auto">
                                                            <?php echo e(__('Change weight')); ?>

                                                        </button>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                <?php endif; ?>
                                <button type="button" class="btn btn-danger" data-bs-toggle="modal"
                                    data-bs-target="#Foto<?php echo e($listp->id); ?>">
                                    <?php echo e(__('View')); ?>

                                </button>
                                <!-- Modal FOTO-->
                                <div class="modal fade" id="Foto<?php echo e($listp->id); ?>" aria-hidden="true"
                                    aria-labelledby="Foto<?php echo e($listp->id); ?>" tabindex="-1">
                                    <div class="modal-dialog modal-dialog-centered modal-md">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <button type="button" class="btn btn-danger bg-danger btn-close"
                                                    data-bs-dismiss="modal" aria-label="Close"></button>
                                            </div>
                                            <div class="modal-body mx-auto">
                                                <figure class="figure">
                                                    <img src="<?php if(!empty($listp->mascota->fotos->where('nfoto', 1)->first())): ?> <?php echo e(asset($listp->mascota->fotos->where('nfoto', 1)->first()->ruta)); ?> <?php else: ?><?php echo e(asset('storage/img/pata.jpg')); ?> <?php endif; ?>"
                                                        class="figure-img d-block mx-auto" width="300vh" height="400vh">
                                                    <figcaption class="figure-caption">
                                                        <?php echo e($listp->mascota->nombre); ?>

                                                    </figcaption>
                                                </figure>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                <tfoot>
                    <tr>
                        <th>REGGAL</th>
                        <th><?php echo e(__('Weight')); ?></th>
                        <th><?php echo e(__('Shed')); ?></th>
                        <th><?php echo e(__('Disability')); ?></th>
                        <th><?php echo e(__('Seal')); ?></th>
                        <th><?php echo e(__('BOX')); ?> MIN.</th>
                        <th><?php echo e(__('BOX')); ?> MAX.</th>
                        <th></th>
                    </tr>
                </tfoot>
            </table>
        </div>
    </div>

    <!-- MODAL ADD -->
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('addanimal')): ?>
        <div class="modal fade" id="AddExemplar" aria-hidden="true" aria-labelledby="AddExemplar" tabindex="-1">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-header">
                        <div class="modal-title text-black fw-bold"><?php echo e(__('Choose exemplar')); ?></div>
                        <button type="button" class="btn btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <form class="form-horizontal" method="POST" action="<?php echo e(route('participants.store')); ?>"
                        enctype="multipart/form-data" autocomplete="off">
                        <?php echo csrf_field(); ?>

                        <div class="modal-body bg-black">
                            
                            <div class="row mb-2">
                                <label class="col-sm-4 col-form-label"><?php echo e(__('Exemplar')); ?>:</label>
                                <div class="col-sm-8">
                                    <select class="form-select" id="mascota_id" name="mascota_id"
                                        value="<?php echo e(old('mascota_id')); ?>" required>
                                        <option value="" selected disabled>Seleccionar mascota</option>
                                        <?php $__currentLoopData = Auth::user()->mascotas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mascota): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($mascota->id); ?>"
                                                <?php if(old('mascota_id') == $mascota->id): ?> selected <?php endif; ?>>
                                                <?php echo e($mascota->nombre); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            
                            <div>
                                <input type="text" id="evento_id" name="evento_id" value="<?php echo e($evento->id); ?>" hidden>
                            </div>
                            
                            <div class="row mb-2">
                                <label class="col-sm-4 col-form-label"><?php echo e(__('REGGAL')); ?>:</label>
                                <div class="col-sm-8">
                                    <input type="text" class="form-control text-danger" id="mreggal" readonly>
                                </div>
                            </div>
                        </div>
                        <div class="modal-footer p-0">
                            <button type="submit" class="btn btn-primary mx-auto">
                                <?php echo e(__('Add Exemplar')); ?>

                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    <?php endif; ?>

    <!-- MODAL EVENTO -->
    <div class="modal fade" id="Event" aria-hidden="true" aria-labelledby="AddExemplar" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered modal-xl">
            <div class="modal-content bg-black border border-danger">
                <div class="modal-header bg-black border border-danger">
                    
                    <button type="button" class="btn btn-danger bg-danger btn-close" data-bs-dismiss="modal"
                        aria-label="Close"></button>
                </div>
                <div class="modal-body bg-black border border-danger">
                    <div class="row">
                        <div class="col-12 col-xl-6">
                            <div class="card h-100 bg-black border border-danger">
                                <div class="card-header border border-danger fw-bold"> <?php echo e(__('EVENT')); ?></div>
                                <div class="card-body border border-danger">
                                    <div class="row">
                                        <div class="col-6 mb-3">
                                            <label for="title" class="form-label"><?php echo e(__('Type Event')); ?></label>
                                            <select class="form-control text-danger fw-bold" disabled
                                                style="-webkit-appearance: none;">
                                                <option value="cmp" <?php if($evento->tevent == 'cmp'): ?> selected <?php endif; ?>>
                                                    <?php echo e(__('Championship')); ?>

                                                </option>
                                                <option value="cct" <?php if($evento->tevent == 'cmp'): ?> selected <?php endif; ?>>
                                                    <?php echo e(__('Concentration')); ?>

                                                </option>
                                                <option value="chk" <?php if($evento->tevent == 'chk'): ?> selected <?php endif; ?>>
                                                    <?php echo e(__('Chuscas')); ?>

                                                </option>
                                                <option value="drb" <?php if($evento->tevent == 'drb'): ?> selected <?php endif; ?>>
                                                    <?php echo e(__('Derby')); ?>

                                                </option>
                                                <option value="prt" <?php if($evento->tevent == 'prt'): ?> selected <?php endif; ?>>
                                                    <?php echo e(__('Party')); ?>

                                                </option>
                                                <option value="thr" <?php if($evento->tevent == 'thr'): ?> selected <?php endif; ?>>
                                                    <?php echo e(__('Other')); ?>

                                                </option>
                                            </select>
                                        </div>
                                        <div class="col-6 mb-3">
                                            <label for="hours" class="form-label"><?php echo e(__('Coliseum')); ?></label>
                                            <input type="text" class="form-control text-danger" id="hours"
                                                value="<?php echo e($evento->coliseum->nombre); ?>" readonly>
                                        </div>
                                        <div class="col-6 mb-3">
                                            <label for="title" class="form-label"><?php echo e(__('Weight')); ?></label>
                                            <div class="col-auto input-group-text">
                                                Min
                                                <div class="form-control form-control-sm m-0 text-danger">
                                                    <?php echo e($evento->miw); ?></div>
                                                Max
                                                <div class="form-control form-control-sm m-0 text-danger">
                                                    <?php echo e($evento->maw); ?></div>
                                            </div>
                                        </div>
                                        <div class="col-6 mb-3">
                                            <label for="hours" class="form-label"><?php echo e(__('Time start')); ?></label>
                                            <input type="time" class="form-control text-danger" id="hours"
                                                value="<?php echo e($evento->hstart); ?>" readonly>
                                        </div>
                                        <div class="col-3 mb-3">
                                            <label for="title" class="form-label"><?php echo e(__('Size')); ?></label>
                                            <div class="col-auto ">
                                                <input type="text" class="form-control text-danger" id="hours"
                                                    value="<?php echo e($evento->sz); ?>" readonly>
                                            </div>
                                        </div>
                                        <div class="col-3 mb-3">
                                            <label for="title" class="form-label"><?php echo e(__('Time')); ?></label>
                                            <div class="col-auto ">
                                                <input type="text" class="form-control text-danger" id="hours"
                                                    value="<?php echo e($evento->time); ?>" readonly>
                                            </div>
                                        </div>
                                        <div class="col-6 mb-3">
                                            <label for="title" class="form-label"><?php echo e(__('Regulation')); ?></label>
                                            <div class="col-auto ">
                                                <select class="form-control text-danger" disabled>
                                                    <option <?php if($evento->trl == 'cls'): ?> selected <?php endif; ?>>
                                                        <?php echo e(__('Coliseum')); ?></option>
                                                    <option <?php if($evento->trl == 'dpt'): ?> selected <?php endif; ?>>
                                                        <?php echo e(__('Departmental')); ?></option>
                                                    <option <?php if($evento->trl == 'nac'): ?> selected <?php endif; ?>>
                                                        <?php echo e(__('National')); ?> </option>
                                                    <option <?php if($evento->trl == 'inc'): ?> selected <?php endif; ?>>
                                                        <?php echo e(__('International')); ?>

                                                    </option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-sm-8 mb-3">
                                            <label for="dates" class="form-label"><?php echo e(__('Dates')); ?></label>
                                            <div class="row">
                                                <?php $__currentLoopData = $evento->fechas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fecha): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <div class="col-6 mb-1">
                                                        <label type="text" class="form-control text-danger">
                                                            <?php echo e($fecha); ?>

                                                        </label>
                                                    </div>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </div>
                                        </div>
                                        <div class="col-sm-4 mb-3">
                                            <label class="form-label"><?php echo e(__('Spurs')); ?></label>
                                            <ul class="list-group list-group-flush">
                                                <?php $__currentLoopData = $evento->spl; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $spl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <li class="list-group-item text-danger">
                                                        <?php if($spl == 'lbr'): ?>
                                                            Libre
                                                        <?php elseif($spl == 'fbr'): ?>
                                                            Fibra
                                                        <?php elseif($spl == 'plt'): ?>
                                                            Plastica
                                                        <?php elseif($spl == 'cry'): ?>
                                                            Carey
                                                        <?php elseif($spl == 'spn'): ?>
                                                            Espina
                                                        <?php endif; ?>
                                                    </li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-12 col-xl-6">
                            <div class="card h-100 bg-black border border-danger">
                                <div class="card-header border border-danger fw-bold text-uppercase">
                                    <?php echo e(__('Award') . ': ' . $evento->awards); ?></div>
                                <div class="card-body border border-danger">
                                    <div class="row">
                                        <div class="col-12 col-lg-4 mb-3 my-auto">
                                            <label for="TROPHY" class="form-label"><?php echo e(__('TROPHYS')); ?></label>
                                            <div class="input-group">
                                                <div class="input-group-text">S/.</div>
                                                <input type="text" class="form-control text-danger" id="trophy"
                                                    value="<?php echo e($evento->trophys); ?>" readonly>
                                            </div>
                                        </div>
                                        <div class="col-6 col-lg-4 mb-3">
                                            <label for="ROOSTER"
                                                class="form-label"><?php echo e(__('ROOSTER') . ' ' . $evento->trooster . ' ' . __('seconds')); ?></label>
                                            <div class="input-group">
                                                <div class="input-group-text">S/.</div>
                                                <input type="text" class="form-control text-danger" id="rooster"
                                                    value="<?php echo e($evento->rooster); ?>" readonly>
                                            </div>
                                        </div>
                                        <div class="col-6 col-lg-4 mb-3">
                                            <label for="ROOSTER"
                                                class="form-label"><?php echo e(__('ROOSTER') . ' 10 ' . __('seconds')); ?>

                                            </label>
                                            <div class="input-group">
                                                <div class="input-group-text">S/.</div>
                                                <input type="text" class="form-control text-danger" id="rooster"
                                                    value="<?php echo e($evento->rooster); ?>" readonly>
                                            </div>
                                        </div>
                                        <div class="col-6 col-md-4 mb-3">
                                            <label for="fft" class="form-label"><?php echo e(__('1er Frente')); ?></label>
                                            <div class="input-group">
                                                <div class="input-group-text">S/.</div>
                                                <input type="text" class="form-control text-danger" id="fft"
                                                    value="<?php echo e($evento->fft); ?>" readonly>
                                            </div>
                                        </div>
                                        <div class="col-6 col-md-4 mb-3">
                                            <label for="sft" class="form-label"><?php echo e(__('2do Frente')); ?></label>
                                            <div class="input-group">
                                                <div class="input-group-text">S/.</div>
                                                <input type="text" class="form-control text-danger" id="sft"
                                                    value="<?php echo e($evento->sft); ?>" readonly>
                                            </div>
                                        </div>
                                        <div class="col-6 col-md-4 mb-3">
                                            <label for="tft" class="form-label"><?php echo e(__('3er Frente')); ?></label>
                                            <div class="input-group">
                                                <div class="input-group-text">S/.</div>
                                                <input type="text" class="form-control text-danger" id="tft"
                                                    value="<?php echo e($evento->tft); ?>" readonly>
                                            </div>
                                        </div>
                                        <div class="col-6 col-md-4 mb-3">
                                            <label for="tft" class="form-label"><?php echo e(__('Fight quality')); ?></label>
                                            <div class="input-group">
                                                <div class="input-group-text">S/.</div>
                                                <input type="text" class="form-control text-danger" id="fcd"
                                                    value="<?php echo e($evento->fcd); ?>" readonly>
                                            </div>
                                        </div>
                                        <div class="col-6 col-md-4 mb-3">
                                            <label for="pvs" class="form-label"><?php echo e(__('Turkeys')); ?></label>
                                            <input type="number" class="form-control text-danger" id="pvs"
                                                value="<?php echo e($evento->pvs); ?>" readonly>
                                        </div>
                                        <div class="col-6 col-md-4  mb-3">
                                            <label for="lch" class="form-label"><?php echo e(__('Piglets')); ?></label>
                                            <input type="number" class="form-control text-danger" id="lch"
                                                value="<?php echo e($evento->lch); ?>" readonly>
                                        </div>
                                        <div class="col-5 mb-3">
                                            <label for="cnt" class="form-label"><?php echo e(__('Baskets')); ?></label>
                                            <input type="number" class="form-control text-danger" id="cnt"
                                                value="<?php echo e($evento->cnt); ?>" readonly>
                                        </div>
                                        <div class="col-7 mb-3">
                                            <label for="skg" class="form-label"><?php echo e(__('Bags')); ?></label>
                                            <input id="skg" type="number" class="form-control text-danger"
                                                value="<?php echo e($evento->skg); ?>" readonly>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- MODAL TICKETS -->
    <div class="modal fade" id="Tickets" aria-hidden="true" aria-labelledby="AddExemplar" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content bg-black border border-danger">
                <div class="modal-header bg-black border border-danger">
                    
                    <button type="button" class="btn btn-danger bg-danger btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body bg-black border border-danger">
                    <div class="mb-3">
                        <div class="card h-100 bg-black border border-danger">
                            <div class="card-header border border-danger fw-bold text-uppercase">
                                <?php echo e(__('Tickets')); ?></div>
                            <div class="card-body border border-danger">
                                <div class="row">
                                    <div class="col-6 mb-3">
                                        <label for="egn" class="form-label"><?php echo e(__('GENERAL')); ?></label>
                                        <div class="input-group">
                                            <div class="input-group-text">S/.</div>
                                            <input type="text" class="form-control text-danger" id="egn"
                                                value="<?php echo e($evento->egn); ?>" readonly>
                                        </div>
                                    </div>
                                    <div class="col-6 mb-3">
                                        <label for="evp" class="form-label"><?php echo e(__('VIP')); ?></label>
                                        <div class="input-group">
                                            <div class="input-group-text">S/.</div>
                                            <input type="text" class="form-control text-danger" id="evp"
                                                value="<?php echo e($evento->evp); ?>" readonly>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="">
                        <div class="card h-100 bg-black border border-danger">
                            <div class="card-header border border-danger fw-bold text-uppercase">
                                <?php echo e(__('inscriptions')); ?></div>
                            <div class="card-body border border-danger">
                                <div class="row">
                                    <div class="col-12 col-lg-4 mb-3">
                                        <label for="ift" class="form-label"><?php echo e(__('Forehead')); ?></label>
                                        <div class="input-group">
                                            <div class="input-group-text">S/.</div>
                                            <input type="text" class="form-control text-danger" id="ift"
                                                value="<?php echo e($evento->ift); ?>" readonly>
                                        </div>
                                    </div>
                                    <div class="col-12 col-lg-4 mb-3">
                                        <label for="gll" class="form-label"><?php echo e(__('Cock')); ?></label>
                                        <div class="input-group">
                                            <div class="input-group-text">S/.</div>
                                            <input type="text" class="form-control text-danger" id="gll"
                                                value="<?php echo e($evento->gll); ?>" readonly>
                                        </div>
                                    </div>
                                    <div class="col-12 col-lg-4 mb-3">
                                        <label for="glp" class="form-label"><?php echo e(__('Shed')); ?></label>
                                        <div class="input-group">
                                            <div class="input-group-text">S/.</div>
                                            <input type="text" class="form-control text-danger" id="glp"
                                                value="<?php echo e($evento->glp); ?>" readonly>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    
    <link rel="stylesheet" href="<?php echo e(asset('css/datatable/dataTables.bootstrap5.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/datatable/buttons.dataTables.min.css')); ?>">
    
    <script src="<?php echo e(asset('js/datatable/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/datatable/dataTables.bootstrap5.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/datatable/dataTables.buttons.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/ajax/jszip.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/ajax/pdfmake.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/ajax/vfs_fonts.js')); ?>"></script>
    <script src="<?php echo e(asset('js/datatable/buttons.html5.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/datatable/buttons.print.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/datatable/buttons.print.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/datatable/sorting/date-eu.js')); ?>"></script>

    
    
    <script>
        function getLanguage() {
            var lang = $('html').attr('lang');
            if (lang == 'es') {
                lng = "es-ES";
            } else if (lang == 'en') {
                lng = "en-GB";
            }
            var result = null;
            var path = 'https://cdn.datatables.net/plug-ins/1.11.5/i18n/';
            result = path + lng + ".json";
            return result;
        }
        // Build Datatable
        $('#datatable').DataTable({
            language: {
                "url": getLanguage()
            },
            "columnDefs": [{
                "targets": 0,
                "type": "date-eu"
            }],
            bInfo: false,
            lengthChange: false,
            pageLength: 10,
            lengthMenu: [
                [10],
                [10]
            ]
        });
        /* MASCOTA */
        function displayVals() {
            var id = $('#mascota_id').val();
            $.ajax({
                type: 'GET', //THIS NEEDS TO BE GET
                url: '/participants/' + id,
                dataType: 'json',
                success: function(data) {
                    console.log(data);
                    $.each(data, function(i, item) {
                        $("#mreggal").val(item.REGGAL);
                    });
                },
                error: function() {
                    console.log(data);
                }
            });
        };
        $("#mascota_id").change(displayVals);
        displayVals();
        //HIDE
        setTimeout(function() {
            $('.alert').fadeOut(3000);
        });
        /*  DONT COPY OR PASTE*/
        $(document).ready(function() {
            $('input').bind('copy paste', function(e) {
                e.preventDefault();
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>