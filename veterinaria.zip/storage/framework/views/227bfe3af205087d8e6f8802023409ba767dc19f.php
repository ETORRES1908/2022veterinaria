<?php $__env->startSection('content'); ?>
    <div class="card bg-black border border-danger">
        <div class="card-header fw-bold fs-3 border border-danger"><?php echo e(__('Register')); ?></div>
        <div class="card-body border border-danger">
            <form class="form-horizontal" method="POST" action="<?php echo e(route('register')); ?>" enctype="multipart/form-data"
                autocomplete="off">
                <?php echo csrf_field(); ?>

                
                <div class="row">
                    
                    <div class="row col-lg-8">
                        
                        <div class="col-sm-8 mb-3 form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                            <label for="name" class="col-form-label fw-bold">
                                <?php echo e(__('User')); ?>/<?php echo e(__('Name Social')); ?>

                            </label>

                            <div class="col-auto">
                                <input id="name" type="text" class="form-control text-danger" name="name"
                                    value="<?php echo e(old('name')); ?>" required autofocus maxlength="12">

                                <?php if($errors->has('name')): ?>
                                    <span class="text-da nger fs-6">
                                        <?php echo e($errors->first('name')); ?>

                                    </span>
                                <?php endif; ?>

                            </div>
                        </div>
                        
                        <div class="col-sm-4 mb-3 form-group<?php echo e($errors->has('usert') ? ' has-error' : ''); ?>">
                            <label for="usert" class="col-form-label fw-bold">
                                <?php echo e(__('Sign Up as')); ?>

                            </label>
                            <div class="col-auto">
                                <select name="usert" class="form-select text-danger" required autofocus>
                                    <option value="own"><?php echo e(__('Owner')); ?></option>
                                    <option value="cls"><?php echo e(__('Coliseum')); ?></option>
                                    <option value="cdk"><?php echo e(__('Control desk')); ?></option>
                                    <option value="jdg"><?php echo e(__('Judge')); ?></option>
                                    <option value="ppr"><?php echo e(__('Preparer')); ?></option>
                                    <option value="asst"><?php echo e(__('Assistant')); ?></option>
                                    <option value="amt"><?php echo e(__('Amateur')); ?></option>
                                </select>
                                <?php if($errors->has('usert')): ?>
                                    <span class="text-da nger fs-6">
                                        <?php echo e($errors->first('usert')); ?>

                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        
                        <div class="col-6 mb-3 form-group<?php echo e($errors->has('nombre') ? ' has-error' : ''); ?>">
                            <label for="nombre" class="col-form-label fw-bold">
                                <?php echo e(__('Name')); ?>

                            </label>
                            <div class="col-auto">
                                <input type="text" class="form-control text-danger" name="nombre"
                                    value="<?php echo e(old('nombre')); ?>" required autofocus pattern="[A-zÀ-ú\S]+" maxlength="10"
                                    onkeydown="return /[A-zÀ-ú]/i.test(event.key)" />

                                <?php if($errors->has('nombre')): ?>
                                    <span class="text-danger text-fs6">
                                        <?php echo e($errors->first('nombre')); ?>

                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        
                        <div class="col-6 mb-3 form-group<?php echo e($errors->has('apellido') ? ' has-error' : ''); ?>">
                            <label for="apellido" class="col-form-label fw-bold">
                                <?php echo e(__('Surname')); ?>

                            </label>

                            <div class="col-auto">
                                <input id="apellido" type="text" class="form-control  text-danger" name="apellido"
                                    value="<?php echo e(old('apellido')); ?>" autofocus required pattern="[A-zÀ-ú\S]+" maxlength="10"
                                    onkeydown="return /[A-zÀ-ú]/i.test(event.key)">

                                <?php if($errors->has('apellido')): ?>
                                    <span class="text-danger text-fs6">
                                        <?php echo e($errors->first('apellido')); ?>

                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        
                        <div class="col-6 mb-3 form-group<?php echo e($errors->has('discapacidad') ? ' has-error' : ''); ?>">
                            <label for="discapacidad" class="col-form-label fw-bold">
                                <?php echo e(__('Disability')); ?>

                            </label>
                            <select class="form-select text-danger" id="discapacidad" name="discapacidad"
                                value="<?php echo e(old('discapacidad')); ?>" required autofocus>
                                <option value="No" <?php if(old('discapacidad') == 'No'): ?> selected <?php endif; ?>><?php echo e(__('No')); ?>

                                </option>
                                <option value="Visual" <?php if(old('discapacidad') == 'Visual'): ?> selected <?php endif; ?>>
                                    <?php echo e(__('Visual')); ?>

                                </option>
                                <option value="Fisica" <?php if(old('discapacidad') == 'Fisica'): ?> selected <?php endif; ?>>
                                    <?php echo e(__('Physical')); ?>

                                </option>
                                <option value="Auditiva" <?php if(old('discapacidad') == 'Auditiva'): ?> selected <?php endif; ?>>
                                    <?php echo e(__('Auditory')); ?></option>
                                <option value="Verbal" <?php if(old('discapacidad') == 'Verbal'): ?> selected <?php endif; ?>>
                                    <?php echo e(__('Verbal')); ?>

                                </option>
                                <option value="Mental" <?php if(old('discapacidad') == 'Mental'): ?> selected <?php endif; ?>>
                                    <?php echo e(__('Mental')); ?>

                                </option>
                            </select>

                            <?php if($errors->has('discapacidad')): ?>
                                <span class="text-danger text-fs6">
                                    <?php echo e($errors->first('discapacidad')); ?>

                                </span>
                            <?php endif; ?>
                        </div>
                        
                        <div class="col-6 mb-3 form-group<?php echo e($errors->has('dni') ? ' has-error' : ''); ?>">
                            <label for="dni" class="col-form-label fw-bold">
                                <?php echo e(__('N°DNI')); ?>

                            </label>

                            <div class="col-auto">
                                <input id="dni" type="number" class="form-control  text-danger" name="dni"
                                    value="<?php echo e(old('dni')); ?>" onKeyPress="if(this.value.length==8) return false;"
                                    onkeydown="return event.keyCode !== 69 && event.keyCode !== 189" required autofocus
                                    minlength="8" maxlength="8">

                                <?php if($errors->has('dni')): ?>
                                    <span class="text-danger text-fs6">
                                        <?php echo e($errors->first('dni')); ?>

                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-lg-4 mb-3 form-group<?php echo e($errors->has('foto') ? ' has-error' : ''); ?>">
                        <label for="foto" class="col-form-label fw-bold">
                            <?php echo e(__('Photo')); ?>

                        </label>
                        <div class="col-auto m-1 bg-black rounded">
                            <img id="preview" class="mx-auto d-block" height="200" width="180" />
                            <input id="foto" type="file" class="form-control form-control-sm" name="foto"
                                value="<?php echo e(old('foto')); ?>" required autofocus accept="image/*">
                        </div>
                        <?php if($errors->has('foto')): ?>
                            <span class="text-danger fs-6">
                                <?php echo e($errors->first('foto')); ?>

                            </span>
                        <?php endif; ?>
                    </div>
                </div>
                
                <div class="row" id="fdb" style="display: none">
                    
                    <div class="col-sm-6 mb-3 text-center form-group<?php echo e($errors->has('fdpt') ? ' has-error' : ''); ?>">
                        <label for="sdpt" class="col-form-label fw-bold text-capitalize">
                            <?php echo e(__('document')); ?> <?php echo e(__('Disability')); ?>

                        </label>
                        <div class="col-auto bg-black rounded">
                            <div style="clear:both">
                                <iframe id="viewer" frameborder="0" scrolling="no" height="200" width="100%"></iframe>
                            </div>
                            <input type="file" id="fdpt" name="fdpt" class="form-control form-control-sm"
                                value="<?php echo e(old('fdpt')); ?>" accept=".pdf">
                        </div>
                        <?php if($errors->has('fdpt')): ?>
                            <span class="text-danger fs-6">
                                <?php echo e($errors->first('fdpt')); ?>

                            </span>
                        <?php endif; ?>
                    </div>
                    
                    <div class="col-sm-6 mb-3 text-center form-group<?php echo e($errors->has('sdpt') ? ' has-error' : ''); ?>">
                        <label for="sdpt" class="col-form-label fw-bold text-capitalize">
                            <?php echo e(__('Photo')); ?> <?php echo e(__('Disability')); ?>

                        </label>
                        <div class="col-auto m-1 bg-black rounded">
                            <img id="sdview" class="mx-auto d-block" height="200" width="180" />
                            <input id="sdpt" type="file" class="form-control form-control-sm" name="sdpt"
                                value="<?php echo e(old('sdpt')); ?>" accept="image/*">
                        </div>

                        <?php if($errors->has('sdpt')): ?>
                            <span class="text-danger fs-6">
                                <?php echo e($errors->first('sdpt')); ?>

                            </span>
                        <?php endif; ?>
                    </div>
                </div>
                
                <div class="row">
                    
                    <div class="col-sm-6 mb-3 form-group<?php echo e($errors->has('galpon') ? ' has-error' : ''); ?>">
                        <label for="galpon" class="col-form-label fw-bold">
                            <?php echo e(__('Shed')); ?>

                        </label>
                        <div class="col-auto">
                            <input id="galpon" type="text" class="form-control  text-danger" name="galpon"
                                value="<?php echo e(old('galpon')); ?>" maxlength="14" required autofocus>

                            <?php if($errors->has('galpon')): ?>
                                <span class="text-danger text-fs6">
                                    <?php echo e($errors->first('galpon')); ?>

                                </span>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                    <div class="col-sm-6 mb-3 form-group<?php echo e($errors->has('prepa') ? ' has-error' : ''); ?>">
                        <label for="prepa" class="col-form-label fw-bold">
                            <?php echo e(__('Preparer')); ?>

                        </label>

                        <div class="col-auto">
                            <input id="prepa" type="text" class="form-control  text-danger" name="prepa"
                                value="<?php echo e(old('prepa')); ?>" maxlength="14" required autofocus>

                            <?php if($errors->has('prepa')): ?>
                                <span class="text-danger text-fs6">
                                    <?php echo e($errors->first('prepa')); ?>

                                </span>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                
                <div class="row">
                    
                    <div class="col-sm-6 mb-3 form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                        <label for="email" class="col-form-label fw-bold">
                            <?php echo e(__('E-Mail Address')); ?>

                        </label>

                        <div class="col">
                            <input id="email" type="email" class="form-control  text-danger" name="email"
                                value="<?php echo e(old('email')); ?>" maxlength="20" required autofocus>

                            <?php if($errors->has('email')): ?>
                                <span class="text-danger text-fs6">
                                    <?php echo e($errors->first('email')); ?>

                                </span>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                    <div class="col-sm-3 mb-3 form-group<?php echo e($errors->has('company') ? ' has-error' : ''); ?>">
                        <label for="company" class="col-form-label fw-bold">
                            <?php echo e(__('Operator')); ?>

                        </label>

                        <div class="col-auto">
                            <select class="form-select text-danger text-uppercase" name="company" required autofocus>
                                <option value="bitel" <?php if(old('company') == 'bitel'): ?> selected <?php endif; ?>>BITEL</option>
                                <option value="claro" <?php if(old('company') == 'claro'): ?> selected <?php endif; ?>>CLARO</option>
                                <option value="entel" <?php if(old('company') == 'entel'): ?> selected <?php endif; ?>>ENTEL</option>
                                <option value="movitar" <?php if(old('company') == 'movitar'): ?> selected <?php endif; ?>>MOVISTAR
                                </option>
                                <option value="otro" <?php if(old('company') == 'otro'): ?> selected <?php endif; ?>>
                                    <?php echo e(__('Other')); ?></option>
                            </select>

                            <?php if($errors->has('company')): ?>
                                <span class="text-danger text-fs6">
                                    <?php echo e($errors->first('company')); ?>

                                </span>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                    <div class="col-sm-3 mb-3 form-group<?php echo e($errors->has('celular') ? ' has-error' : ''); ?>">
                        <label for="celular" class="col-form-label fw-bold">
                            <?php echo e(__('Phone')); ?>

                        </label>
                        <div class="col-auto">
                            <input id="celular" type="number" class="form-control  text-danger" name="celular" minlength="9"
                                value="<?php echo e(old('celular')); ?>" onKeyPress="if(this.value.length==9) return false;"
                                minlength="9" onkeydown="return event.keyCode !== 69 && event.keyCode !== 189" required
                                autofocus>

                            <?php if($errors->has('celular')): ?>
                                <span class="text-danger text-fs6">
                                    <?php echo e($errors->first('celular')); ?>

                                </span>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                
                <div class="row">
                    
                    <div class="col-md-4 mb-3 form-group<?php echo e($errors->has('country') ? ' has-error' : ''); ?>">
                        <label for="country" class="col-form-label fw-bold">
                            <?php echo e(__('Country')); ?>

                        </label>

                        <div class="col">
                            <select class="select2 form-control form-select text-danger fw-bold" name="country" id="country"
                                value="<?php echo e(old('country')); ?>" required autofocus>
                                <option class="text-danger fw-bold" value="PER"
                                    <?php if(old('country') == 'PER'): ?> selected <?php endif; ?>>PER - Perú</option>
                            </select>


                            <?php if($errors->has('country')): ?>
                                <span class="text-danger text-fs6">
                                    <?php echo e($errors->first('country')); ?>

                                </span>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                    <div class="col-sm-4 mb-3 form-group<?php echo e($errors->has('state') ? ' has-error' : ''); ?>">
                        <label for="state" class="col-form-label fw-bold">
                            <?php echo e(__('State')); ?>

                        </label>

                        <div class="col-auto">
                            <select class="form-control text-danger fw-bold" name="state" id="state"
                                value="<?php echo e(old('state')); ?>" required autofocus>
                                <option data="PER" class="text-danger fw-bold" value="AM"
                                    <?php if(old('state') == 'AM'): ?> selected <?php endif; ?>>
                                    AM - Amazonas</option>
                                <option data="PER" class="text-danger fw-bold" value="AN"
                                    <?php if(old('state') == 'AN'): ?> selected <?php endif; ?>>
                                    AN - Ancash
                                </option>
                                <option data="PER" class="text-danger fw-bold" value="AP"
                                    <?php if(old('state') == 'AP'): ?> selected <?php endif; ?>>
                                    AP - Apurímac
                                </option>
                                <option data="PER" class="text-danger fw-bold" value="AR"
                                    <?php if(old('state') == 'AR'): ?> selected <?php endif; ?>>
                                    AR - Arequipa
                                </option>
                                <option data="PER" class="text-danger fw-bold" value="AY"
                                    <?php if(old('state') == 'AY'): ?> selected <?php endif; ?>>
                                    AY - Ayacucho
                                </option>
                                <option data="PER" class="text-danger fw-bold" value="CJ"
                                    <?php if(old('state') == 'CJ'): ?> selected <?php endif; ?>>
                                    CJ - Cajamarca
                                </option>
                                <option data="PER" class="text-danger fw-bold" value="CZ"
                                    <?php if(old('state') == 'CZ'): ?> selected <?php endif; ?>>
                                    CZ - Cuzco
                                </option>
                                <option data="PER" class="text-danger fw-bold" value="HC"
                                    <?php if(old('state') == 'HC'): ?> selected <?php endif; ?>>
                                    HC - Huancavelica</option>
                                <option data="PER" class="text-danger fw-bold" value="HU"
                                    <?php if(old('state') == 'HU'): ?> selected <?php endif; ?>>
                                    HU - Huánuco
                                </option>
                                <option data=" PER" class="text-danger fw-bold" value="IC"
                                    <?php if(old('state') == 'IC'): ?> selected <?php endif; ?>>
                                    IC - Ica
                                </option>
                                <option data="PER" class="text-danger fw-bold" value="JU"
                                    <?php if(old('state') == 'JU'): ?> selected <?php endif; ?>>
                                    JU - Junín
                                </option>
                                <option data=" PER" class="text-danger fw-bold" value="LL"
                                    <?php if(old('state') == 'LL'): ?> selected <?php endif; ?>>
                                    LL - La Libertad</option>
                                <option data="PER" class="text-danger fw-bold" value="LB"
                                    <?php if(old('state') == 'LB'): ?> selected <?php endif; ?>>
                                    LB - Lambayeque</option>
                                <option data="PER" class="text-danger fw-bold" value="LM"
                                    <?php if(old('state') == 'LM'): ?> selected <?php endif; ?> selected>
                                    LM - Lima
                                </option>
                                <option data="PER" class="text-danger fw-bold" value="LO"
                                    <?php if(old('state') == 'LO'): ?> selected <?php endif; ?>>
                                    LO - Loreto
                                </option>
                                <option data="PER" class="text-danger fw-bold" value="MD"
                                    <?php if(old('state') == 'MD'): ?> selected <?php endif; ?>>
                                    MD - Madre de Dios</option>
                                <option data="PER" class="text-danger fw-bold" value="MQ"
                                    <?php if(old('state') == 'MQ'): ?> selected <?php endif; ?>>
                                    MQ - Moquegua</option>
                                <option data="PER" class="text-danger fw-bold" value="PA"
                                    <?php if(old('state') == 'PA'): ?> selected <?php endif; ?>>
                                    PA - Pasco
                                </option>
                                <option data="PER" class="text-danger fw-bold" value="PI"
                                    <?php if(old('state') == 'PI'): ?> selected <?php endif; ?>>
                                    PI - Piura
                                </option>
                                <option data="PER" class="text-danger fw-bold" value="PU"
                                    <?php if(old('state') == 'PU'): ?> selected <?php endif; ?>>
                                    PU - Puno
                                </option>
                                <option data="PER" class="text-danger fw-bold" value="SM"
                                    <?php if(old('state') == 'SM'): ?> selected <?php endif; ?>>
                                    SM - San Martín</option>
                                <option data="PER" class="text-danger fw-bold" value="TA"
                                    <?php if(old('state') == 'TA'): ?> selected <?php endif; ?>>
                                    TA - Tacna
                                </option>
                                <option data="PER" class="text-danger fw-bold" value="TU"
                                    <?php if(old('state') == 'TU'): ?> selected <?php endif; ?>>
                                    TU - Tumbes
                                </option>
                                <option data=" PER" class="text-danger fw-bold" value="UC"
                                    <?php if(old('state') == 'UC'): ?> selected <?php endif; ?>>
                                    UC - Ucayali</option>
                            </select>

                            <?php if($errors->has('state')): ?>
                                <span class="text-danger text-fs6">
                                    <?php echo e($errors->first('state')); ?>

                                </span>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                    <div class="col-sm-4 mb-3 form-group<?php echo e($errors->has('district') ? ' has-error' : ''); ?>">
                        <label for="district" class="col-form-label fw-bold">
                            <?php echo e(__('District')); ?>

                        </label>
                        <div class="col-auto">
                            <input id="district" type="text" class="form-control  text-danger" name="district"
                                value="<?php echo e(old('district')); ?>" maxlength="10" required autofocus>

                            <?php if($errors->has('district')): ?>
                                <span class="text-danger text-fs6">
                                    <?php echo e($errors->first('district')); ?>

                                </span>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                
                <div class="row">
                    
                    <div class="col-sm-7 mb-3 form-group<?php echo e($errors->has('direction') ? ' has-error' : ''); ?>">
                        <label for="direction" class="col-form-label fw-bold">
                            <?php echo e(__('Direction')); ?>

                        </label>
                        <div class="col-auto">
                            <input id="direction" type="text" class="form-control  text-danger" name="direction"
                                value="<?php echo e(old('direction')); ?>" maxlength="30" required autofocus
                                placeholder="REF. ó ALT.">

                            <?php if($errors->has('direction')): ?>
                                <span class="text-danger text-fs6">
                                    <?php echo e($errors->first('direction')); ?>

                                </span>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                    <div class="col-sm-5 mb-3 form-group<?php echo e($errors->has('job') ? ' has-error' : ''); ?>">
                        <label for="job" class="col-form-label fw-bold">
                            <?php echo e(__('Profession or Trade')); ?>

                        </label>
                        <div class="col-auto">
                            <input id="job" type="text" class="form-control  text-danger" name="job"
                                value="<?php echo e(old('job')); ?>" maxlength="15" required autofocus>

                            <?php if($errors->has('job')): ?>
                                <span class="text-danger text-fs6">
                                    <?php echo e($errors->first('job')); ?>

                                </span>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                
                <div class="row">
                    
                    <div class="col-sm-6 mb-3 form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                        <label for="password" class="col-form-label fw-bold"
                            onKeyPress="if(this.value.length==8) return false;">
                            <?php echo e(__('Password')); ?>

                        </label>

                        <div class="col-auto">
                            <input type="password" class="form-control text-danger" name="password" min="8"
                                onKeyPress="if(this.value.length==8) return false;" pattern="^(?=\D*\d)(?=.*?[a-zA-Z]).{8}"
                                required autofocus>


                            <?php if($errors->has('password')): ?>
                                <span class="text-danger text-fs6">
                                    <?php echo e($errors->first('password')); ?>

                                </span>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                    <div class="col-sm-6 mb-3 form-group">
                        <label for="password-confirm" class="col-form-label fw-bold">
                            <?php echo e(__('Confirm Password')); ?>

                            
                        </label>
                        <span data-bs-toggle="popover" data-bs-trigger="hover focus"
                            data-bs-content="<?php echo e(__('Must contain 1 letter 1 number, minimum 8')); ?>">
                            <input type="button" class="btn btn-primary py-0" value="?">
                        </span>
                        <div class="col-auto">
                            <input type="password" class="form-control  text-danger" name="password_confirmation" required
                                onKeyPress="if(this.value.length==8) return false;" autofocus>
                        </div>
                        <?php if($errors->has('password_confirmation')): ?>
                            <span class="text-danger text-fs6">
                                <?php echo e($errors->first('password_confirmation')); ?>

                            </span>
                        <?php endif; ?>
                    </div>
                </div>
                
                <div class="col-sm-12 mb-3 form-group<?php echo e($errors->has('question') ? ' has-error' : ''); ?>">
                    <label for="answer" class="col-auto col-form-label fw-bold text-capitalize">
                        <?php echo e(__('secrect answer')); ?>

                    </label>
                    <input id="answer" type="text" class="form-control text-danger" name="answer" maxlength="10"
                        placeholder="<?php echo e(__('Answer')); ?>..." value="<?php echo e(old('answer')); ?>" required autofocus>
                    <?php if($errors->has('answer')): ?>
                        <span class="text-danger text-fs6">
                            <?php echo e($errors->first('answer')); ?>

                        </span>
                    <?php endif; ?>
                </div>
                
                <div class="col-sm-6 mx-auto mb-3 form-group<?php echo e($errors->has('captcha') ? ' has-error' : ''); ?>">
                    
                    <div for="Captcha" class="col-form-label fw-bold">
                        <span class="captcha-img col-sm-8">
                            <?php echo captcha_img(); ?>

                        </span>
                    </div>
                    
                    <div class="col-sm-7 col-form-label">
                        <input id="captcha" type="text" class="form-control text-danger fs-3 fw-bold" name="captcha"
                            required autofocus maxlength="5">

                        <?php if($errors->has('captcha')): ?>
                            <span class="fs-6 text-danger">
                                <?php echo e($errors->first('captcha')); ?>

                            </span>
                        <?php endif; ?>
                    </div>
                </div>
                
                <div class="col-sm-12 mb-3 ">
                    <button type="submit" class="btn btn-primary ">
                        <?php echo e(__('Register')); ?>

                    </button>
                </div>
            </form>
        </div>
    </div>

    
    <script>
        /*  POPOVER  */
        var popoverTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="popover"]'))
        var popoverList = popoverTriggerList.map(function(popoverTriggerEl) {
            return new bootstrap.Popover(popoverTriggerEl)
        })
        /* PREVIEW */
        foto.onchange = evt => {
            const [file] = foto.files
            if (file) {
                preview.src = URL.createObjectURL(file)
            }
        };
        /* DISABILITY */
        $("#discapacidad").change(function() {
            if ($("#discapacidad").val() != 'No') {
                $('#fdb').show(600);
            }
            if ($("#discapacidad").val() == 'No') {
                $('#fdb').hide(600);
            }
            /* PREVIEW */
            sdpt.onchange = evt => {
                const [file] = sdpt.files
                if (file) {
                    sdview.src = URL.createObjectURL(file)
                }
            };
        }).change();
        /* STATE -  */
        var $select1 = $('#country'),
            $select2 = $('#state'),
            $options = $select2.find('option');

        $select1.on('change', function() {
            $select2.html($options.filter('[data="' + this.value + '"]'));
        }).trigger('change');
        /*  DONT COPY OR PASTE*/
        $(document).ready(function() {
            $('input').bind('cut copy paste', function(e) {
                e.preventDefault();
            });
        });
        /* DISABILITY DOCUMENT */
        fdpt.onchange = evt => {
            pdffile = document.getElementById("fdpt").files[0];
            pdffile_url = URL.createObjectURL(pdffile);
            $('#viewer').attr('src', pdffile_url);
        };
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>