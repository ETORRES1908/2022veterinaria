<?php $__env->startSection('content'); ?>
    <div class="card col-xl-8 mx-auto text-black">
        <div class="card-header fw-bold fs-3"><?php echo e(__('Register')); ?></div>
        <div class="card-body ">
            <form class="form-horizontal" method="POST" action="<?php echo e(route('register')); ?>" enctype="multipart/form-data">
                <?php echo e(csrf_field()); ?>

                
                <div class="row">
                    
                    <div class="row col-sm-8">
                        
                        <div class="mb-3 form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                            <label for="name" class="col-form-label fw-bold">
                                <?php echo e(__('Username')); ?>/<?php echo e(__('Nickname')); ?>

                            </label>

                            <div class="col-auto">
                                <input id="name" type="text" class="form-control text-danger" name="name"
                                    value="<?php echo e(old('name')); ?>" required autofocus>

                                <?php if($errors->has('name')): ?>
                                    <span class="text-da nger fs-6">
                                        <?php echo e($errors->first('name')); ?>

                                    </span>
                                <?php endif; ?>

                            </div>
                        </div>

                        
                        <div class="col-sm-6 mb-3 form-group<?php echo e($errors->has('nombre') ? ' has-error' : ''); ?>">
                            <label for="nombre" class="col-form-label fw-bold">
                                <?php echo e(__('Name')); ?>

                            </label>
                            <div class="col-auto">
                                <input type="text" class="form-control text-danger" name="nombre"
                                    value="<?php echo e(old('nombre')); ?>" required pattern="[A-zÀ-ú\S]+" maxlength="10">

                                <?php if($errors->has('nombre')): ?>
                                    <span class="text-danger text-fs6">
                                        <?php echo e($errors->first('nombre')); ?>

                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        
                        <div class="col-sm-6 mb-3 form-group<?php echo e($errors->has('apellido') ? ' has-error' : ''); ?>">
                            <label for="apellido" class="col-form-label fw-bold">
                                <?php echo e(__('Surname')); ?>

                            </label>

                            <div class="col-auto">
                                <input id="apellido" type="text" class="form-control  text-danger" name="apellido"
                                    value="<?php echo e(old('apellido')); ?>" required pattern="[A-zÀ-ú\S]+" maxlength="10">

                                <?php if($errors->has('apellido')): ?>
                                    <span class="text-danger text-fs6">
                                        <?php echo e($errors->first('apellido')); ?>

                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-sm-4 mb-3 form-group<?php echo e($errors->has('foto') ? ' has-error' : ''); ?>">
                        <label for="foto" class="col-form-label fw-bold">
                            <?php echo e(__('Photo')); ?>

                        </label>
                        <div class="col-auto m-1 bg-black rounded">
                            <img id="preview" class="mx-auto d-block" height="200" width="180" />
                            <input id="foto" type="file" class="form-control form-control-sm" name="foto"
                                value="<?php echo e(old('foto')); ?>" required autofocus accept="image/*">
                        </div>

                        <?php if($errors->has('foto')): ?>
                            <span class="text-danger fs-6">
                                <?php echo e($errors->first('foto')); ?>

                            </span>
                        <?php endif; ?>
                    </div>
                </div>

                
                <div class="row">
                    
                    <div class="col-sm-4 mb-3 form-group<?php echo e($errors->has('discapacidad') ? ' has-error' : ''); ?>">
                        <label for="discapacidad" class="col-form-label fw-bold">
                            <?php echo e(__('Disability')); ?>

                        </label>
                        <select class="form-select text-danger" id="discapacidad" name="discapacidad"
                            value="<?php echo e(old('discapacidad')); ?>" required>
                            <option value="No" <?php if(old('discapacidad') == 'No'): ?> selected <?php endif; ?>><?php echo e(__('No')); ?>

                            </option>
                            <option value="Visual" <?php if(old('discapacidad') == 'Visual'): ?> selected <?php endif; ?>><?php echo e(__('Visual')); ?>

                            </option>
                            <option value="Fisica" <?php if(old('discapacidad') == 'Fisica'): ?> selected <?php endif; ?>><?php echo e(__('Physical')); ?>

                            </option>
                            <option value="Auditiva" <?php if(old('discapacidad') == 'Auditiva'): ?> selected <?php endif; ?>>
                                <?php echo e(__('Auditory')); ?></option>
                            <option value="Verbal" <?php if(old('discapacidad') == 'Verbal'): ?> selected <?php endif; ?>><?php echo e(__('Verbal')); ?>

                            </option>
                            <option value="Mental" <?php if(old('discapacidad') == 'Mental'): ?> selected <?php endif; ?>><?php echo e(__('Mental')); ?>

                            </option>
                        </select>

                        <?php if($errors->has('discapacidad')): ?>
                            <span class="text-danger text-fs6">
                                <?php echo e($errors->first('discapacidad')); ?>

                            </span>
                        <?php endif; ?>
                    </div>
                    
                    <div class="col-sm-8 mb-3 form-group<?php echo e($errors->has('dni') ? ' has-error' : ''); ?>">
                        <label for="dni" class="col-form-label fw-bold">
                            <?php echo e(__('N°DNI')); ?>

                        </label>

                        <div class="col-auto">
                            <input id="dni" type="number" class="form-control  text-danger" name="dni"
                                value="<?php echo e(old('dni')); ?>" required autofocus maxlength="7">

                            <?php if($errors->has('dni')): ?>
                                <span class="text-danger text-fs6">
                                    <?php echo e($errors->first('dni')); ?>

                                </span>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                
                <div class="row">
                    
                    <div class="col-sm-6 mb-3 form-group<?php echo e($errors->has('galpon') ? ' has-error' : ''); ?>">
                        <label for="galpon" class="col-form-label fw-bold">
                            <?php echo e(__('Galpon')); ?>

                        </label>
                        <div class="col-auto">
                            <input id="galpon" type="text" class="form-control  text-danger" name="galpon"
                                value="<?php echo e(old('galpon')); ?>" required autofocus>

                            <?php if($errors->has('galpon')): ?>
                                <span class="text-danger text-fs6">
                                    <?php echo e($errors->first('galpon')); ?>

                                </span>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                    <div class="col-sm-6 mb-3 form-group<?php echo e($errors->has('prepa') ? ' has-error' : ''); ?>">
                        <label for="prepa" class="col-form-label fw-bold">
                            <?php echo e(__('Trainer')); ?>

                        </label>

                        <div class="col-auto">
                            <input id="prepa" type="text" class="form-control  text-danger" name="prepa"
                                value="<?php echo e(old('prepa')); ?>" required autofocus>

                            <?php if($errors->has('prepa')): ?>
                                <span class="text-danger text-fs6">
                                    <?php echo e($errors->first('prepa')); ?>

                                </span>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                
                <div class="row">
                    
                    <div class="col-sm-6 mb-3 form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                        <label for="email" class="col-form-label fw-bold">
                            <?php echo e(__('E-Mail Address')); ?>

                        </label>

                        <div class="col">
                            <input id="email" type="email" class="form-control  text-danger" name="email"
                                value="<?php echo e(old('email')); ?>" required>

                            <?php if($errors->has('email')): ?>
                                <span class="text-danger text-fs6">
                                    <?php echo e($errors->first('email')); ?>

                                </span>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                    <div class="col-sm-3 mb-3 form-group<?php echo e($errors->has('company') ? ' has-error' : ''); ?>">
                        <label for="company" class="col-form-label fw-bold">
                            <?php echo e(__('Company')); ?>

                        </label>

                        <div class="col-auto">
                            <input id="company" type="text" class="form-control  text-danger" name="company"
                                value="<?php echo e(old('company')); ?>" required autofocus>

                            <?php if($errors->has('company')): ?>
                                <span class="text-danger text-fs6">
                                    <?php echo e($errors->first('company')); ?>

                                </span>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                    <div class="col-sm-3 mb-3 form-group<?php echo e($errors->has('celular') ? ' has-error' : ''); ?>">
                        <label for="celular" class="col-form-label fw-bold">
                            N°<?php echo e(__('Phone')); ?>

                        </label>
                        <div class="col-auto">
                            <input id="celular" type="text" class="form-control  text-danger" name="celular"
                                value="<?php echo e(old('celular')); ?>" required autofocus>

                            <?php if($errors->has('celular')): ?>
                                <span class="text-danger text-fs6">
                                    <?php echo e($errors->first('celular')); ?>

                                </span>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                
                <div class="row">
                    
                    <div class="col-md-4 mb-3 form-group<?php echo e($errors->has('country') ? ' has-error' : ''); ?>">
                        <label for="country" class="col-form-label fw-bold">
                            <?php echo e(__('Country')); ?>

                        </label>

                        <div class="col">
                            <input id="country" type="text" class="form-control  text-danger" name="country"
                                value="<?php echo e(old('email')); ?>" required>

                            <?php if($errors->has('country')): ?>
                                <span class="text-danger text-fs6">
                                    <?php echo e($errors->first('country')); ?>

                                </span>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                    <div class="col-sm-4 mb-3 form-group<?php echo e($errors->has('state') ? ' has-error' : ''); ?>">
                        <label for="state" class="col-form-label fw-bold">
                            <?php echo e(__('State')); ?>

                        </label>

                        <div class="col-auto">
                            <input id="state" type="text" class="form-control  text-danger" name="state"
                                value="<?php echo e(old('state')); ?>" required autofocus>

                            <?php if($errors->has('state')): ?>
                                <span class="text-danger text-fs6">
                                    <?php echo e($errors->first('state')); ?>

                                </span>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                    <div class="col-sm-4 mb-3 form-group<?php echo e($errors->has('district') ? ' has-error' : ''); ?>">
                        <label for="district" class="col-form-label fw-bold">
                            <?php echo e(__('District')); ?>

                        </label>
                        <div class="col-auto">
                            <input id="district" type="text" class="form-control  text-danger" name="district"
                                value="<?php echo e(old('district')); ?>" required autofocus>

                            <?php if($errors->has('district')): ?>
                                <span class="text-danger text-fs6">
                                    <?php echo e($errors->first('district')); ?>

                                </span>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                
                <div class="row">
                    
                    <div class="col-sm-7 mb-3 form-group<?php echo e($errors->has('direction') ? ' has-error' : ''); ?>">
                        <label for="direction" class="col-form-label fw-bold">
                            <?php echo e(__('Direction')); ?>

                        </label>
                        <div class="col-auto">
                            <input id="direction" type="text" class="form-control  text-danger" name="direction"
                                value="<?php echo e(old('direction')); ?>" required autofocus>

                            <?php if($errors->has('direction')): ?>
                                <span class="text-danger text-fs6">
                                    <?php echo e($errors->first('direction')); ?>

                                </span>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                    <div class="col-sm-5 mb-3 form-group<?php echo e($errors->has('job') ? ' has-error' : ''); ?>">
                        <label for="job" class="col-form-label fw-bold">
                            <?php echo e(__('Job')); ?>

                        </label>
                        <div class="col-auto">
                            <input id="job" type="text" class="form-control  text-danger" name="job"
                                value="<?php echo e(old('job')); ?>" required autofocus>

                            <?php if($errors->has('job')): ?>
                                <span class="text-danger text-fs6">
                                    <?php echo e($errors->first('job')); ?>

                                </span>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                
                <div class="row">
                    
                    <div class="col-sm-6 mb-3 form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                        <label for="password" class="col-form-label fw-bold">
                            <?php echo e(__('Password')); ?>

                        </label>

                        <div class="col-auto">
                            <input value="<?php echo e(old('password')); ?>" type="password" class="form-control text-danger"
                                name="password" required>

                            <?php if($errors->has('password')): ?>
                                <span class="text-danger text-fs6">
                                    <?php echo e($errors->first('password')); ?>

                                </span>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                    <div class="col-sm-6 mb-3 form-group">
                        <label for="password-confirm" class="col-form-label fw-bold">
                            <?php echo e(__('Confirm Password')); ?>

                            
                        </label>
                        <span data-bs-toggle="popover" data-bs-trigger="hover focus"
                            data-bs-content="Debe contener mayusculas, minusculas y un simbolo, min 8">
                            <button class="btn btn-primary py-0" type="button" disabled>?</button>
                        </span>
                        <div class="col-auto">
                            <input value="<?php echo e(old('password_confirmation')); ?>" type="password"
                                class="form-control  text-danger" name="password_confirmation" required>
                        </div>
                        <?php if($errors->has('password_confirmation')): ?>
                            <span class="text-danger text-fs6">
                                <?php echo e($errors->first('password_confirmation')); ?>

                            </span>
                        <?php endif; ?>
                    </div>
                </div>
                
                <div class="col-sm-12 mb-3 form-group<?php echo e($errors->has('question') ? ' has-error' : ''); ?>">
                    <label for="question" class="col-auto col-form-label fw-bold">
                        <?php echo e(__('Question to password')); ?>

                    </label>
                    <div class="row">
                        <div class="col-sm-12 col-form-label fw-bold">
                            <select class="form-control text-danger col-sm-12" id="question" name="question"
                                value="<?php echo e(old('question')); ?>" required>
                                <option selected disabled value="">Opciones...</option>
                                <option value="0" <?php if(old('question') == '0'): ?> selected <?php endif; ?>>
                                    ¿Nombre de la Primera mascota?</option>
                                <option value="1" <?php if(old('question') == '1'): ?> selected <?php endif; ?>>
                                    ¿Nombre de la ciudad natal?</option>
                                <option value="2" <?php if(old('question') == '2'): ?> selected <?php endif; ?>>
                                    ¿Nombre del mejor amigo de la infancia?</option>
                            </select>
                        </div>
                        <div class="col-sm-12 col-form-label fw-bold">
                            <input id="answer" type="text" class="form-control  text-danger" name="answer"
                                placeholder="Respuesta..." value="<?php echo e(old('answer')); ?>" required autofocus>

                            <?php if($errors->has('answer')): ?>
                                <span class="text-danger text-fs6">
                                    <?php echo e($errors->first('answer')); ?>

                                </span>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                
                <div class="col-sm-6 mx-auto mb-3 form-group<?php echo e($errors->has('captcha') ? ' has-error' : ''); ?>">
                    
                    <div for="Captcha" class="col-form-label fw-bold">
                        <span class="captcha-img col-sm-8">
                            <?php echo captcha_img(); ?>

                        </span>
                    </div>
                    
                    <div class="col-sm-7 col-form-label">
                        <input id="captcha" type="text" class="form-control text-danger fs-3 fw-bold" name="captcha"
                            required>

                        <?php if($errors->has('captcha')): ?>
                            <span class="fs-6 text-danger">
                                <?php echo e($errors->first('captcha')); ?>

                            </span>
                        <?php endif; ?>
                    </div>
                </div>
                
                <div class="col-sm-12 mb-3 ">
                    <button type="submit" class="btn btn-primary ">
                        <?php echo e(__('Register')); ?>

                    </button>
                </div>
            </form>
        </div>
    </div>

    
    <script>
        /*  POPOVER  */
        var popoverTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="popover"]'))
        var popoverList = popoverTriggerList.map(function(popoverTriggerEl) {
            return new bootstrap.Popover(popoverTriggerEl)
        })
        var popover = new bootstrap.Popover(document.querySelector('.popover-dismiss'), {
            trigger: 'focus'
        })
    </script>
    <script>
        /*  PREVIEW */
        foto.onchange = evt => {
            const [file] = foto.files
            if (file) {
                preview.src = URL.createObjectURL(file)
            }
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>