<?php $__env->startSection('content'); ?>
    <?php if(session('mensaje')): ?>
        <div class="alert alert-success">
            <?php echo e(session('mensaje')); ?>

        </div>
    <?php endif; ?>
    <div class="card bg-black border border-danger mb-3">
        <div class="card-body border border-danger">
            <h5 class="card-title fw-bold text-uppercase pe-none text-danger">
                REGGAL: <?php echo e($mascota->REGGAL); ?>

            </h5>
            <div class="row">
                <div class="col-lg-6  mb-3">
                    <div class="card-text">
                        <ul class="list-group list-group-flush">
                            <li class="list-group-item bg-black text-white">
                                <div><strong><?php echo e(__('Name')); ?>:</strong> <?php echo e($mascota->nombre); ?></div>
                            </li>
                            <li class="list-group-item bg-black text-white">
                                <div class="text-capitalize"><strong><?php echo e(__('gender')); ?>:</strong>
                                    <?php echo e(__($mascota->gender)); ?>

                                </div>
                            </li>
                            <li class="list-group-item bg-black text-white">
                                <div><strong><?php echo e(__('Birthday')); ?>:</strong> <?php echo e($mascota->fnac); ?></div>
                            </li>
                            <li class="list-group-item bg-black text-white">
                                <div><strong><?php echo e(__('Weight')); ?>:</strong> <?php echo e($mascota->sss); ?></div>
                            </li>
                            <li class="list-group-item bg-black text-white">
                                <div><strong><?php echo e(__('Size')); ?>:</strong>
                                    <?php switch ($mascota->size) {
                                        case 'smll':
                                            echo __('Small');
                                            break;
                                        case 'mdm':
                                            echo __('Medium');
                                            break;
                                        case 'lrg':
                                            echo __('Large');
                                            break;
                                    } ?>
                                </div>
                            </li>
                            <li class="list-group-item bg-black text-white">
                                <div><strong><?php echo e(__('Seal')); ?>:</strong> <?php echo e($mascota->plc); ?></div>
                            </li>
                            <li class="list-group-item bg-black text-white">
                                <div><strong><?php echo e(__('Locker')); ?>:</strong> <?php echo e($mascota->lck); ?></div>
                            </li>
                            <li class="list-group-item bg-black text-white">
                                <div><strong><?php echo e(__('Colour')); ?>:</strong> <?php echo e($mascota->plu); ?></div>
                            </li>
                            <li class="list-group-item bg-black text-white">
                                <div><strong><?php echo e(__('Father')); ?>:</strong>
                                    <?php if($pad): ?>
                                        <?php echo e($pad->REGGAL); ?>

                                    <?php endif; ?>
                                </div>
                            </li>
                            <li class="list-group-item bg-black text-white">
                                <div><strong><?php echo e(__('Mother')); ?>:</strong>
                                    <?php if($mad): ?>
                                        <?php echo e($mad->REGGAL); ?>

                                    <?php endif; ?>
                                </div>
                            </li>
                            <li class="list-group-item bg-black text-white">
                                <div><strong><?php echo e(__('Disability')); ?>:</strong>
                                    <?php switch ($mascota->des) {
                                        case '0':
                                            echo __('No');
                                            break;
                                        case '1':
                                            echo __('Visual');
                                            break;
                                        case '2':
                                            echo __('Physical');
                                            break;
                                        case '3':
                                            echo __('Other');
                                            break;
                                    } ?>
                                </div>
                            </li>
                            <?php if($mascota->gender == 'female'): ?>
                                <li class="list-group-item bg-black text-white">
                                    <div><strong><?php echo e(__('Incubation')); ?>:</strong> <?php echo e($mascota->icbc); ?></div>
                                </li>
                                <li class="list-group-item bg-black text-white">
                                    <div><strong><?php echo e(__('Eggs')); ?>:</strong> <?php echo e($mascota->hvs); ?></div>
                                </li>
                                <li class="list-group-item bg-black text-white">
                                    <div><strong><?php echo e(__('Born')); ?>:</strong> <?php echo e($mascota->ncr); ?></div>
                                </li>
                            <?php endif; ?>
                            <li class="list-group-item bg-black text-white">
                                <div><strong><?php echo e(__('Vaccines')); ?>:</strong></div>
                                <div class="table-responsive">
                                    <table class="table text-white">
                                        <thead>
                                            <tr>
                                                <th><?php echo e(__('Date')); ?></th>
                                                <th><?php echo e(__('Type')); ?></th>
                                                <th><?php echo e(__('Brand')); ?></th>
                                                <th><?php echo e(__('Dose')); ?></th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $mascota->vacunas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vacuna): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td>
                                                        <?php echo e($vacuna->vcnsf); ?>

                                                    </td>
                                                    <td>
                                                        <?php echo e($vacuna->vcnst); ?>

                                                    </td>
                                                    <td>
                                                        <?php echo e($vacuna->vcnsm); ?>

                                                    </td>
                                                    <td>
                                                        <?php echo e($vacuna->vcnsd); ?>

                                                    </td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </li>
                            <li class="list-group-item bg-black text-white">
                                <label class="form-label"><strong><?php echo e(__('Moves')); ?></strong></label>
                                <div class="row">
                                    <div class="col">
                                        <strong><?php echo e(__('Date')); ?>:</strong><br><?php echo e($mascota->mvf); ?>

                                    </div>
                                    <div class="col">
                                        <strong><?php echo e(__('Time')); ?>:</strong><br><?php echo e($mascota->mm); ?>:<?php echo e($mascota->ms); ?>

                                    </div>
                                    <div class="col">
                                        <strong><?php echo e(__('Type')); ?>:</strong><br><?php echo e($mascota->mvtp); ?>

                                    </div>
                                    <div class="col text-capitalize">
                                        <strong><?php echo e(__('Result')); ?>:</strong><br><?php echo e(__($mascota->mvr)); ?>

                                    </div>
                                </div>
                            </li>
                            <form action="<?php echo e(route('mascotas.update', $mascota->id)); ?>" method="POST">
                                <?php echo csrf_field(); ?>

                                <?php echo e(method_field('PUT')); ?>

                                <li class="list-group-item bg-black text-white">
                                    <div><strong><?php echo e(__('SENASA')); ?>:</strong></div>
                                    <input class="form-control" type="text" name="sena" value="<?php echo e($mascota->sena); ?>"
                                        required required pattern="[A-zÀ-ú1-9\s]+" maxlength="30"
                                        onkeydown="return /[A-zÀ-ú1-9\s]/i.test(event.key)">
                                </li>
                                <li class="list-group-item bg-black text-white">
                                    <div><strong><?php echo e(__('Supplement')); ?>:</strong></div>
                                    <input class="form-control" type="text" name="spmt" value="<?php echo e($mascota->spmt); ?>"
                                        required pattern="[A-zÀ-ú1-9\s]+" maxlength="20"
                                        onkeydown="return /[A-zÀ-ú1-9\s]/i.test(event.key)">
                                </li>
                                <li class="list-group-item bg-black text-white">
                                    <div class="form-label"><strong><?php echo e(__('Observations')); ?>:</strong><br>
                                        <textarea class="form-control" value="<?php echo e(old('obs')); ?>" name="obs" maxlength="200" required
                                            rows="4"><?php echo e($mascota->obs); ?></textarea>
                                    </div>
                                    <button type="submit" class="btn btn-dark"><?php echo e(__('Edit')); ?></button>

                                </li>
                            </form>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-6 h-100">
                    <div class="row g-3 text-center">
                        <!-- Button Modal -->
                        <div class="col-12">
                            <div for="nombre" class="form-label fw-bold text-white">
                                <?php echo e(__('Photo Profile')); ?>

                            </div>
                            <button type="button" class="btn border border-danger" data-bs-toggle="modal"
                                data-bs-target="#exampleModalToggle">
                                <img src="<?php if(!empty($mascota->fotos->where('nfoto', 1)->first())): ?> <?php echo e(asset($mascota->fotos->where('nfoto', 1)->first()->ruta)); ?>

                            <?php else: ?>
                            <?php echo e(asset('storage/img/pata.jpg')); ?> <?php endif; ?>"
                                    class="rounded img-fluid" style="height: 10em;">
                            </button>
                        </div>
                        <div for="nombre" class="form-label fw-bold text-white">
                            <?php echo e(__('Photo')); ?>s
                        </div>
                        <div class="col-6">
                            <button type="button" class="btn" data-bs-toggle="modal"
                                data-bs-target="#exampleModalToggle2">
                                <img src="<?php if(!empty($mascota->fotos->where('nfoto', 2)->first())): ?> <?php echo e(asset($mascota->fotos->where('nfoto', 2)->first()->ruta)); ?>

                        <?php else: ?>
                        <?php echo e(asset('storage/img/pata.jpg')); ?> <?php endif; ?>"
                                    class="rounded img-fluid" style="height: 10em;">
                            </button>
                        </div>
                        <div class="col-6">
                            <button type="button" class="btn" data-bs-toggle="modal"
                                data-bs-target="#exampleModalToggle3">
                                <img src="<?php if(!empty($mascota->fotos->where('nfoto', 3)->first())): ?> <?php echo e(asset($mascota->fotos->where('nfoto', 3)->first()->ruta)); ?>

                        <?php else: ?>
                        <?php echo e(asset('storage/img/pata.jpg')); ?> <?php endif; ?>"
                                    class="rounded img-fluid" style="height: 10em;">
                            </button>
                        </div>
                        <div class="col-6">
                            <button type="button" class="btn" data-bs-toggle="modal"
                                data-bs-target="#exampleModalToggle4">
                                <img src="<?php if(!empty($mascota->fotos->where('nfoto', 4)->first())): ?> <?php echo e(asset($mascota->fotos->where('nfoto', 4)->first()->ruta)); ?>

                        <?php else: ?>
                        <?php echo e(asset('storage/img/pata.jpg')); ?> <?php endif; ?>"
                                    class="rounded img-fluid" style="height: 10em;">
                            </button>
                        </div>
                        <div class="col-6">
                            <button type="button" class="btn" data-bs-toggle="modal"
                                data-bs-target="#exampleModalToggle5">
                                <img src="<?php if(!empty($mascota->fotos->where('nfoto', 5)->first())): ?> <?php echo e(asset($mascota->fotos->where('nfoto', 5)->first()->ruta)); ?>

                        <?php else: ?>
                        <?php echo e(asset('storage/img/pata.jpg')); ?> <?php endif; ?>"
                                    class="rounded img-fluid" style="height: 10em;">
                            </button>
                        </div>
                        <div class="col-6">
                            <button type="button" class="btn" data-bs-toggle="modal"
                                data-bs-target="#exampleModalToggle6">
                                <img src="<?php if(!empty($mascota->fotos->where('nfoto', 6)->first()->ruta)): ?> <?php echo e(asset($mascota->fotos->where('nfoto', 6)->first()->ruta)); ?>

                        <?php else: ?>
                        <?php echo e(asset('storage/img/pata.jpg')); ?> <?php endif; ?>"
                                    class="rounded img-fluid" style="height: 10em;">
                            </button>
                        </div>
                        <div class="col-6">
                            <button type="button" class="btn" data-bs-toggle="modal"
                                data-bs-target="#exampleModalToggle7">
                                <img src="<?php if(!empty($mascota->fotos->where('nfoto', 7)->first())): ?> <?php echo e(asset($mascota->fotos->where('nfoto', 7)->first()->ruta)); ?>

                        <?php else: ?>
                        <?php echo e(asset('storage/img/pata.jpg')); ?> <?php endif; ?>"
                                    class="rounded img-fluid" style="height: 10em;">
                            </button>
                        </div>
                        <div for="nombre" class="form-label fw-bold text-white">
                            <?php echo e(__('Videos')); ?>

                        </div>
                        <div class="col-6">
                            <button type="button" class="btn" data-bs-toggle="modal"
                                data-bs-target="#exampleModalToggle8">
                                <?php if(!empty($mascota->videos->where('nvideo', 1)->first())): ?>
                                    <video class="rounded img-fluid" style="height: 10em;">
                                        <source src="<?php echo e(asset($mascota->videos->where('nvideo', 1)->first()->ruta)); ?>"
                                            type="video/mp4">
                                    </video>
                                <?php else: ?>
                                    <img src="<?php echo e(asset('storage/img/pata.jpg')); ?>" class="rounded img-fluid"
                                        style="height: 10em;">
                                <?php endif; ?>
                            </button>
                        </div>
                        <div class="col-6">
                            <button type="button" class="btn" data-bs-toggle="modal"
                                data-bs-target="#exampleModalToggle9">
                                <?php if(!empty($mascota->videos->where('nvideo', 2)->first()->ruta)): ?>
                                    <video class="rounded img-fluid" style="height: 10em;">
                                        <source src="<?php echo e(asset($mascota->videos->where('nvideo', 2)->first()->ruta)); ?>"
                                            type="video/mp4">
                                    </video>
                                <?php else: ?>
                                    <img src="<?php echo e(asset('storage/img/pata.jpg')); ?>" class="rounded img-fluid"
                                        style="height: 10em;">
                                <?php endif; ?>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="card-footer border border-danger table-responsive">
            <label class="form-label fw-bold text-uppercase text-danger"><?php echo e(__('Last 10 participantions')); ?></label>
            <table class="table table-sm table-dark table-hover fs-5" id="datatable">
                <thead>
                    <tr>
                        <th><?php echo e(__('Deal')); ?></th>
                        <th><?php echo e(__('Rival')); ?></th>
                        <th><?php echo e(__('Coliseum')); ?></th>
                        <th><?php echo e(__('Time')); ?></th>
                        <th><?php echo e(__('Type')); ?></th>
                        <th><?php echo e(__('Result')); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $duelos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $duelo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e(str_replace('-', '', $duelo->lparticipante->evento->fechas[0]) .$duelo->lparticipante->evento->coliseum->country .$duelo->lparticipante->evento->coliseum->estate .'JUE' .$duelo->lparticipante->evento->judge->id); ?>

                            </td>
                            <td>
                                <?php if($duelo->pmascota_id == $mascota->id): ?>
                                    <?php echo e($duelo->smascota->nombre); ?>

                                <?php elseif($duelo->smascota_id == $mascota->id): ?>
                                    <?php echo e($duelo->pmascota->nombre); ?>

                                <?php endif; ?>
                            </td>
                            <td><?php echo e($duelo->lparticipante->evento->coliseum->nombre); ?></td>
                            <td><?php echo e($duelo->dm . ':' . $duelo->ds); ?></td>
                            <td>
                                <select class="form-control text-white" style="background:none;border:none;" disabled>
                                    <option <?php if($duelo->trslt == ''): ?> selected <?php endif; ?>> </option>
                                    <option <?php if($duelo->trslt == 'win'): ?> selected <?php endif; ?>>
                                        <?php echo e(__('Win')); ?></option>
                                    <option <?php if($duelo->trslt == 'win'): ?> selected <?php endif; ?>>
                                        <?php echo e(__('Win')); ?></option>
                                    <option <?php if($duelo->trslt == 'rooster'): ?> selected <?php endif; ?>>
                                        <?php echo e(__('Rooster')); ?></option>
                                    <option <?php if($duelo->trslt == 'srstr'): ?> selected <?php endif; ?>>
                                        Super <?php echo e(__('Rooster')); ?></option>
                                </select>
                            </td>
                            <td class="table-active text-center">
                                <?php if($duelo->result == 'draw'): ?>
                                    <div class="bg-warning"><?php echo e(__('Draw')); ?></div>
                                <?php elseif($duelo->result == null): ?>
                                    <div class="bg-warning"><?php echo e(__('Waiting')); ?></div>
                                <?php elseif($duelo->result == $mascota->id): ?>
                                    <div class="bg-success"><?php echo e(__('Win')); ?></div>
                                <?php elseif($duelo->result != $mascota->id): ?>
                                    <div class="bg-danger"><?php echo e(__('Lose')); ?></div>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>


    <!-- Modal 1-->
    <div class="modal fade" id="exampleModalToggle" aria-hidden="true" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="btn btn-danger btn-close" data-bs-dismiss="modal"
                        aria-label="Close"></button>
                </div>
                <div class="modal-body mx-auto">
                    <figure class="figure">
                        <img src="<?php if(!empty($mascota->fotos->where('nfoto', 1)->first())): ?> <?php echo e(asset($mascota->fotos->where('nfoto', 1)->first()->ruta)); ?>

                            <?php else: ?>
                            <?php echo e(asset('storage/img/pata.jpg')); ?> <?php endif; ?>"
                            class="figure-img" width="100%" height="250vh">
                    </figure>
                </div>
                <div class="modal-footer d-flex justify-content-between">
                    <button class="btn btn-primary" data-bs-target="#exampleModalToggle9" data-bs-toggle="modal">
                        <?php echo e(__('Prev')); ?></button>
                    <button class="btn btn-primary" data-bs-target="#exampleModalToggle2" data-bs-toggle="modal">
                        <?php echo e(__('Next')); ?></button>
                </div>
            </div>
        </div>
    </div>
    <!-- Modal 2 -->
    <div class="modal fade" id="exampleModalToggle2" aria-hidden="true" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <?php if(!empty($mascota->fotos->where('nfoto', 2)->first())): ?>
                        <form action="<?php echo e(route('mfotos.destroy', $mascota->fotos->where('nfoto', 2)->first())); ?>"
                            method="post">
                            <?php echo method_field('delete'); ?>

                            <?php echo csrf_field(); ?>

                            <button type="submit" class="btn btn-danger">Eliminar</button>
                        </form>
                    <?php else: ?>
                        
                        <form class="d-flex justify-content-between mt-3 w-75" method="POST"
                            action="<?php echo e(route('mfotos.store')); ?>" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>

                            <input id="nfoto" type="text" name="nfoto" value="2" hidden>
                            <input id="REGGAL" type="text" name="REGGAL" value="<?php echo e($mascota->REGGAL); ?>" hidden>
                            <input id="text" type="text" name="text" value="xd" hidden>
                            <input id="mascota_id" type="text" name="mascota_id" value="<?php echo e($mascota->id); ?>" hidden>
                            <input id="foto" type="file" class="form-control form-control-sm" name="foto"
                                value="<?php echo e(old('foto')); ?>" required autofocus accept="image/*">
                            <?php if($errors->has('foto')): ?>
                                <span class="text-danger fs-6">
                                    <?php echo e($errors->first('foto')); ?>

                                </span>
                            <?php endif; ?>
                            <button type="submit" class="btn btn-danger">Editar</button>
                        </form>
                    <?php endif; ?>
                    <button type="button" class="btn btn-danger btn-close" data-bs-dismiss="modal"
                        aria-label="Close"></button>
                </div>
                <div class="modal-body mx-auto">
                    <figure class="figure">
                        <img src="<?php if(!empty($mascota->fotos->where('nfoto', 2)->first())): ?> <?php echo e(asset($mascota->fotos->where('nfoto', 2)->first()->ruta)); ?>

                            <?php else: ?>
                            <?php echo e(asset('storage/img/pata.jpg')); ?> <?php endif; ?>"
                            class="figure-img" width="100%" height="250vh">
                    </figure>
                </div>
                <div class="modal-footer d-flex justify-content-between">
                    <button class="btn btn-primary" data-bs-target="#exampleModalToggle" data-bs-toggle="modal">
                        <?php echo e(__('Prev')); ?></button>
                    <button class="btn btn-primary" data-bs-target="#exampleModalToggle3" data-bs-toggle="modal">
                        <?php echo e(__('Next')); ?></button>
                </div>
            </div>
        </div>
    </div>
    <!-- Modal 3 -->
    <div class="modal fade" id="exampleModalToggle3" aria-hidden="true" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <?php if(!empty($mascota->fotos->where('nfoto', 3)->first())): ?>
                        <form action="<?php echo e(route('mfotos.destroy', $mascota->fotos->where('nfoto', 3)->first())); ?>"
                            method="post">
                            <?php echo method_field('delete'); ?>

                            <?php echo csrf_field(); ?>

                            <button type="submit" class="btn btn-danger">Eliminar</button>
                        </form>
                    <?php else: ?>
                        
                        <form class="d-flex justify-content-between mt-3 w-75" method="POST"
                            action="<?php echo e(route('mfotos.store')); ?>" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>

                            <input id="nfoto" type="text" name="nfoto" value="3" hidden>
                            <input id="REGGAL" type="text" name="REGGAL" value="<?php echo e($mascota->REGGAL); ?>" hidden>
                            <input id="text" type="text" name="text" value="xd" hidden>
                            <input id="mascota_id" type="text" name="mascota_id" value="<?php echo e($mascota->id); ?>" hidden>
                            <input id="foto" type="file" class="form-control form-control-sm" name="foto"
                                value="<?php echo e(old('foto')); ?>" required autofocus accept="image/*">
                            <?php if($errors->has('foto')): ?>
                                <span class="text-danger fs-6">
                                    <?php echo e($errors->first('foto')); ?>

                                </span>
                            <?php endif; ?>
                            <button type="submit" class="btn btn-danger">Editar</button>
                        </form>
                    <?php endif; ?>
                    <button type="button" class="btn btn-danger btn-close" data-bs-dismiss="modal"
                        aria-label="Close"></button>
                </div>
                <div class="modal-body mx-auto">
                    <figure class="figure">
                        <img src="<?php if(!empty($mascota->fotos->where('nfoto', 3)->first())): ?> <?php echo e(asset($mascota->fotos->where('nfoto', 3)->first()->ruta)); ?>

                            <?php else: ?>
                            <?php echo e(asset('storage/img/pata.jpg')); ?> <?php endif; ?>"
                            class="figure-img" width="100%" height="250vh">

                    </figure>
                </div>
                <div class="modal-footer d-flex justify-content-between">
                    <button class="btn btn-primary" data-bs-target="#exampleModalToggle2" data-bs-toggle="modal">
                        <?php echo e(__('Prev')); ?></button>
                    <button class="btn btn-primary" data-bs-target="#exampleModalToggle4" data-bs-toggle="modal">
                        <?php echo e(__('Next')); ?></button>
                </div>
            </div>
        </div>
    </div>
    
    <div class="modal fade" id="exampleModalToggle4" aria-hidden="true" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <?php if(!empty($mascota->fotos->where('nfoto', 4)->first())): ?>
                        <form action="<?php echo e(route('mfotos.destroy', $mascota->fotos->where('nfoto', 4)->first())); ?>"
                            method="post">
                            <?php echo method_field('delete'); ?>

                            <?php echo csrf_field(); ?>

                            <button type="submit" class="btn btn-danger">Eliminar</button>
                        </form>
                    <?php else: ?>
                        
                        <form class="d-flex justify-content-between mt-3 w-75" method="POST"
                            action="<?php echo e(route('mfotos.store')); ?>" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>

                            <input id="nfoto" type="text" name="nfoto" value="4" hidden>
                            <input id="REGGAL" type="text" name="REGGAL" value="<?php echo e($mascota->REGGAL); ?>" hidden>
                            <input id="text" type="text" name="text" value="xd" hidden>
                            <input id="mascota_id" type="text" name="mascota_id" value="<?php echo e($mascota->id); ?>" hidden>
                            <input id="foto" type="file" class="form-control form-control-sm" name="foto"
                                value="<?php echo e(old('foto')); ?>" required autofocus accept="image/*">
                            <?php if($errors->has('foto')): ?>
                                <span class="text-danger fs-6">
                                    <?php echo e($errors->first('foto')); ?>

                                </span>
                            <?php endif; ?>
                            <button type="submit" class="btn btn-danger">Editar</button>
                        </form>
                    <?php endif; ?>
                    <button type="button" class="btn btn-danger btn-close" data-bs-dismiss="modal"
                        aria-label="Close"></button>
                </div>
                <div class="modal-body mx-auto">
                    <figure class="figure">
                        <img src="<?php if(!empty($mascota->fotos->where('nfoto', 4)->first())): ?> <?php echo e(asset($mascota->fotos->where('nfoto', 4)->first()->ruta)); ?>

                            <?php else: ?>
                            <?php echo e(asset('storage/img/pata.jpg')); ?> <?php endif; ?>"
                            class="figure-img" width="100%" height="250vh">

                    </figure>
                </div>
                <div class="modal-footer d-flex justify-content-between">
                    <button class="btn btn-primary" data-bs-target="#exampleModalToggle3" data-bs-toggle="modal">
                        <?php echo e(__('Prev')); ?></button>
                    <button class="btn btn-primary" data-bs-target="#exampleModalToggle5" data-bs-toggle="modal">
                        <?php echo e(__('Next')); ?></button>
                </div>
            </div>
        </div>
    </div>
    
    <div class="modal fade" id="exampleModalToggle5" aria-hidden="true" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <?php if(!empty($mascota->fotos->where('nfoto', 5)->first())): ?>
                        <form action="<?php echo e(route('mfotos.destroy', $mascota->fotos->where('nfoto', 5)->first())); ?>"
                            method="post">
                            <?php echo method_field('delete'); ?>

                            <?php echo csrf_field(); ?>

                            <button type="submit" class="btn btn-danger">Eliminar</button>
                        </form>
                    <?php else: ?>
                        
                        <form class="d-flex justify-content-between mt-3 w-75" method="POST"
                            action="<?php echo e(route('mfotos.store')); ?>" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>

                            <input id="nfoto" type="text" name="nfoto" value="5" hidden>
                            <input id="REGGAL" type="text" name="REGGAL" value="<?php echo e($mascota->REGGAL); ?>" hidden>
                            <input id="text" type="text" name="text" value="xd" hidden>
                            <input id="mascota_id" type="text" name="mascota_id" value="<?php echo e($mascota->id); ?>" hidden>
                            <input id="foto" type="file" class="form-control form-control-sm" name="foto"
                                value="<?php echo e(old('foto')); ?>" required autofocus accept="image/*">
                            <?php if($errors->has('foto')): ?>
                                <span class="text-danger fs-6">
                                    <?php echo e($errors->first('foto')); ?>

                                </span>
                            <?php endif; ?>
                            <button type="submit" class="btn btn-danger">Editar</button>
                        </form>
                    <?php endif; ?>
                    <button type="button" class="btn btn-danger btn-close" data-bs-dismiss="modal"
                        aria-label="Close"></button>
                </div>
                <div class="modal-body mx-auto">
                    <figure class="figure">
                        <img src="<?php if(!empty($mascota->fotos->where('nfoto', 5)->first())): ?> <?php echo e(asset($mascota->fotos->where('nfoto', 5)->first()->ruta)); ?>

                            <?php else: ?>
                            <?php echo e(asset('storage/img/pata.jpg')); ?> <?php endif; ?>"
                            class="figure-img" width="100%" height="250vh">

                    </figure>
                </div>
                <div class="modal-footer d-flex justify-content-between">
                    <button class="btn btn-primary" data-bs-target="#exampleModalToggle4" data-bs-toggle="modal">
                        <?php echo e(__('Prev')); ?></button>
                    <button class="btn btn-primary" data-bs-target="#exampleModalToggle6" data-bs-toggle="modal">
                        <?php echo e(__('Next')); ?></button>
                </div>
            </div>
        </div>
    </div>
    
    <div class="modal fade" id="exampleModalToggle6" aria-hidden="true" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <?php if(!empty($mascota->fotos->where('nfoto', 6)->first())): ?>
                        <form action="<?php echo e(route('mfotos.destroy', $mascota->fotos->where('nfoto', 6)->first())); ?>"
                            method="post">
                            <?php echo method_field('delete'); ?>

                            <?php echo csrf_field(); ?>

                            <button type="submit" class="btn btn-danger">Eliminar</button>
                        </form>
                    <?php else: ?>
                        
                        <form class="d-flex justify-content-between mt-3 w-75" method="POST"
                            action="<?php echo e(route('mfotos.store')); ?>" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>

                            <input id="nfoto" type="text" name="nfoto" value="6" hidden>
                            <input id="REGGAL" type="text" name="REGGAL" value="<?php echo e($mascota->REGGAL); ?>" hidden>
                            <input id="text" type="text" name="text" value="xd" hidden>
                            <input id="mascota_id" type="text" name="mascota_id" value="<?php echo e($mascota->id); ?>" hidden>
                            <input id="foto" type="file" class="form-control form-control-sm" name="foto"
                                value="<?php echo e(old('foto')); ?>" required autofocus accept="image/*">
                            <?php if($errors->has('foto')): ?>
                                <span class="text-danger fs-6">
                                    <?php echo e($errors->first('foto')); ?>

                                </span>
                            <?php endif; ?>
                            <button type="submit" class="btn btn-danger">Editar</button>
                        </form>
                    <?php endif; ?>
                    <button type="button" class="btn btn-danger btn-close" data-bs-dismiss="modal"
                        aria-label="Close"></button>
                </div>
                <div class="modal-body mx-auto">
                    <figure class="figure">
                        <img src="<?php if(!empty($mascota->fotos->where('nfoto', 6)->first())): ?> <?php echo e(asset($mascota->fotos->where('nfoto', 6)->first()->ruta)); ?>

                            <?php else: ?>
                            <?php echo e(asset('storage/img/pata.jpg')); ?> <?php endif; ?>"
                            class="figure-img" width="100%" height="250vh">

                    </figure>
                </div>
                <div class="modal-footer d-flex justify-content-between">
                    <button class="btn btn-primary" data-bs-target="#exampleModalToggle5" data-bs-toggle="modal">
                        <?php echo e(__('Prev')); ?></button>
                    <button class="btn btn-primary" data-bs-target="#exampleModalToggle7" data-bs-toggle="modal">
                        <?php echo e(__('Next')); ?></button>
                </div>
            </div>
        </div>
    </div>
    
    <div class="modal fade" id="exampleModalToggle7" aria-hidden="true" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <?php if(!empty($mascota->fotos->where('nfoto', 7)->first())): ?>
                        <form action="<?php echo e(route('mfotos.destroy', $mascota->fotos->where('nfoto', 7)->first())); ?>"
                            method="post">
                            <?php echo method_field('delete'); ?>

                            <?php echo csrf_field(); ?>

                            <button type="submit" class="btn btn-danger">Eliminar</button>
                        </form>
                    <?php else: ?>
                        
                        <form class="d-flex justify-content-between mt-3 w-75" method="POST"
                            action="<?php echo e(route('mfotos.store')); ?>" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>

                            <input id="nfoto" type="text" name="nfoto" value="7" hidden>
                            <input id="REGGAL" type="text" name="REGGAL" value="<?php echo e($mascota->REGGAL); ?>" hidden>
                            <input id="text" type="text" name="text" value="xd" hidden>
                            <input id="mascota_id" type="text" name="mascota_id" value="<?php echo e($mascota->id); ?>" hidden>
                            <input id="foto" type="file" class="form-control form-control-sm" name="foto"
                                value="<?php echo e(old('foto')); ?>" required autofocus accept="image/*">
                            <?php if($errors->has('foto')): ?>
                                <span class="text-danger fs-6">
                                    <?php echo e($errors->first('foto')); ?>

                                </span>
                            <?php endif; ?>
                            <button type="submit" class="btn btn-danger">Editar</button>
                        </form>
                    <?php endif; ?>
                    <button type="button" class="btn btn-danger btn-close" data-bs-dismiss="modal"
                        aria-label="Close"></button>
                </div>
                <div class="modal-body mx-auto">
                    <figure class="figure">
                        <img src="<?php if(!empty($mascota->fotos->where('nfoto', 7)->first())): ?> <?php echo e(asset($mascota->fotos->where('nfoto', 7)->first()->ruta)); ?>

                            <?php else: ?>
                            <?php echo e(asset('storage/img/pata.jpg')); ?> <?php endif; ?>"
                            class="figure-img" width="100%" height="250vh">

                    </figure>
                </div>
                <div class="modal-footer d-flex justify-content-between">
                    <button class="btn btn-primary" data-bs-target="#exampleModalToggle6" data-bs-toggle="modal">
                        <?php echo e(__('Prev')); ?></button>
                    <button class="btn btn-primary" data-bs-target="#exampleModalToggle8" data-bs-toggle="modal">
                        <?php echo e(__('Next')); ?></button>
                </div>
            </div>
        </div>
    </div>
    
    <div class="modal fade" id="exampleModalToggle8" aria-hidden="true" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <?php if(!empty($mascota->videos->where('nvideo', 1)->first())): ?>
                        <form action="<?php echo e(route('mvideos.destroy', $mascota->videos->where('nvideo', 1)->first())); ?>"
                            method="post">
                            <?php echo method_field('delete'); ?>

                            <?php echo csrf_field(); ?>

                            <button type="submit" class="btn btn-danger">Eliminar</button>
                        </form>
                    <?php else: ?>
                        
                        <form class="d-flex justify-content-between mt-3 w-75" method="POST"
                            action="<?php echo e(route('mvideos.store')); ?>" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>

                            <input id="nvideo" type="text" name="nvideo" value="1" hidden>
                            <input id="REGGAL" type="text" name="REGGAL" value="<?php echo e($mascota->REGGAL); ?>" hidden>
                            <input id="text" type="text" name="text" value="xd" hidden>
                            <input id="mascota_id" type="text" name="mascota_id" value="<?php echo e($mascota->id); ?>" hidden>
                            <input id="video" type="file" class="form-control form-control-sm" name="video"
                                value="<?php echo e(old('video')); ?>" required autofocus accept=".mp4">
                            <?php if($errors->has('video')): ?>
                                <span class="text-danger fs-6">
                                    <?php echo e($errors->first('video')); ?>

                                </span>
                            <?php endif; ?>
                            <button type="submit" class="btn btn-danger">Editar</button>
                        </form>
                    <?php endif; ?>
                    <button type="button" class="btn btn-danger btn-close" data-bs-dismiss="modal"
                        aria-label="Close"></button>
                </div>
                <div class="modal-body mx-auto">
                    <figure class="figure">
                        <?php if(!empty($mascota->videos->where('nvideo', 1)->first())): ?>
                            <video width="100%" height="250vh" autoplay controls>
                                <source src="<?php echo e(asset($mascota->videos->where('nvideo', 1)->first()->ruta)); ?>"
                                    type="video/mp4">
                                Your browser does not support the video tag.
                            </video>
                        <?php else: ?>
                            <img src="<?php echo e(asset('storage/img/pata.jpg')); ?>" class="figure-img" width="100%"
                                height="250vh">
                        <?php endif; ?>

                    </figure>
                </div>
                <div class="modal-footer d-flex justify-content-between">
                    <button class="btn btn-primary" data-bs-target="#exampleModalToggle7" data-bs-toggle="modal">
                        <?php echo e(__('Prev')); ?></button>
                    <button class="btn btn-primary" data-bs-target="#exampleModalToggle9" data-bs-toggle="modal">
                        <?php echo e(__('Next')); ?></button>
                </div>
            </div>
        </div>
    </div>
    
    <div class="modal fade" id="exampleModalToggle9" aria-hidden="true" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <?php if(!empty($mascota->videos->where('nvideo', 2)->first())): ?>
                        <form action="<?php echo e(route('mvideos.destroy', $mascota->videos->where('nvideo', 2)->first())); ?>"
                            method="post">
                            <?php echo method_field('delete'); ?>

                            <?php echo csrf_field(); ?>

                            <button type="submit" class="btn btn-danger">Eliminar</button>
                        </form>
                    <?php else: ?>
                        
                        <form class="d-flex justify-content-between mt-3 w-75" method="POST"
                            action="<?php echo e(route('mvideos.store')); ?>" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>

                            <input id="nvideo" type="text" name="nvideo" value="2" hidden>
                            <input id="REGGAL" type="text" name="REGGAL" value="<?php echo e($mascota->REGGAL); ?>" hidden>
                            <input id="text" type="text" name="text" value="xd" hidden>
                            <input id="mascota_id" type="text" name="mascota_id" value="<?php echo e($mascota->id); ?>" hidden>
                            <input id="video" type="file" class="form-control form-control-sm" name="video"
                                value="<?php echo e(old('video')); ?>" required autofocus accept=".mp4">
                            <?php if($errors->has('video')): ?>
                                <span class="text-danger fs-6">
                                    <?php echo e($errors->first('video')); ?>

                                </span>
                            <?php endif; ?>
                            <button type="submit" class="btn btn-danger">Editar</button>
                        </form>
                    <?php endif; ?>
                    <button type="button" class="btn btn-danger btn-close" data-bs-dismiss="modal"
                        aria-label="Close"></button>
                </div>
                <div class="modal-body mx-auto">
                    <figure class="figure">
                        <?php if(!empty($mascota->videos->where('nvideo', 2)->first())): ?>
                            <video width="100%" height="250vh" autoplay controls>
                                <source src="<?php echo e(asset($mascota->videos->where('nvideo', 2)->first()->ruta)); ?>"
                                    type="video/mp4">
                                Your browser does not support the video tag.
                            </video>
                        <?php else: ?>
                            <img src="<?php echo e(asset('storage/img/pata.jpg')); ?>" class="figure-img" width="100%"
                                height="250vh">
                        <?php endif; ?>

                    </figure>
                </div>
                <div class="modal-footer d-flex justify-content-between">
                    <button class="btn btn-primary" data-bs-target="#exampleModalToggle8" data-bs-toggle="modal">
                        <?php echo e(__('Prev')); ?></button>
                    <button class="btn btn-primary" data-bs-target="#exampleModalToggle" data-bs-toggle="modal">
                        <?php echo e(__('Next')); ?></button>
                </div>
            </div>
        </div>
    </div>

    
    <link rel="stylesheet" href="<?php echo e(asset('css/datatable/dataTables.bootstrap5.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/datatable/buttons.dataTables.min.css')); ?>">
    
    <script src="<?php echo e(asset('js/datatable/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/datatable/dataTables.bootstrap5.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/datatable/dataTables.buttons.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/ajax/jszip.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/ajax/pdfmake.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/ajax/vfs_fonts.js')); ?>"></script>
    <script src="<?php echo e(asset('js/datatable/buttons.html5.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/datatable/buttons.print.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/datatable/buttons.print.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/datatable/sorting/date-eu.js')); ?>"></script>
    
    <script type="text/javascript">
        $(document).ready(function() {
            function getLanguage() {
                var lang = $('html').attr('lang');
                if (lang == 'es') {
                    lng = "es-ES";
                } else if (lang == 'en') {
                    lng = "en-GB";
                }
                var result = null;
                var path = 'https://cdn.datatables.net/plug-ins/1.11.5/i18n/';
                result = path + lng + ".json";
                return result;
            }
            // Build Datatable
            $('#datatable').DataTable({
                bInfo: false,
                lengthChange: false,
                pageLength: 10,
                lengthMenu: [
                    [10],
                    [10]
                ],
                language: {
                    "url": getLanguage()
                }
            });
        });
        /* ERROR */
        setTimeout(function() {
            $('.alert').fadeOut(3000);
        }, );
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>