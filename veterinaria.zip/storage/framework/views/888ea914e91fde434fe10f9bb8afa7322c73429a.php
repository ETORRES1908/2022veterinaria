<?php $__env->startSection('title'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1><?php echo e(__('EVENT')); ?></h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php echo e($evento); ?>

    <form method="POST" action="<?php echo e(route('MEventos.update', ['id' => $evento->id])); ?>">
        <?php echo e(csrf_field()); ?>

        <?php echo e(method_field('PUT')); ?>

        <label><?php echo e(__('Status')); ?></label>
        <select class="form-control text-danger" name="status" style="width: 40%;margin:auto">
            <option value="0" <?php if($evento->status == '0'): ?> selected <?php endif; ?>>
                <?php echo e(__('Inactived')); ?>

            </option>
            <option value="1" <?php if($evento->status == '1'): ?> selected <?php endif; ?>>
                <?php echo e(__('Actived')); ?>

            </option>
            <option value="2" <?php if($evento->status == '2'): ?> selected <?php endif; ?>>
                <?php echo e(__('Suspended')); ?>

            </option>
        </select><br>
        <button type="submit" class="btn btn-primary"><?php echo e(__('Change status')); ?></button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>