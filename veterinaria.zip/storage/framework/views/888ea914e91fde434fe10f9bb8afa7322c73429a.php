<?php $__env->startSection('title'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1><?php echo e(__('EVENT')); ?></h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row bg-black text-danger" style="padding:5vh 0 10vh 0;font-size: 1.3em">
        <div class="col-md-5 text-center center-block">
            <div class="row">
                <div class="col-xs-6">
                    <img width="150" src="<?php echo e(asset($evento->organizador->foto)); ?>" class="mb">
                    <div><?php echo e(__('Organizer')); ?></div>
                    <div><?php echo e($evento->organizador->nombre); ?> <?php echo e($evento->organizador->apellido); ?></div>
                </div>
                <div class="col-xs-6">
                    <img width="150" src="<?php echo e(asset($evento->mcontrol->foto)); ?>" class="mb">
                    <div><?php echo e(__('Control desk')); ?></div>
                    <div><?php echo e($evento->mcontrol->nombre); ?> <?php echo e($evento->mcontrol->apellido); ?></div>

                </div>
                <div class="col-xs-6">
                    <img width="150" src="<?php echo e(asset($evento->judge->foto)); ?>" class="mb">
                    <div><?php echo e(__('Judge')); ?></div>
                    <div><?php echo e($evento->judge->nombre); ?> <?php echo e($evento->judge->apellido); ?></div>

                </div>
                <div class="col-xs-6 mb">
                    <img width="150" src="<?php echo e(asset($evento->assistent->foto)); ?>" class="mb">
                    <div><?php echo e(__('Assistant')); ?></div>
                    <div><?php echo e($evento->assistent->nombre); ?> <?php echo e($evento->assistent->apellido); ?></div>
                </div>
                <div class="col-xs-12"><br>
                    <form method="POST" action="<?php echo e(route('meventos.update', ['id' => $evento->id])); ?>">
                        <?php echo e(csrf_field()); ?>

                        <?php echo e(method_field('PUT')); ?>

                        <div class="mb">
                            <div class="col-xs-6"><?php echo e(__('Status')); ?>:</div>
                            <select class="col-xs-6 form-control" name="status" style="width: 40%;margin:auto">
                                <option value="0" <?php if($evento->status == '0'): ?> selected <?php endif; ?>>
                                    <?php echo e(__('Inactived')); ?>

                                </option>
                                <option value="1" <?php if($evento->status == '1'): ?> selected <?php endif; ?>>
                                    <?php echo e(__('Actived')); ?>

                                </option>
                            </select><br>
                        </div><br>
                        <button type="submit" class="btn btn-primary"><?php echo e(__('Change status')); ?></button>
                    </form>
                </div>
            </div>
        </div>
        <div class="col-md-7 center-block">
            <div class="row">
                <div class="col-xs-12 mb">
                    <label><?php echo e(__('Dates')); ?></label>
                    <div class="row">
                        <?php $__currentLoopData = $evento->fechas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fecha): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-xs-4 mb">
                                <label type="text" class="form-control text-danger">
                                    <?php echo e($fecha); ?>

                                </label>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                <div class="col-xs-4 mb">
                    <label><?php echo e(__('Coliseum')); ?></label>
                    <input type="text" class="form-control" value="<?php echo e($evento->coliseum->nombre); ?>" readonly>
                </div>
                <div class="col-xs-4 mb"><label><?php echo e(__('Type Event')); ?></label>
                    <select class="form-control text-danger fw-bold" disabled style="-webkit-appearance: none;">
                        <option value="cmp" <?php if($evento->tevent == 'cmp'): ?> selected <?php endif; ?>>
                            <?php echo e(__('Championship')); ?>

                        </option>
                        <option value="cct" <?php if($evento->tevent == 'cmp'): ?> selected <?php endif; ?>>
                            <?php echo e(__('Concentration')); ?>

                        </option>
                        <option value="chk" <?php if($evento->tevent == 'chk'): ?> selected <?php endif; ?>>
                            <?php echo e(__('Chuscas')); ?>

                        </option>
                        <option value="drb" <?php if($evento->tevent == 'drb'): ?> selected <?php endif; ?>>
                            <?php echo e(__('Derby')); ?>

                        </option>
                        <option value="prt" <?php if($evento->tevent == 'prt'): ?> selected <?php endif; ?>>
                            <?php echo e(__('Party')); ?>

                        </option>
                        <option value="thr" <?php if($evento->tevent == 'thr'): ?> selected <?php endif; ?>>
                            <?php echo e(__('Other')); ?>

                        </option>
                    </select>
                </div>
                <div class="col-xs-4 mb">
                    <label><?php echo e(__('Regulation')); ?></label>
                    <select class="form-control text-danger fw-bold" disabled style="-webkit-appearance: none;">
                        <option eventovalue="cls" <?php if($evento->trl == 'cls'): ?> selected <?php endif; ?>>
                            <?php echo e(__('Coliseum')); ?></option>
                        <option eventovalue="dpt" <?php if($evento->trl == 'dpt'): ?> selected <?php endif; ?>>
                            <?php echo e(__('Departmental')); ?></option>
                        <option eventovalue="nac" <?php if($evento->trl == 'nac'): ?> selected <?php endif; ?>>
                            <?php echo e(__('National')); ?> </option>
                        <option value="inc" <?php if($evento->trl == 'inc'): ?> selected <?php endif; ?>>
                            <?php echo e(__('International')); ?>

                        </option>
                    </select>
                </div>
                <div class="col-xs-12 mb">
                    <label class="form-label"><?php echo e(__('Spurs')); ?></label>
                    <div class="row">
                        <?php $__currentLoopData = $evento->spl; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $spl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($spl == 'lbr'): ?>
                                <div class="col-xs-4 mb">
                                    <label class="form-control text-danger">Libre</label>
                                </div>
                            <?php elseif($spl == 'fbr'): ?>
                                <div class="col-xs-4 mb">
                                    <label class="form-control text-danger">Fibra</label>
                                </div>
                            <?php elseif($spl == 'plt'): ?>
                                <div class="col-xs-4 mb">
                                    <label class="form-control text-danger">Plastica</label>
                                </div>
                            <?php elseif($spl == 'cry'): ?>
                                <div class="col-xs-4 mb">
                                    <label class="form-control text-danger">Carey</label>
                                </div>
                            <?php elseif($spl == 'spn'): ?>
                                <div class="col-xs-4 mb">
                                    <label class="form-control text-danger">Espina</label>
                                </div>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                <div class="col-xs-3 mb">
                    <label><?php echo e(__('Size')); ?></label>
                    <input type="text" class="form-control" value="<?php echo e($evento->sz); ?>" readonly>
                </div>
                <div class="col-xs-3 mb">
                    <label><?php echo e(__('Time')); ?></label>
                    <input type="text" class="form-control" value="<?php echo e($evento->sz); ?>" readonly>
                </div>
                <div class="col-xs-6 mb">
                    <label for="title" class="form-label"><?php echo e(__('Weight')); ?></label>
                    <div class="input-group">
                        <span class="input-group-addon">
                            Min</span>
                        <div class="form-control">
                            <?php echo e($evento->miw); ?></div>
                        <span class="input-group-addon">Max</span>
                        <div class="form-control">
                            <?php echo e($evento->maw); ?></div>
                    </div>
                </div>
                <div class="col-xs-5 mb">
                    <label><?php echo e(__('Country') . ', ' . __('State')); ?></label>
                    <div class="form-control">
                        <?php switch ($evento->ctr) {
                            case 'PER':
                                echo 'Perú';
                                break;
                            case 'ARG':
                                echo 'Argentina';
                                break;
                            case 'ECU':
                                echo 'Ecuador';
                                break;
                            case 'CHL':
                                echo 'Chile';
                                break;
                        } ?>,
                        <select disabled class="text-white"
                            style="-webkit-appearance: none;background:none;border:none;">
                            <option <?php if($evento->stt == 'PE-AMA'): ?> selected <?php endif; ?>>Amazonas</option>
                            <option <?php if($evento->stt == 'PE-ANC'): ?> selected <?php endif; ?>>Ancash</option>
                            <option <?php if($evento->stt == 'PE-APU'): ?> selected <?php endif; ?>>Apurímac</option>
                            <option <?php if($evento->stt == 'PE-ARE'): ?> selected <?php endif; ?>>Arequipa</option>
                            <option <?php if($evento->stt == 'PE-AYA'): ?> selected <?php endif; ?>>Ayacucho</option>
                            <option <?php if($evento->stt == 'PE-CAJ'): ?> selected <?php endif; ?>>Cajamarca</option>
                            <option <?php if($evento->stt == 'PE-CUS'): ?> selected <?php endif; ?>>Cuzco</option>
                            <option <?php if($evento->stt == 'PE-HUV'): ?> selected <?php endif; ?>>Huancavelica</option>
                            <option <?php if($evento->stt == 'PE-HUC'): ?> selected <?php endif; ?>>Huánuco</option>
                            <option <?php if($evento->stt == 'PE-ICA'): ?> selected <?php endif; ?>>ICA</option>
                            <option <?php if($evento->stt == 'PE-JUN'): ?> selected <?php endif; ?>>Junín</option>
                            <option <?php if($evento->stt == 'PE-LAL'): ?> selected <?php endif; ?>>La Libertad</option>
                            <option <?php if($evento->stt == 'PE-LAM'): ?> selected <?php endif; ?>>Lambayeque</option>
                            <option <?php if($evento->stt == 'PE-LIM'): ?> selected <?php endif; ?>>Lima</option>
                            <option <?php if($evento->stt == 'PE-LOR'): ?> selected <?php endif; ?>>Loreto</option>
                            <option <?php if($evento->stt == 'PE-MDD'): ?> selected <?php endif; ?>>Madre de Dios</option>
                            <option <?php if($evento->stt == 'PE-MOQ'): ?> selected <?php endif; ?>>Moquegua</option>
                            <option <?php if($evento->stt == 'PE-PAS'): ?> selected <?php endif; ?>>Pasco</option>
                            <option <?php if($evento->stt == 'PE-PIU'): ?> selected <?php endif; ?>>Piura</option>
                            <option <?php if($evento->stt == 'PE-PUN'): ?> selected <?php endif; ?>>Puno</option>
                            <option <?php if($evento->stt == 'PE-SAM'): ?> selected <?php endif; ?>>San Martín</option>
                            <option <?php if($evento->stt == 'PE-TAC'): ?> selected <?php endif; ?>>Tacna</option>
                            <option <?php if($evento->stt == 'PE-TUM'): ?> selected <?php endif; ?>>Tumbes</option>
                            <option <?php if($evento->stt == 'PE-UCA'): ?> selected <?php endif; ?>>Ucayali</option>
                            
                            <option <?php if($evento->stt == 'CL-AI'): ?> selected <?php endif; ?>>Aysén</option>
                            <option <?php if($evento->stt == 'CL-AN'): ?> selected <?php endif; ?>>Antofagasta</option>
                            <option <?php if($evento->stt == 'CL-AP'): ?> selected <?php endif; ?>>Arica y Parinacota
                            </option>
                            <option <?php if($evento->stt == 'CL-AR'): ?> selected <?php endif; ?>>Araucanía</option>
                            <option <?php if($evento->stt == 'CL-AT'): ?> selected <?php endif; ?>>Atacama</option>
                            <option <?php if($evento->stt == 'CL-BI'): ?> selected <?php endif; ?>>Biobío</option>
                            <option <?php if($evento->stt == 'CL-CO'): ?> selected <?php endif; ?>>Coquimbo</option>
                            <option <?php if($evento->stt == 'CL-LI'): ?> selected <?php endif; ?>>O'Higgins</option>
                            <option <?php if($evento->stt == 'CL-LL'): ?> selected <?php endif; ?>>Los Lagos</option>
                            <option <?php if($evento->stt == 'CL-LR'): ?> selected <?php endif; ?>>Los Ríos</option>
                            <option <?php if($evento->stt == 'CL-MA'): ?> selected <?php endif; ?>>Magallanes y Antártica
                            </option>
                            <option <?php if($evento->stt == 'CL-ML'): ?> selected <?php endif; ?>>Maule</option>
                            <option <?php if($evento->stt == 'CL-NB'): ?> selected <?php endif; ?>>Ñuble</option>
                            <option <?php if($evento->stt == 'CL-RM'): ?> selected <?php endif; ?>>Santiago</option>
                            <option <?php if($evento->stt == 'CL-TA'): ?> selected <?php endif; ?>>Tarapacá</option>
                            <option <?php if($evento->stt == 'CL-VS'): ?> selected <?php endif; ?>>Valparaíso</option>
                        </select>
                    </div>
                </div>
                <div class="col-xs-7 mb">
                    <label><?php echo e(__('Direction')); ?></label>
                    <div class="form-control">
                        <?php echo e($evento->drc); ?>

                    </div>
                </div>
                <div class="col-xs-4 mb">
                    <label><?php echo e(__('1st WEIGH')); ?></label>
                    <input class="form-control" type="time" step='1' value="<?php echo e($evento->ftw); ?>" readonly>
                </div>
                <div class="col-xs-4 mb">
                    <label><?php echo e(__('2nd WEIGH')); ?></label>
                    <input class="form-control" type="time" step='1' value="<?php echo e($evento->stw); ?>" readonly>
                </div>
                <div class="col-xs-4 mb">
                    <label><?php echo e(__('Start')); ?></label>
                    <input class="form-control" type="time" step='1' value="<?php echo e($evento->hstart); ?>" readonly>
                </div>
                <div class="col-xs-6 mb">
                    <label><?php echo e(__('Awards')); ?></label>
                    <input class="form-control" value="<?php echo e($evento->awards); ?>" readonly>
                </div>
                <div class="col-xs-6 mb">
                    <label><?php echo e(__('Awards')); ?></label>
                    <input class="form-control" value="<?php echo e($evento->trophys); ?>" readonly>
                </div>
                <div class="col-xs-6 mb">
                    <label><?php echo e(__('Rooster') . ' ' . $evento->trooster . __('seconds')); ?></label>
                    <input class="form-control" value="<?php echo e($evento->rooster); ?>" readonly>
                </div>
                <div class="col-xs-6 mb">
                    <label><?php echo e(__('Rooster') . ' 10' . __('seconds')); ?></label>
                    <input class="form-control" value="<?php echo e($evento->rten); ?>" readonly>
                </div>
                <div class="col-xs-3 mb">
                    <label>1 <?php echo e(__('FRENTE')); ?></label>
                    <input class="form-control" value="<?php echo e($evento->fft); ?>" readonly>
                </div>
                <div class="col-xs-3 mb">
                    <label>2 <?php echo e(__('FRENTE')); ?></label>
                    <input class="form-control" value="<?php echo e($evento->sft); ?>" readonly>
                </div>
                <div class="col-xs-3 mb">
                    <label>3 <?php echo e(__('FRENTE')); ?></label>
                    <input class="form-control" value="<?php echo e($evento->tft); ?>" readonly>
                </div>
                <div class="col-xs-3 mb">
                    <label><?php echo e(__('Fight quality')); ?></label>
                    <input class="form-control" value="<?php echo e($evento->fcd); ?>" readonly>
                </div>
            </div>
        </div>
    </div>

    
    <style>
        .form-control {
            color: rgb(210, 0, 0);
        }

        .mb {
            margin-bottom: 1vh;
        }

    </style>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>