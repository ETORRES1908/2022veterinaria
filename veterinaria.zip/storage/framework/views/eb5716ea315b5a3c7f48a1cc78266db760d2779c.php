<?php $__env->startSection('title'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Mantenimiento de Coliseos</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div style="margin-bottom:1vh">
            <a class="btn btn-primary" href="<?php echo e(route('mcoliseos.create')); ?>"><?php echo e(__('Create')); ?></a>
        </div>
        <div class="table-responsive">
            <table id="datatable" class="table table-hover nowrap" style="width:100%">
                <thead>
                    <tr>
                        <th><?php echo e(__('Name')); ?></th>
                        <th><?php echo e(__('Country')); ?></th>
                        <th><?php echo e(__('State')); ?></th>
                        <th><?php echo e(__('District')); ?></th>
                        <th><?php echo e(__('Reference')); ?></th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $coliseos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $coliseo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($coliseo->nombre); ?></td>
                            <td><?php echo e($coliseo->country); ?></td>
                            <td><?php echo e($coliseo->state); ?></td>
                            <td><?php echo e($coliseo->district); ?></td>
                            <td><?php echo e($coliseo->reference); ?></td>
                            <td>
                                <form method="POST" action="<?php echo e(route('mcoliseos.destroy', $coliseo->id)); ?>">
                                    <?php echo method_field('delete'); ?>

                                    <?php echo csrf_field(); ?>

                                    <button type="submit" class="col btn btn-danger"><?php echo e(__('Delete')); ?></button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                <tfoot>
                    <tr>
                        <th><?php echo e(__('Name')); ?></th>
                        <th><?php echo e(__('Country')); ?></th>
                        <th><?php echo e(__('State')); ?></th>
                        <th><?php echo e(__('District')); ?></th>
                        <th><?php echo e(__('Reference')); ?></th>
                        <th></th>
                    </tr>
                </tfoot>
            </table>
        </div>
    </div>

    
    <link rel="stylesheet" href="<?php echo e(asset('css/datatable/dataTables.bootstrap5.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/datatable/buttons.dataTables.min.css')); ?>">
    
    <script src="<?php echo e(asset('js/jquery-3.6.0.js')); ?>"></script>
    <script src="<?php echo e(asset('js/datatable/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/datatable/dataTables.bootstrap5.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/datatable/dataTables.buttons.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/ajax/jszip.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/ajax/pdfmake.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/ajax/vfs_fonts.js')); ?>"></script>
    <script src="<?php echo e(asset('js/datatable/buttons.html5.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/datatable/buttons.print.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/datatable/buttons.print.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/datatable/sorting/date-eu.js')); ?>"></script>

    
    <script type="text/javascript">
        $(document).ready(function() {
            function getLanguage() {
                var lang = $('html').attr('lang');
                if (lang == 'es') {
                    lng = "es-ES";
                } else if (lang == 'en') {
                    lng = "en-GB";
                }
                var result = null;
                var path = 'https://cdn.datatables.net/plug-ins/1.11.5/i18n/';
                result = path + lng + ".json";
                return result;
            }
            // Build Datatable
            $('#datatable').DataTable({
                language: {
                    "url": getLanguage()
                },
                bInfo: false,
                lengthChange: false,
                pageLength: 10,
                lengthMenu: [
                    [10],
                    [10]
                ]
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>