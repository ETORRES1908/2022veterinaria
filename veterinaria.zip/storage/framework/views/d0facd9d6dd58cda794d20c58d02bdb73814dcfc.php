<?php $__env->startSection('title'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1><?php echo e(__('EVENT')); ?></h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid bg-black">
        <?php if(session('mensaje')): ?>
            <div class="alert alert-success">
                <?php echo e(session('mensaje')); ?>

            </div>
        <?php endif; ?>
        <br>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('chngs')): ?>
            <a class="btn btn-primary" href="<?php echo e(route('meventos.edit', $evento->id)); ?>"><?php echo e(__('Edit')); ?></a>
        <?php endif; ?>
        <div class="row text-danger" style="padding:5vh 0 10vh 0;font-size: 1.3em">
            <div class="col-md-5 text-center center-block">
                <div class="row">
                    <div class="col-xs-6">
                        <a href="<?php echo e(route('usuarios.show', $evento->organizador->id)); ?>">
                            <img width="150" src="<?php echo e(asset($evento->organizador->foto)); ?>" class="form-group">
                            <div><?php echo e(__('Organizer')); ?></div>
                            <div><?php echo e($evento->organizador->nombre); ?> <?php echo e($evento->organizador->apellido); ?></div>
                        </a>
                    </div>
                    <div class="col-xs-6">
                        <a href="<?php echo e(route('usuarios.show', $evento->mcontrol->id)); ?>">
                            <img width="150" src="<?php echo e(asset($evento->mcontrol->foto)); ?>" class="form-group">
                            <div><?php echo e(__('Control desk')); ?></div>
                            <div><?php echo e($evento->mcontrol->nombre); ?> <?php echo e($evento->mcontrol->apellido); ?></div>
                        </a>
                    </div>
                    <div class="col-xs-6">
                        <a href="<?php echo e(route('usuarios.show', $evento->judge->id)); ?>">
                            <img width="150" src="<?php echo e(asset($evento->judge->foto)); ?>" class="form-group">
                            <div><?php echo e(__('Judge')); ?></div>
                            <div><?php echo e($evento->judge->nombre); ?> <?php echo e($evento->judge->apellido); ?></div>
                        </a>
                    </div>
                    <?php if(!empty($evento->assistent)): ?>
                        <div class="col-xs-6 form-group">
                            <a href="<?php echo e(route('usuarios.show', $evento->assistent->id)); ?>">
                                <img width="150" src="<?php echo e(asset($evento->assistent->foto)); ?>" class="form-group">
                                <div><?php echo e(__('Assistant')); ?></div>
                                <div><?php echo e($evento->assistent->nombre); ?> <?php echo e($evento->assistent->apellido); ?></div>
                            </a>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
            <div class="col-md-7 center-block">
                <div class="row">
                    
                    <div class="col-xs-12 form-group">
                        <label><?php echo e(__('Dates')); ?></label>
                        <div class="row">
                            <?php $__currentLoopData = $evento->fechas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fecha): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-xs-4 form-group">
                                    <label type="text" class="form-control text-danger">
                                        <?php echo e($fecha); ?>

                                    </label>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                    
                    <div class="col-xs-4 form-group">
                        <label><?php echo e(__('Coliseum')); ?></label>
                        <select class="form-control" id="coliseo_id" name="coliseo_id" disabled>
                            <option value="<?php echo e($evento->coliseum->id); ?>" selected>
                                <?php echo e($evento->coliseum->nombre); ?>

                            </option>
                        </select>
                    </div>
                    
                    <div class="col-xs-4 form-group"><label><?php echo e(__('Type Event')); ?></label>
                        <select class="form-control text-danger fw-bold" disabled style="-webkit-appearance: none;">
                            <option value="cmp" <?php if($evento->tevent == 'cmp'): ?> selected <?php endif; ?>>
                                <?php echo e(__('Championship')); ?>

                            </option>
                            <option value="cct" <?php if($evento->tevent == 'cmp'): ?> selected <?php endif; ?>>
                                <?php echo e(__('Concentration')); ?>

                            </option>
                            <option value="chk" <?php if($evento->tevent == 'chk'): ?> selected <?php endif; ?>>
                                <?php echo e(__('Chuscas')); ?>

                            </option>
                            <option value="drb" <?php if($evento->tevent == 'drb'): ?> selected <?php endif; ?>>
                                <?php echo e(__('Derby')); ?>

                            </option>
                            <option value="prt" <?php if($evento->tevent == 'prt'): ?> selected <?php endif; ?>>
                                <?php echo e(__('Party')); ?>

                            </option>
                            <option value="thr" <?php if($evento->tevent == 'thr'): ?> selected <?php endif; ?>>
                                <?php echo e(__('Other')); ?>

                            </option>
                        </select>
                    </div>
                    
                    <div class="col-xs-4 form-group">
                        <label><?php echo e(__('Regulation')); ?></label>
                        <select class="form-control text-danger fw-bold" disabled style="-webkit-appearance: none;">
                            <option eventovalue="cls" <?php if($evento->trl == 'cls'): ?> selected <?php endif; ?>>
                                <?php echo e(__('Coliseum')); ?></option>
                            <option eventovalue="dpt" <?php if($evento->trl == 'dpt'): ?> selected <?php endif; ?>>
                                <?php echo e(__('Departmental')); ?></option>
                            <option eventovalue="nac" <?php if($evento->trl == 'nac'): ?> selected <?php endif; ?>>
                                <?php echo e(__('National')); ?> </option>
                            <option value="inc" <?php if($evento->trl == 'inc'): ?> selected <?php endif; ?>>
                                <?php echo e(__('International')); ?>

                            </option>
                        </select>
                    </div>
                    
                    <div class="col-xs-12 form-group">
                        <label class="form-label"><?php echo e(__('Spurs')); ?></label>
                        <div class="row">
                            <?php $__currentLoopData = $evento->spl; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $spl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($spl == 'lbr'): ?>
                                    <div class="col-xs-4 form-group">
                                        <label class="form-control text-danger">Libre</label>
                                    </div>
                                <?php elseif($spl == 'fbr'): ?>
                                    <div class="col-xs-4 form-group">
                                        <label class="form-control text-danger">Fibra</label>
                                    </div>
                                <?php elseif($spl == 'plt'): ?>
                                    <div class="col-xs-4 form-group">
                                        <label class="form-control text-danger">Plastica</label>
                                    </div>
                                <?php elseif($spl == 'cry'): ?>
                                    <div class="col-xs-4 form-group">
                                        <label class="form-control text-danger">Carey</label>
                                    </div>
                                <?php elseif($spl == 'spn'): ?>
                                    <div class="col-xs-4 form-group">
                                        <label class="form-control text-danger">Espina</label>
                                    </div>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                    
                    <div class="col-xs-3 form-group">
                        <label><?php echo e(__('Size')); ?></label>
                        <input type="text" class="form-control" value="<?php echo e($evento->sz); ?>" readonly>
                    </div>
                    
                    <div class="col-xs-3 form-group">
                        <label><?php echo e(__('Time')); ?></label>
                        <input type="text" class="form-control" value="<?php echo e($evento->sz); ?>" readonly>
                    </div>
                    
                    <div class="col-xs-6 form-group">
                        <label for="title" class="form-label"><?php echo e(__('Weight')); ?></label>
                        <div class="input-group">
                            <span class="input-group-addon">
                                Min</span>
                            <div class="form-control">
                                <?php echo e($evento->miw); ?></div>
                            <span class="input-group-addon">Max</span>
                            <div class="form-control">
                                <?php echo e($evento->maw); ?></div>
                        </div>
                    </div>
                    
                    <div class="col-xs-6 form-group">
                        <label><?php echo e(__('Country')); ?></label>
                        <input type="text" class="form-control" value="<?php echo e($evento->coliseum->country); ?>" readonly>
                    </div>
                    
                    <div class="col-xs-6 form-group">
                        <label><?php echo e(__('State')); ?></label>
                        <input type="text" class="form-control" value="<?php echo e($evento->coliseum->state); ?>" readonly>
                    </div>
                    
                    <div class="col-xs-8 form-group">
                        <label><?php echo e(__('Referencia')); ?></label>
                        <input class="form-control" type="text" id="rfr" readonly>
                    </div>
                    
                    <div class="col-xs-4 form-group">
                        <label><?php echo e(__('District')); ?></label>
                        <input class="form-control" type="text" id="drt" readonly>
                    </div>
                    <div class="col-xs-4 form-group">
                        <label><?php echo e(__('1st WEIGH')); ?></label>
                        <input class="form-control" type="time" step='0' value="<?php echo e($evento->ftw); ?>" readonly>
                    </div>
                    <div class="col-xs-4 form-group">
                        <label><?php echo e(__('2nd WEIGH')); ?></label>
                        <input class="form-control" type="time" step='0' value="<?php echo e($evento->stw); ?>" readonly>
                    </div>
                    <div class="col-xs-4 form-group">
                        <label><?php echo e(__('Start')); ?></label>
                        <input class="form-control" type="time" step='0' value="<?php echo e($evento->hstart); ?>" readonly>
                    </div>
                    <div class="col-xs-6 form-group">
                        <label><?php echo e(__('Awards')); ?></label>
                        <input class="form-control" value="<?php echo e($evento->awards); ?>" readonly>
                    </div>
                    <div class="col-xs-6 form-group">
                        <label><?php echo e(__('Awards')); ?></label>
                        <input class="form-control" value="<?php echo e($evento->trophys); ?>" readonly>
                    </div>
                    <div class="col-xs-6 form-group">
                        <label><?php echo e(__('Rooster') . ' ' . $evento->trooster . __('seconds')); ?></label>
                        <input class="form-control" value="<?php echo e($evento->rooster); ?>" readonly>
                    </div>
                    <div class="col-xs-6 form-group">
                        <label>Super <?php echo e(__('Rooster') . ' 10' . __('seconds')); ?></label>
                        <input class="form-control" value="<?php echo e($evento->rten); ?>" readonly>
                    </div>
                    <div class="col-xs-4 form-group">
                        <label>1 <?php echo e(__('Forehead')); ?></label>
                        <input class="form-control" value="<?php echo e($evento->fft); ?>" readonly>
                    </div>
                    <div class="col-xs-4 form-group">
                        <label>2 <?php echo e(__('Forehead')); ?></label>
                        <input class="form-control" value="<?php echo e($evento->sft); ?>" readonly>
                    </div>
                    <div class="col-xs-4 form-group">
                        <label>3 <?php echo e(__('Forehead')); ?></label>
                        <input class="form-control" value="<?php echo e($evento->tft); ?>" readonly>
                    </div>
                    <div class="col-xs-4 form-group">
                        <label><?php echo e(__('Fight quality')); ?></label>
                        <input class="form-control" value="<?php echo e($evento->fcd); ?>" readonly>
                    </div>
                    
                    <div class="col-xs-4 form-group">
                        <label><?php echo e(__('Turkeys')); ?></label>
                        <input class="form-control" value="<?php echo e($evento->pvs); ?>" readonly />
                    </div>
                    
                    <div class="col-xs-4 form-group">
                        <label><?php echo e(__('Piglets')); ?></label>
                        <input class="form-control" value="<?php echo e($evento->lch); ?>" readonly />
                    </div>
                    
                    <div class="col-xs-4 form-group">
                        <label><?php echo e(__('Baskets')); ?></label>
                        <input class="form-control" value="<?php echo e($evento->cnt); ?>" readonly />
                    </div>
                    
                    <div class="col-xs-4 form-group">
                        <label><?php echo e(__('Bags')); ?> 20KG </label>
                        <input class="col form-control" value="<?php echo e($evento->skg); ?>" readonly />
                    </div>
                </div>
            </div>
        </div>
    </div>

     <style>
        .form-control {
            color: rgb(210, 0, 0);
        }

        .form-group {
            margin-bottom: 1vh;
        }

    </style>
    <script src="<?php echo e(asset('js/jquery-3.6.0.js')); ?>"></script>
    
    <script>
        /* ALERT */
        setTimeout(function() {
            $('.alert').fadeOut('slow');
        }, 5000);

        function displayVals1() {
            var id = $('#coliseo_id').val();
            $.ajax({
                type: 'GET', //THIS NEEDS TO BE GET
                url: '/coliseums/' + id,
                dataType: 'json',
                success: function(data) {
                    console.log(data);
                    $.each(data, function(i, item) {
                        $("#ctr").val(item.country);
                        $("#stt").val(item.state);
                        $("#drt").val(item.district);
                        $("#rfr").val(item.reference);
                    });
                },
                error: function() {
                    console.log(data);
                }
            });
        }
        $("#coliseo_id").change(displayVals1);
        displayVals1();
        //HIDE
        setTimeout(function() {
            $('.alert').fadeOut(3000);
        });
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>