<?php $__env->startSection('content'); ?>
    <?php if(session('mensaje')): ?>
        <div class="alert btn alert-warning" id="mensaje">
            <?php echo e(__('YOUR EVENT IS WAITING FOR APPROVAL FROM THE ADMINISTRATOR, YOU WILL BE SENT AN EMAIL.')); ?>

        </div>
    <?php endif; ?>

    <div class="card bg-black border border-danger">
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('addevent')): ?>
            <div class="card-header border border-danger">
                <a href="<?php echo e(route('events.create')); ?>" class="btn btn-success" style="font-size: 95%">
                    <?php echo e(__('Create your event')); ?></a>
            </div>
        <?php endif; ?>
        <div class="card-body table-responsive border border-danger text-uppercase">
            <table id="datatable" class="table table-dark table-hover" style="width:100%">
                <thead>
                    <tr>
                        <th><?php echo e(__('Date')); ?></th>
                        <th><?php echo e(__('Shed')); ?></th>
                        <th><?php echo e(__('Award')); ?></th>
                        <th><?php echo e(__('Type Event')); ?></th>
                        <th><?php echo e(__('State')); ?></th>
                        <th><?php echo e(__('Country')); ?></th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $eventos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $evento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($evento->fechas[0]); ?></td>
                            <td><?php echo e($evento->organizador->galpon); ?></td>
                            <td><?php echo e($evento->awards); ?></td>
                            <td> <select class="form-control text-white" disabled
                                    style="-webkit-appearance: none;background: none;border: none">
                                    <option <?php if($evento->tevent == 'cmp'): ?> selected <?php endif; ?>>
                                        <?php echo e(__('Championship')); ?>

                                    </option>
                                    <option <?php if($evento->tevent == 'cct'): ?> selected <?php endif; ?>>
                                        <?php echo e(__('Concentration')); ?>

                                    </option>
                                    <option <?php if($evento->tevent == 'chk'): ?> selected <?php endif; ?>>
                                        <?php echo e(__('Chuzk')); ?>

                                    </option>
                                    <option <?php if($evento->tevent == 'drb'): ?> selected <?php endif; ?>>
                                        <?php echo e(__('Derby')); ?>

                                    </option>
                                    <option <?php if($evento->tevent == 'prt'): ?> selected <?php endif; ?>>
                                        <?php echo e(__('Party')); ?>

                                    </option>
                                    <option <?php if($evento->tevent == 'thr'): ?> selected <?php endif; ?>>
                                        <?php echo e(__('Other')); ?>

                                    </option>
                                </select>

                            </td>
                            <td>
                                <?php echo e($evento->coliseum->state); ?>

                            </td>
                            <td>
                                <?php echo e($evento->coliseum->country); ?>

                            </td>
                            <td>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->denies('sentence')): ?>
                                    <a href="<?php echo e(route('events.show', $evento->id)); ?>" class="btn btn-warning">
                                        <?php echo e(__('participate')); ?>

                                    </a>
                                <?php endif; ?>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('sentence')): ?>
                                <?php if(Auth::user()->id == $evento->judge_id): ?>
                                    <a href="<?php echo e(route('pactados.show', $evento->id)); ?>" class="btn btn-warning">
                                        <?php echo e(__('sentence')); ?>

                                    </a>
                                <?php endif; ?>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                <tfoot>
                    <tr>
                         <th><?php echo e(__('Date')); ?></th>
                        <th><?php echo e(__('Shed')); ?></th>
                        <th><?php echo e(__('Award')); ?></th>
                        <th><?php echo e(__('Type Event')); ?></th>
                        <th><?php echo e(__('State')); ?></th>
                        <th><?php echo e(__('Country')); ?></th>
                        <th></th>
                    </tr>
                </tfoot>
            </table>
        </div>
    </div>

    
    <link rel="stylesheet" href="<?php echo e(asset('css/datatable/dataTables.bootstrap5.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/datatable/buttons.dataTables.min.css')); ?>">
    
    <script src="<?php echo e(asset('js/datatable/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/datatable/dataTables.bootstrap5.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/datatable/dataTables.buttons.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/ajax/jszip.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/ajax/pdfmake.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/ajax/vfs_fonts.js')); ?>"></script>
    <script src="<?php echo e(asset('js/datatable/buttons.html5.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/datatable/buttons.print.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/datatable/buttons.print.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/datatable/sorting/date-eu.js')); ?>"></script>

    
    <script type="text/javascript">
        function getLanguage() {
            var lang = $('html').attr('lang');
            if (lang == 'es') {
                lng = "es-ES";
            } else if (lang == 'en') {
                lng = "en-GB";
            }
            var result = null;
            var path = 'https://cdn.datatables.net/plug-ins/1.11.5/i18n/';
            result = path + lng + ".json";
            return result;
        }
        // Build Datatable
        $('#datatable').DataTable({
            language: {
                "url": getLanguage()
            },
            "columnDefs": [{
                "targets": 0,
                "type": "date-eu"
            }],
            bInfo: false,
            lengthChange: false,
            pageLength: 10,
            lengthMenu: [
                [10],
                [10]
            ]
        });

        //HIDE
        setTimeout(function() {
            $('.alert').fadeOut(6000);
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>