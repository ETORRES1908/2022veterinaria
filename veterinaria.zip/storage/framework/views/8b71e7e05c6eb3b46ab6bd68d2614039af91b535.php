<?php $__env->startSection('content'); ?>
    <div class="card bg-black border border-danger">
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('events.create')): ?>
            <div class="card-header border border-danger">
                <a href="<?php echo e(route('Events.create')); ?>" class="btn btn-success" style="font-size: 95%">
                    <?php echo e(__('Add Event')); ?></a>
            </div>
        <?php endif; ?>
        <div class="card-body table-responsive border border-danger">
            <table id="datatable" class="table table-dark table-hover" style="width:100%">
                <thead>
                    <tr>
                        <th><?php echo e(__('Date')); ?></th>
                        <th><?php echo e(__('Organizer')); ?></th>
                        <th><?php echo e(__('Control desk')); ?></th>
                        <th><?php echo e(__('Judge')); ?></th>
                        <th><?php echo e(__('Assistant')); ?></th>
                        <th class="nowrap"><?php echo e(__('Place')); ?></th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $eventos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $evento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e(str_replace('-', '/', $evento->fechas[0])); ?>

                            </td>
                            <td>
                                <button type="button" class="btn btn-dark" data-bs-toggle="modal"
                                    data-bs-target="#Organizador<?php echo e($evento->organizador->id); ?>">
                                    <?php echo e($evento->organizador->nombre . ' ' . $evento->organizador->apellido); ?>

                                </button>
                                <!-- Modal 1-->
                                <div class="modal fade" id="Organizador<?php echo e($evento->organizador->id); ?>"
                                    aria-hidden="true" aria-labelledby="Organizador" tabindex="-1">
                                    <div class="modal-dialog modal-dialog-centered">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <button type="button" class="btn btn-danger bg-danger btn-close" data-bs-dismiss="modal"
                                                    aria-label="Close"></button>
                                            </div>
                                            <div class="modal-body mx-auto">
                                                <figure class="figure">
                                                    <img src="<?php if(!empty($evento->organizador->foto)): ?> <?php echo e(asset($evento->organizador->foto)); ?> <?php else: ?><?php echo e(asset('storage/img/pata.jpg')); ?> <?php endif; ?>"
                                                        class="figure-img d-block mx-auto" height="250vh">
                                                    <figcaption class="figure-caption">
                                                        <?php echo e($evento->organizador->nombre . ' ' . $evento->organizador->apellido); ?>

                                                        -
                                                        <?php echo e($evento->organizador->country . ' ' . $evento->organizador->state); ?>

                                                        <br>
                                                        <?php echo e($evento->organizador->direction); ?>

                                                    </figcaption>
                                                </figure>
                                            </div>
                                            <div class="modal-footer d-flex justify-content-between">
                                                <button class="btn btn-primary"
                                                    data-bs-target="#Asistente<?php echo e($evento->assistent->id); ?>"
                                                    data-bs-toggle="modal">
                                                    <?php echo e(__('Assistent')); ?>

                                                </button>
                                                <button class="btn btn-primary"
                                                    data-bs-target="#MControl<?php echo e($evento->mcontrol->id); ?>"
                                                    data-bs-toggle="modal">
                                                    <?php echo e(__('Desktop Control')); ?>

                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </td>
                            <td>
                                <button type="button" class="btn btn-dark" data-bs-toggle="modal"
                                    data-bs-target="#MControl<?php echo e($evento->mcontrol->id); ?>">
                                    <?php echo e($evento->mcontrol->nombre . ' ' . $evento->mcontrol->apellido); ?>

                                </button>
                                <!-- Modal 2-->
                                <div class="modal fade" id="MControl<?php echo e($evento->mcontrol->id); ?>" aria-hidden="true"
                                    aria-labelledby="MControl" tabindex="-1">
                                    <div class="modal-dialog modal-dialog-centered">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <button type="button" class="btn btn-danger bg-danger btn-close" data-bs-dismiss="modal"
                                                    aria-label="Close"></button>
                                            </div>
                                            <div class="modal-body mx-auto">
                                                <figure class="figure">
                                                    <img src="<?php if(!empty($evento->mcontrol->foto)): ?> <?php echo e(asset($evento->mcontrol->foto)); ?> <?php else: ?><?php echo e(asset('storage/img/pata.jpg')); ?> <?php endif; ?>"
                                                        class="figure-img d-block mx-auto" height="250vh">
                                                    <figcaption class="figure-caption">
                                                        <?php echo e($evento->mcontrol->nombre . ' ' . $evento->mcontrol->apellido); ?>

                                                        -
                                                        <?php echo e($evento->mcontrol->country . ' ' . $evento->mcontrol->state); ?>

                                                        <br>
                                                        <?php echo e($evento->mcontrol->direction); ?>

                                                    </figcaption>
                                                </figure>
                                            </div>
                                            <div class="modal-footer d-flex justify-content-between">
                                                <button class="btn btn-primary"
                                                    data-bs-target="#Organizador<?php echo e($evento->organizador->id); ?>"
                                                    data-bs-toggle="modal">
                                                    <?php echo e(__('Organizer')); ?>

                                                </button>
                                                <button class="btn btn-primary"
                                                    data-bs-target="#Judge<?php echo e($evento->judge->id); ?>"
                                                    data-bs-toggle="modal">
                                                    <?php echo e(__('Judge')); ?>

                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </td>
                            <td>
                                <button type="button" class="btn btn-dark" data-bs-toggle="modal"
                                    data-bs-target="#Judge<?php echo e($evento->judge->id); ?>">
                                    <?php echo e($evento->judge->nombre . ' ' . $evento->judge->apellido); ?>

                                </button>
                                <!-- Modal 3-->
                                <div class="modal fade" id="Judge<?php echo e($evento->judge->id); ?>" aria-hidden="true"
                                    aria-labelledby="Judge" tabindex="-1">
                                    <div class="modal-dialog modal-dialog-centered">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <button type="button" class="btn btn-danger bg-danger btn-close" data-bs-dismiss="modal"
                                                    aria-label="Close"></button>
                                            </div>
                                            <div class="modal-body mx-auto">
                                                <figure class="figure">
                                                    <img src="<?php if(!empty($evento->judge->foto)): ?> <?php echo e(asset($evento->judge->foto)); ?> <?php else: ?><?php echo e(asset('storage/img/pata.jpg')); ?> <?php endif; ?>"
                                                        class="figure-img d-block mx-auto" height="250vh">
                                                    <figcaption class="figure-caption">
                                                        <?php echo e($evento->judge->nombre . ' ' . $evento->judge->apellido); ?> -
                                                        <?php echo e($evento->judge->country . ' ' . $evento->judge->state); ?> <br>
                                                        <?php echo e($evento->judge->direction); ?>

                                                    </figcaption>
                                                </figure>
                                            </div>
                                            <div class="modal-footer d-flex justify-content-between">
                                                <button class="btn btn-primary"
                                                    data-bs-target="#MControl<?php echo e($evento->mcontrol->id); ?>"
                                                    data-bs-toggle="modal">
                                                    <?php echo e(__('Desktop Control')); ?></button>
                                                <button class="btn btn-primary"
                                                    data-bs-target="#Asistente<?php echo e($evento->assistent->id); ?>"
                                                    data-bs-toggle="modal">
                                                    <?php echo e(__('Assitent')); ?> </button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </td>
                            <td>
                                <button type="button" class="btn btn-dark" data-bs-toggle="modal"
                                    data-bs-target="#Asistente<?php echo e($evento->assistent->id); ?>">
                                    <?php echo e($evento->assistent->nombre . ' ' . $evento->assistent->apellido); ?>

                                </button>
                                <!-- Modal 4-->
                                <div class="modal fade" id="Asistente<?php echo e($evento->assistent->id); ?>" aria-hidden="true"
                                    aria-labelledby="Asistente" tabindex="-1">
                                    <div class="modal-dialog modal-dialog-centered">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <button type="button" class="btn btn-danger bg-danger btn-close" data-bs-dismiss="modal"
                                                    aria-label="Close"></button>
                                            </div>
                                            <div class="modal-body mx-auto">
                                                <figure class="figure">
                                                    <img src="<?php if(!empty($evento->assistent->foto)): ?> <?php echo e(asset($evento->assistent->foto)); ?> <?php else: ?><?php echo e(asset('storage/img/pata.jpg')); ?> <?php endif; ?>"
                                                        class="figure-img d-block mx-auto" height="250vh">
                                                    <figcaption class="figure-caption">
                                                        <?php echo e($evento->assistent->nombre . ' ' . $evento->assistent->apellido); ?>

                                                        -
                                                        <?php echo e($evento->assistent->country . ' ' . $evento->assistent->state); ?>

                                                        <br>
                                                        <?php echo e($evento->assistent->direction); ?>

                                                    </figcaption>
                                                </figure>
                                            </div>
                                            <div class="modal-footer d-flex justify-content-between">
                                                <button class="btn btn-primary"
                                                    data-bs-target="#Judge<?php echo e($evento->mcontrol->id); ?>"
                                                    data-bs-toggle="modal">
                                                    <?php echo e(__('Judge')); ?></button>
                                                <button class="btn btn-primary"
                                                    data-bs-target="#Organizador<?php echo e($evento->organizador->id); ?>"
                                                    data-bs-toggle="modal">
                                                    <?php echo e(__('Organizer')); ?></button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </td>
                            <td class="nowrap">
                                <h6 class="nowrap">
                                    <?php switch ($evento->ctr) {
                                        case 'PE':
                                            echo 'Perú';
                                            break;
                                        case 'ARG':
                                            echo 'Argentina';
                                            break;
                                        case 'EC':
                                            echo 'Ecuador';
                                            break;
                                        case 'CL':
                                            echo 'Chile';
                                            break;
                                    } ?>,
                                    <?php echo e($evento->stt); ?><br><?php echo e($evento->drc); ?>

                                </h6>
                            </td>
                            <td>
                                <a href="<?php echo e(route('Events.show', $evento->id)); ?>" class="btn btn-warning">
                                    <?php echo e(__('View')); ?>

                                </a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                <tfoot>
                    <tr>
                        <th><?php echo e(__('Date')); ?></th>
                        <th><?php echo e(__('Organizer')); ?></th>
                        <th><?php echo e(__('Control desk')); ?></th>
                        <th><?php echo e(__('Judge')); ?></th>
                        <th><?php echo e(__('Assistant')); ?></th>
                        <th class="nowrap"><?php echo e(__('Place')); ?></th>
                        <th></th>
                    </tr>
                </tfoot>
            </table>
        </div>
    </div>

    
    <script type="text/javascript">
        $(document).ready(function() {
            function getLanguage() {
                var lang = $('html').attr('lang');
                if (lang == 'es') {
                    lng = "es-ES";
                } else if (lang == 'en') {
                    lng = "en-GB";
                }
                var result = null;
                var path = 'https://cdn.datatables.net/plug-ins/1.11.5/i18n/';
                result = path + lng + ".json";
                return result;
            }
            // Build Datatable
            $('#datatable').DataTable({
                language: {
                    "url": getLanguage()
                },
                "columnDefs": [{
                    "targets": 0,
                    "type": "date-eu"
                }],
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.datatable', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>