<?php $__env->startSection('content'); ?>
    <?php if(session('mensaje')): ?>
        <div class="alert btn alert-warning" id="mensaje">
            <?php echo e(__('YOUR EVENT IS WAITING FOR APPROVAL FROM THE ADMINISTRATOR, YOU WILL BE SENT AN EMAIL.')); ?>

        </div>
    <?php endif; ?>

    <div class="card bg-black border border-danger">
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('events.create')): ?>
            <div class="card-header border border-danger">
                <a href="<?php echo e(route('events.create')); ?>" class="btn btn-success" style="font-size: 95%">
                    <?php echo e(__('Add Event')); ?></a>
            </div>
        <?php endif; ?>
        <div class="card-body table-responsive border border-danger">
            <table id="datatable" class="table table-dark table-hover" style="width:100%">
                <thead>
                    <tr>
                        <th><?php echo e(__('Date')); ?></th>
                        <th><?php echo e(__('City')); ?></th>
                        <th><?php echo e(__('State')); ?></th>
                        <th><?php echo e(__('Country')); ?></th>
                        <th class="nowrap"><?php echo e(__('Reference')); ?></th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $eventos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $evento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($evento->fechas[0]); ?></td>
                            <td><?php echo e($evento->coliseum->district); ?></td>
                            <td>
                                <select class="form-control text-white" style="background:none;border:none;" disabled>
                                    <option <?php if($evento->coliseum->state == 'AM'): ?> selected <?php endif; ?>>AM - Amazonas</option>
                                    <option <?php if($evento->coliseum->state == 'AN'): ?> selected <?php endif; ?>>AN - Ancash</option>
                                    <option <?php if($evento->coliseum->state == 'AP'): ?> selected <?php endif; ?>>AP - Apurímac</option>
                                    <option <?php if($evento->coliseum->state == 'AR'): ?> selected <?php endif; ?>>AR - Arequipa</option>
                                    <option <?php if($evento->coliseum->state == 'AY'): ?> selected <?php endif; ?>>AY - Ayacucho</option>
                                    <option <?php if($evento->coliseum->state == 'CJ'): ?> selected <?php endif; ?>>CJ - Cajamarca</option>
                                    <option <?php if($evento->coliseum->state == 'CZ'): ?> selected <?php endif; ?>>CZ - Cuzco</option>
                                    <option <?php if($evento->coliseum->state == 'HC'): ?> selected <?php endif; ?>>HC - Huancavelica</option>
                                    <option <?php if($evento->coliseum->state == 'HU'): ?> selected <?php endif; ?>>HU - Huánuco</option>
                                    <option <?php if($evento->coliseum->state == 'IC'): ?> selected <?php endif; ?>>IC - ICA</option>
                                    <option <?php if($evento->coliseum->state == 'JU'): ?> selected <?php endif; ?>>JU - Junín</option>
                                    <option <?php if($evento->coliseum->state == 'LL'): ?> selected <?php endif; ?>>LL - La Libertad</option>
                                    <option <?php if($evento->coliseum->state == 'LB'): ?> selected <?php endif; ?>>LB - Lambayeque</option>
                                    <option <?php if($evento->coliseum->state == 'LM'): ?> selected <?php endif; ?>>LM - Lima</option>
                                    <option <?php if($evento->coliseum->state == 'LO'): ?> selected <?php endif; ?>>LO - Loreto</option>
                                    <option <?php if($evento->coliseum->state == 'MD'): ?> selected <?php endif; ?>>MD - Madre de Dios</option>
                                    <option <?php if($evento->coliseum->state == 'MQ'): ?> selected <?php endif; ?>>MQ - Moquegua</option>
                                    <option <?php if($evento->coliseum->state == 'PA'): ?> selected <?php endif; ?>>PA - Pasco</option>
                                    <option <?php if($evento->coliseum->state == 'PI'): ?> selected <?php endif; ?>>PI - Piura</option>
                                    <option <?php if($evento->coliseum->state == 'PU'): ?> selected <?php endif; ?>>PU - Puno</option>
                                    <option <?php if($evento->coliseum->state == 'SM'): ?> selected <?php endif; ?>>SM - San Martín</option>
                                    <option <?php if($evento->coliseum->state == 'TA'): ?> selected <?php endif; ?>>TA - Tacna</option>
                                    <option <?php if($evento->coliseum->state == 'TU'): ?> selected <?php endif; ?>>TU - Tumbes</option>
                                    <option <?php if($evento->coliseum->state == 'UC'): ?> selected <?php endif; ?>>UC - Ucayali</option>
                                </select>
                            </td>
                            <td>
                                <select class="form-control text-white" style="background:none;border:none;" disabled>
                                    <option <?php if($evento->coliseum->country == 'PER'): ?> selected <?php endif; ?>>PER - Perú</option>
                                </select>
                            </td>
                            <td class="nowrap"><?php echo e($evento->coliseum->reference); ?></td>
                            <td>
                                <a href="<?php echo e(route('events.show', $evento->id)); ?>" class="btn btn-warning">
                                    <?php echo e(__('View')); ?>

                                </a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                <tfoot>
                    <tr>
                        <th><?php echo e(__('Date')); ?></th>
                        <th><?php echo e(__('City')); ?></th>
                        <th><?php echo e(__('State')); ?></th>
                        <th><?php echo e(__('Country')); ?></th>
                        <th class="nowrap"><?php echo e(__('Reference')); ?></th>
                        <th></th>
                    </tr>
                </tfoot>
            </table>
        </div>
    </div>

    
    <link rel="stylesheet" href="<?php echo e(asset('css/datatable/dataTables.bootstrap5.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/datatable/buttons.dataTables.min.css')); ?>">
    
    <script src="<?php echo e(asset('js/datatable/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/datatable/dataTables.bootstrap5.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/datatable/dataTables.buttons.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/ajax/jszip.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/ajax/pdfmake.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/ajax/vfs_fonts.js')); ?>"></script>
    <script src="<?php echo e(asset('js/datatable/buttons.html5.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/datatable/buttons.print.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/datatable/buttons.print.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/datatable/sorting/date-eu.js')); ?>"></script>

    
    <script type="text/javascript">
        function getLanguage() {
            var lang = $('html').attr('lang');
            if (lang == 'es') {
                lng = "es-ES";
            } else if (lang == 'en') {
                lng = "en-GB";
            }
            var result = null;
            var path = 'https://cdn.datatables.net/plug-ins/1.11.5/i18n/';
            result = path + lng + ".json";
            return result;
        }
        // Build Datatable
        $('#datatable').DataTable({
            language: {
                "url": getLanguage()
            },
            "columnDefs": [{
                "targets": 0,
                "type": "date-eu"
            }],
            bInfo: false,
            pageLength: 10,
            lengthMenu: [
                [10],
                [10]
            ]
        });

        //HIDE
        setTimeout(function() {
            $('.alert').fadeOut(5000);
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>