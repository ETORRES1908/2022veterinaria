<?php $__env->startSection('content'); ?>
    <?php if(session('mensaje')): ?>
        <div class="alert btn alert-warning" id="mensaje">
            <?php echo e(__('YOUR EVENT IS WAITING FOR APPROVAL FROM THE ADMINISTRATOR, YOU WILL BE SENT AN EMAIL.')); ?>

        </div>
    <?php endif; ?>

    <div class="card bg-black border border-danger">
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('events.create')): ?>
            <div class="card-header border border-danger">
                <a href="<?php echo e(route('events.create')); ?>" class="btn btn-success" style="font-size: 95%">
                    <?php echo e(__('Add Event')); ?></a>

            </div>
        <?php endif; ?>
        <div class="card-body table-responsive border border-danger">
            <table id="datatable" class="table table-dark table-hover" style="width:100%">
                <thead>
                    <tr>
                        <th><?php echo e(__('Date')); ?></th>
                        <th><?php echo e(__('City')); ?></th>
                        <th><?php echo e(__('State')); ?></th>
                        <th><?php echo e(__('Country')); ?></th>
                        <th class="nowrap"><?php echo e(__('Direction')); ?></th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $eventos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $evento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($evento->fechas[0]); ?></td>
                            <td><?php echo e($evento->drc); ?></td>
                            <td><select disabled class="text-white"
                                    style="-webkit-appearance: none;background:none;border:none;">
                                    <option <?php if($evento->stt == 'PE-AMA'): ?> selected <?php endif; ?>>Amazonas</option>
                                    <option <?php if($evento->stt == 'PE-ANC'): ?> selected <?php endif; ?>>Ancash</option>
                                    <option <?php if($evento->stt == 'PE-APU'): ?> selected <?php endif; ?>>Apurímac</option>
                                    <option <?php if($evento->stt == 'PE-ARE'): ?> selected <?php endif; ?>>Arequipa</option>
                                    <option <?php if($evento->stt == 'PE-AYA'): ?> selected <?php endif; ?>>Ayacucho</option>
                                    <option <?php if($evento->stt == 'PE-CAJ'): ?> selected <?php endif; ?>>Cajamarca</option>
                                    <option <?php if($evento->stt == 'PE-CUS'): ?> selected <?php endif; ?>>Cuzco</option>
                                    <option <?php if($evento->stt == 'PE-HUV'): ?> selected <?php endif; ?>>Huancavelica</option>
                                    <option <?php if($evento->stt == 'PE-HUC'): ?> selected <?php endif; ?>>Huánuco</option>
                                    <option <?php if($evento->stt == 'PE-ICA'): ?> selected <?php endif; ?>>ICA</option>
                                    <option <?php if($evento->stt == 'PE-JUN'): ?> selected <?php endif; ?>>Junín</option>
                                    <option <?php if($evento->stt == 'PE-LAL'): ?> selected <?php endif; ?>>La Libertad</option>
                                    <option <?php if($evento->stt == 'PE-LAM'): ?> selected <?php endif; ?>>Lambayeque</option>
                                    <option <?php if($evento->stt == 'PE-LIM'): ?> selected <?php endif; ?>>Lima</option>
                                    <option <?php if($evento->stt == 'PE-LOR'): ?> selected <?php endif; ?>>Loreto</option>
                                    <option <?php if($evento->stt == 'PE-MDD'): ?> selected <?php endif; ?>>Madre de Dios</option>
                                    <option <?php if($evento->stt == 'PE-MOQ'): ?> selected <?php endif; ?>>Moquegua</option>
                                    <option <?php if($evento->stt == 'PE-PAS'): ?> selected <?php endif; ?>>Pasco</option>
                                    <option <?php if($evento->stt == 'PE-PIU'): ?> selected <?php endif; ?>>Piura</option>
                                    <option <?php if($evento->stt == 'PE-PUN'): ?> selected <?php endif; ?>>Puno</option>
                                    <option <?php if($evento->stt == 'PE-SAM'): ?> selected <?php endif; ?>>San Martín</option>
                                    <option <?php if($evento->stt == 'PE-TAC'): ?> selected <?php endif; ?>>Tacna</option>
                                    <option <?php if($evento->stt == 'PE-TUM'): ?> selected <?php endif; ?>>Tumbes</option>
                                    <option <?php if($evento->stt == 'PE-UCA'): ?> selected <?php endif; ?>>Ucayali</option>
                                    
                                    <option <?php if($evento->stt == 'CL-AI'): ?> selected <?php endif; ?>>Aysén</option>
                                    <option <?php if($evento->stt == 'CL-AN'): ?> selected <?php endif; ?>>Antofagasta</option>
                                    <option <?php if($evento->stt == 'CL-AP'): ?> selected <?php endif; ?>>Arica y Parinacota
                                    </option>
                                    <option <?php if($evento->stt == 'CL-AR'): ?> selected <?php endif; ?>>Araucanía</option>
                                    <option <?php if($evento->stt == 'CL-AT'): ?> selected <?php endif; ?>>Atacama</option>
                                    <option <?php if($evento->stt == 'CL-BI'): ?> selected <?php endif; ?>>Biobío</option>
                                    <option <?php if($evento->stt == 'CL-CO'): ?> selected <?php endif; ?>>Coquimbo</option>
                                    <option <?php if($evento->stt == 'CL-LI'): ?> selected <?php endif; ?>>O'Higgins</option>
                                    <option <?php if($evento->stt == 'CL-LL'): ?> selected <?php endif; ?>>Los Lagos</option>
                                    <option <?php if($evento->stt == 'CL-LR'): ?> selected <?php endif; ?>>Los Ríos</option>
                                    <option <?php if($evento->stt == 'CL-MA'): ?> selected <?php endif; ?>>Magallanes y Antártica
                                    </option>
                                    <option <?php if($evento->stt == 'CL-ML'): ?> selected <?php endif; ?>>Maule</option>
                                    <option <?php if($evento->stt == 'CL-NB'): ?> selected <?php endif; ?>>Ñuble</option>
                                    <option <?php if($evento->stt == 'CL-RM'): ?> selected <?php endif; ?>>Santiago</option>
                                    <option <?php if($evento->stt == 'CL-TA'): ?> selected <?php endif; ?>>Tarapacá</option>
                                    <option <?php if($evento->stt == 'CL-VS'): ?> selected <?php endif; ?>>Valparaíso</option>
                                </select></td>
                            <td>
                                <?php switch ($evento->ctr) {
                                    case 'PER':
                                        echo 'Perú';
                                        break;
                                    case 'ARG':
                                        echo 'Argentina';
                                        break;
                                    case 'ECU':
                                        echo 'Ecuador';
                                        break;
                                    case 'CHL':
                                        echo 'Chile';
                                        break;
                                } ?>
                            </td>
                            <td class="nowrap"><?php echo e($evento->drc); ?></td>
                            <td>
                                <a href="<?php echo e(route('events.show', $evento->id)); ?>" class="btn btn-warning">
                                    <?php echo e(__('View')); ?>

                                </a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                <tfoot>
                    <tr>
                        <th><?php echo e(__('Date')); ?></th>
                        <th><?php echo e(__('City')); ?></th>
                        <th><?php echo e(__('State')); ?></th>
                        <th><?php echo e(__('Country')); ?></th>
                        <th class="nowrap"><?php echo e(__('Direction')); ?></th>
                        <th></th>
                    </tr>
                </tfoot>
            </table>
        </div>
    </div>

    
    <link rel="stylesheet" href="https://cdn.datatables.net/1.11.5/css/dataTables.bootstrap5.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/buttons/2.2.2/css/buttons.dataTables.min.css">
    
    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.5/js/dataTables.bootstrap5.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/2.2.2/js/dataTables.buttons.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
    <script src="https://cdn.datatables.net/buttons/2.2.2/js/buttons.html5.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/2.2.2/js/buttons.print.min.js"></script>
    <script src="https:////cdn.datatables.net/plug-ins/1.11.5/sorting/date-eu.js"></script>
    
    <script type="text/javascript">
        function getLanguage() {
            var lang = $('html').attr('lang');
            if (lang == 'es') {
                lng = "es-ES";
            } else if (lang == 'en') {
                lng = "en-GB";
            }
            var result = null;
            var path = 'https://cdn.datatables.net/plug-ins/1.11.5/i18n/';
            result = path + lng + ".json";
            return result;
        }
        // Build Datatable
        $('#datatable').DataTable({
            language: {
                "url": getLanguage()
            },
            "columnDefs": [{
                "targets": 0,
                "type": "date-eu"
            }],
        });

        $(document).ready(function() {
            $('#datatable').DataTable();
        });
        //HIDE
        setTimeout(function() {
            $('.alert').fadeOut(5000);
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.datatable', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>