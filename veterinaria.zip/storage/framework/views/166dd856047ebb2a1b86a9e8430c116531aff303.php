<?php $__env->startSection('content'); ?>
    <div class="card bg-black mx-auto text-dark border border-danger mb-3">
        <div class="card-body border border-danger">
            <div class="row mx-auto">
                <div class="col-6 col-md-3 mb-3">
                    <img src=" <?php echo e(asset('storage/img/pata.jpg')); ?>" class="img-fluid d-block mx-auto">
                </div>
                <div class="col-6 col-md-3 my-auto">
                    <ul class="list-unstyled text-white">
                        <li>
                            <h6> <?php echo e(__('USER')); ?>: <?php echo e(Auth::user()->name); ?></h6>
                        </li>
                        <li>
                            <h6><?php echo e(__('GALPON')); ?>: <?php echo e(Auth::user()->galpon); ?></h6>
                        </li>
                        <li>
                            <h6><?php echo e(__('COUNTRY')); ?>: <?php echo e(Auth::user()->country); ?></h6>
                        </li>
                        <li>
                            <h6><?php echo e(__('STATE')); ?>: <?php echo e(Auth::user()->state); ?></h6>
                        </li>
                    </ul>
                </div>
                <div class="col-6 col-md-3 my-auto">
                    <img src="<?php if(!empty(
    Auth::user()->mascotas[0]->fotos->where('nfoto', 1)->first()
)): ?> <?php echo e(asset(Auth::user()->mascotas[0]->fotos->where('nfoto', 1)->first()->ruta)); ?>

                    <?php else: ?><?php echo e(asset('storage/img/pata.jpg')); ?> <?php endif; ?>"
                        class="img-fluid d-block mx-auto">
                </div>
                <div class="col-6 col-sm-3 my-auto">
                    <img src="<?php if(!empty(
    Auth::user()->mascotas[1]->fotos->where('nfoto', 1)->first()
)): ?> <?php echo e(asset(Auth::user()->mascotas[1]->fotos->where('nfoto', 1)->first()->ruta)); ?>

                    <?php else: ?><?php echo e(asset('storage/img/pata.jpg')); ?> <?php endif; ?>"
                        class="img-fluid d-block mx-auto">
                </div>
            </div>
        </div>
    </div>
    <div class="card mx-auto text-dark border border-danger">
        <div class="card-body border border-danger">
            <form class="form-horizontal" method="POST" action="<?php echo e(route('Events.store')); ?>"
                enctype="multipart/form-data">
                <?php echo e(csrf_field()); ?>

                <div class="row">
                    
                    <input id="organizador_id" type="text" name="organizador_id" value="<?php echo e(Auth::user()->id); ?>" hidden>
                    
                    <div>
                        <label for="jueza_id" class="col-form-label fw-bold">
                            <?php echo e(__('Dates')); ?>

                            <a class="btn btn-success" id="adddates">+</a>
                            <a class="btn btn-danger" id="removedate">-</a>

                            <?php if($errors->has('fechas')): ?>
                                <span class="text-danger text-fs6">
                                    <?php echo e(__('Get the dates right')); ?>

                                </span>
                            <?php endif; ?>
                        </label>
                        <div class="form_dates row g-3">
                        </div>
                    </div>
                    
                    <div class="col-sm-4 mb-3 form-group<?php echo e($errors->has('coliseum') ? ' has-error' : ''); ?>">
                        <label for="coliseum" class="col-form-label fw-bold">
                            <?php echo e(__('Coliseum')); ?>

                        </label>
                        <div class="col-auto">
                            <input id="coliseum" type="text" class="form-control text-danger fw-bold" name="coliseum"
                                value="<?php echo e(old('coliseum')); ?>" required autofocus>

                            <?php if($errors->has('coliseum')): ?>
                                <span class="text-danger text-fs6">
                                    <?php echo e($errors->first('coliseum')); ?>

                                </span>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                    <div class="col-sm-4 mb-3 form-group<?php echo e($errors->has('tevent') ? ' has-error' : ''); ?>">
                        <label for="tevent" class="col-form-label fw-bold">
                            <?php echo e(__('Type Event')); ?>

                        </label>
                        <div class="col-auto">
                            <select class="form-select text-danger fw-bold" id="tevent" name="tevent"
                                value="<?php echo e(old('tevent')); ?>" required autofocus>
                                <option value="cmp">
                                    <?php echo e(__('Championship')); ?>

                                </option>
                                <option value="cct">
                                    <?php echo e(__('Concentration')); ?>

                                </option>
                                <option value="chk">
                                    <?php echo e(__('Chuzbk')); ?>

                                </option>
                                <option value="drb">
                                    <?php echo e(__('Derby')); ?>

                                </option>
                                <option value="prt">
                                    <?php echo e(__('Party')); ?>

                                </option>
                                <option value="thr">
                                    <?php echo e(__('Other')); ?>

                                </option>
                            </select>

                            <?php if($errors->has('tevent')): ?>
                                <span class="text-danger text-fs6">
                                    <?php echo e($errors->first('tevent')); ?>

                                </span>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                    <div class="col-sm-3 mb-3 form-group<?php echo e($errors->has('trule') ? ' has-error' : ''); ?>">
                        <label for="trule" class="col-form-label fw-bold">
                            <?php echo e(__('Regulation')); ?>

                        </label>
                        <div class="col-auto">
                            <select class="form-control form-select text-danger fw-bold" id="trule" name="trule"
                                value="<?php echo e(old('trule')); ?>" required autofocus>
                                <option class="text-danger fw-bold" selected value="cls">Coliseo</option>
                                <option class="text-danger fw-bold" value="dpt">Departamental </option>
                                <option class="text-danger fw-bold" value="nac">Nacional</option>
                                <option class="text-danger fw-bold" value="inc">Internacional</option>
                            </select>
                            <?php if($errors->has('trule')): ?>
                                <span class="text-danger text-fs6">
                                    <?php echo e($errors->first('trule')); ?>

                                </span>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                    <div class="col-sm-3 mb-3 form-group<?php echo e($errors->has('trule') ? ' has-error' : ''); ?>">
                        <label for="trule" class="col-form-label fw-bold">
                            <?php echo e(__('ESPUELAS')); ?>

                        </label>
                        <div class="col-auto">
                            <div class="form-check form-switch">
                                <input class="form-check-input" type="checkbox" value="lbr" name="espuela[]">
                                <label class="form-check-label" for="switch">Libre</label>
                            </div>
                            <div class="form-check form-switch">
                                <input class="form-check-input" type="checkbox" value="fbr" name="espuela[]">
                                <label class="form-check-label" for="switch">Fibra</label>
                            </div>
                            <div class="form-check form-switch">
                                <input class="form-check-input" type="checkbox" value="plt" name="espuela[]">
                                <label class="form-check-label" for="switch">Plastica</label>
                            </div>
                            <div class="form-check form-switch">
                                <input class="form-check-input" type="checkbox" value="cry" name="espuela[]">
                                <label class="form-check-label" for="switch">Carey</label>
                            </div>
                            <div class="form-check form-switch">
                                <input class="form-check-input" type="checkbox" value="spn" name="espuela[]">
                                <label class="form-check-label" for="switch">Espina</label>
                            </div>
                            <?php if($errors->has('trule')): ?>
                                <span class="text-danger text-fs6">
                                    <?php echo e($errors->first('trule')); ?>

                                </span>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                    <div class="col-sm-3 mb-3 form-group<?php echo e($errors->has('size') ? ' has-error' : ''); ?>">
                        <label for="size" class="col-form-label fw-bold">
                            <?php echo e(__('Size')); ?>

                        </label>
                        <div class="col-auto">
                            <select class="form-control form-select text-danger fw-bold" id="size" name="size"
                                value="<?php echo e(old('size')); ?>" required autofocus>
                                <option class="text-danger fw-bold" selected value="5">5</option>
                                <option class="text-danger fw-bold" value="8">8 </option>
                                <option class="text-danger fw-bold" value="lbr">Libre</option>
                            </select>
                            <?php if($errors->has('size')): ?>
                                <span class="text-danger text-fs6">
                                    <?php echo e($errors->first('size')); ?>

                                </span>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                    <div class="col-sm-3 mb-3 form-group<?php echo e($errors->has('time') ? ' has-error' : ''); ?>">
                        <label for="time" class="col-form-label fw-bold">
                            <?php echo e(__('Time')); ?>

                        </label>
                        <div class="col-auto">
                            <select class="form-control form-select text-danger fw-bold" id="time" name="time"
                                value="<?php echo e(old('time')); ?>" required autofocus>
                                <option class="text-danger fw-bold" selected value="4">4</option>
                                <option class="text-danger fw-bold" value="9">6 </option>
                                <option class="text-danger fw-bold" value="8">8</option>
                                <option class="text-danger fw-bold" value="10">10</option>
                            </select>
                            <?php if($errors->has('time')): ?>
                                <span class="text-danger text-fs6">
                                    <?php echo e($errors->first('time')); ?>

                                </span>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                    <div class="col-sm-4 mb-3 form-group<?php echo e($errors->has('weight') ? ' has-error' : ''); ?>">
                        <label for="weight" class="col-form-label fw-bold">
                            <?php echo e(__('Weight')); ?>

                        </label>
                        <div class="col-auto">
                            <div class="input-group">
                                <span class="input-group-text">Min</span>
                                <input type="number" class="form-control" min="1"
                                    onKeyPress="if(this.value.length==3) return false;" />
                                <span class="input-group-text">-</span>
                                <input type="number" class="form-control" min="1"
                                    onKeyPress="if(this.value.length==3) return false;" />
                                <span class="input-group-text">Max</span>
                            </div>
                            <?php if($errors->has('time')): ?>
                                <span class="text-danger text-fs6">
                                    <?php echo e($errors->first('time')); ?>

                                </span>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                    <div class="col mb-3 form-group<?php echo e($errors->has('hstart') ? ' has-error' : ''); ?>">
                        <label for="weight" class="col-form-label fw-bold">
                            <?php echo e(__('First Time Weight')); ?>

                        </label>
                        <div class="col-auto">
                            <input id="hstart" type="time" step='1' class="form-control text-danger fw-bold" name="hstart"
                                value="<?php echo e(old('hstart')); ?>" required autofocus>

                            <?php if($errors->has('hstart')): ?>
                                <span class="text-danger text-fs6">
                                    <?php echo e($errors->first('hstart')); ?>

                                </span>
                            <?php endif; ?>
                        </div>
                        <?php if($errors->has('time')): ?>
                            <span class="text-danger text-fs6">
                                <?php echo e($errors->first('time')); ?>

                            </span>
                        <?php endif; ?>
                    </div>
                    
                    <div class="col mb-3 form-group<?php echo e($errors->has('hstart') ? ' has-error' : ''); ?>">
                        <label for="weight" class="col-form-label fw-bold">
                            <?php echo e(__('Second Time Weight')); ?>

                        </label>
                        <div class="col-auto">
                            <input id="hstart" type="time" step='1' class="form-control text-danger fw-bold" name="hstart"
                                value="<?php echo e(old('hstart')); ?>" required autofocus>

                            <?php if($errors->has('hstart')): ?>
                                <span class="text-danger text-fs6">
                                    <?php echo e($errors->first('hstart')); ?>

                                </span>
                            <?php endif; ?>
                        </div>
                        <?php if($errors->has('time')): ?>
                            <span class="text-danger text-fs6">
                                <?php echo e($errors->first('time')); ?>

                            </span>
                        <?php endif; ?>
                    </div>
                    
                    <div class="col mb-3 form-group<?php echo e($errors->has('hstart') ? ' has-error' : ''); ?>">
                        <label for="hstart" class="col-form-label fw-bold">
                            <?php echo e(__('Time Start')); ?>

                        </label>
                        <div class="col-auto">
                            <input id="hstart" type="time" step='1' class="form-control text-danger fw-bold" name="hstart"
                                value="<?php echo e(old('hstart')); ?>" required autofocus>

                            <?php if($errors->has('hstart')): ?>
                                <span class="text-danger text-fs6">
                                    <?php echo e($errors->first('hstart')); ?>

                                </span>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                    
                    <div class="col-sm-4 mb-3 form-group<?php echo e($errors->has('mcontrol') ? ' has-error' : ''); ?>">
                        <label for="mcontrol" class="col-form-label fw-bold">
                            <?php echo e(__('CONTROL DESK')); ?> A
                        </label>
                        <div class="col-auto">
                            <select class="form-select text-danger fw-bold" id="mcontrol" name="mcontrol"
                                value="<?php echo e(old('mcontrol')); ?>" required autofocus>
                                <?php $__currentLoopData = $judges; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $judge): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($judge->id); ?>"><?php echo e($judge->nombre . ' ' . $judge->apellido); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>

                            <?php if($errors->any()): ?>
                                <div class="alert alert-danger">
                                    <ul>
                                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li><?php echo e($error); ?></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                    <div class="col-sm-4 mb-3 form-group<?php echo e($errors->has('judge') ? ' has-error' : ''); ?>">
                        <label for="judge" class="col-form-label fw-bold">
                            <?php echo e(__('Judge')); ?>

                        </label>
                        <div class="col-auto">
                            <select class="form-select text-danger fw-bold" id="judge" name="judge"
                                value="<?php echo e(old('judge')); ?>" required autofocus>
                                <?php $__currentLoopData = $judges; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $judge): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($judge->id); ?>"><?php echo e($judge->nombre . ' ' . $judge->apellido); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>

                            <?php if($errors->has('judge')): ?>
                                <span class="text-danger text-fs6">
                                    <?php echo e($errors->first('judge')); ?>

                                </span>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                    <div class="col-sm-4 mb-3 form-group<?php echo e($errors->has('assinst') ? ' has-error' : ''); ?>">
                        <label for="assinst" class="col-form-label fw-bold">
                            <?php echo e(__('ASSINTENT')); ?>

                        </label>
                        <div class="col-auto">
                            <select class="form-select text-danger fw-bold" id="assinst" name="assinst"
                                value="<?php echo e(old('assinst')); ?>" required autofocus>
                                <?php $__currentLoopData = $judges; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $judge): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($judge->id); ?>"><?php echo e($judge->nombre . ' ' . $judge->apellido); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>

                            <?php if($errors->has('assinst')): ?>
                                <span class="text-danger text-fs6">
                                    <?php echo e($errors->first('assinst')); ?>

                                </span>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                    <label for="awards" class="col-form-label fw-bold">
                        <?php echo e(__('Awards')); ?>

                    </label>
                    
                    <div class="col-sm-4 mb-3 form-group<?php echo e($errors->has('trophy') ? ' has-error' : ''); ?>">
                        <label for="trophy" class="col-form-label fw-bold">
                            <?php echo e(__('Trophy')); ?>

                        </label>
                        <div class="col-auto">
                            <div class="input-group">
                                <div class="input-group-text">S/.</div>
                                <input id="trophy" type="number" class="form-control text-danger fw-bold" name="trophy"
                                    value="<?php echo e(old('trophy')); ?>" required autofocus min="0"
                                    onKeyPress="if(this.value.length==5) return false;" />

                                <?php if($errors->has('trophy')): ?>
                                    <span class="text-danger text-fs6">
                                        <?php echo e($errors->first('trophy')); ?>

                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-sm-4 mb-3 form-group<?php echo e($errors->has('rooster') ? ' has-error' : ''); ?>">
                        <label for="rooster" class="col-form-label fw-bold">
                            <?php echo e(__('Rooster')); ?>

                        </label>
                        <div class="col-auto">
                            <div class="input-group">
                                <div class="input-group-text">S/.</div>
                                <input id="rooster" type="number" class="form-control text-danger fw-bold" name="rooster"
                                    value="<?php echo e(old('rooster')); ?>" required autofocus min="0"
                                    onKeyPress="if(this.value.length==5) return false;">

                                <?php if($errors->has('rooster')): ?>
                                    <span class="text-danger text-fs6">
                                        <?php echo e($errors->first('rooster')); ?>

                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-sm-4 mb-3 form-group<?php echo e($errors->has('duel') ? ' has-error' : ''); ?>">
                        <label for="duel" class="col-form-label fw-bold">
                            <?php echo e(__('Duel')); ?>

                        </label>
                        <div class="col-auto">
                            <div class="input-group">
                                <div class="input-group-text">S/.</div>
                                <input id="duel" type="number" class="form-control text-danger fw-bold" name="duel"
                                    value="<?php echo e(old('duel')); ?>" required autofocus min="0"
                                    onKeyPress="if(this.value.length==5) return false;" />

                                <?php if($errors->has('duel')): ?>
                                    <span class="text-danger text-fs6">
                                        <?php echo e($errors->first('duel')); ?>

                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="mx-auto">
                    <button type="submit" class="btn btn-primary">
                        <?php echo e(__('Add Event')); ?>

                    </button>
                </div>
            </form>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.js"></script>
    <script type="text/javascript">
        $("#adddates").click(function() {
            $(".form_dates").append(
                '<div id="dfechas" class="col-6 col-md"><input id="fechas" type="date" class="form-control text-danger fw-bold" name="fechas[]" required autofocus ></div>'
            );
        });
        $("#removedate").click(function() {
            $('#dfechas').last().remove();
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>