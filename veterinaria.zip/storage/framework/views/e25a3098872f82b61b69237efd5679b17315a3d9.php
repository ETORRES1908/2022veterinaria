<?php $__env->startSection('title'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>Mantenimiento de Usuarios</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<?php $__env->startSection('content'); ?>
    <div class="table-responsive pb-1">
        <table id="datatable" class="table table-hover nowrap" style="width:100%">
            <thead>
                <tr>
                    <th><?php echo e(__('Username')); ?></th>
                    <th><?php echo e(__('Name')); ?></th>
                    <th><?php echo e(__('Surname')); ?></th>
                    <th><?php echo e(__('DNI')); ?></th>
                    <th><?php echo e(__('E-Mail Address')); ?></th>
                    <th><?php echo e(__('Country')); ?>,&nbsp<?php echo e(__('State')); ?>&nbsp-&nbsp<?php echo e(__('District')); ?></th>
                    <th><?php echo e(__('Status')); ?></th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($user->name); ?></td>
                        <td><?php echo e($user->nombre); ?></td>
                        <td><?php echo e($user->apellido); ?></td>
                        <td><?php echo e($user->dni); ?></td>
                        <td><?php echo e($user->email); ?></td>
                        <td><?php echo e($user->country); ?>, <?php echo e($user->state); ?><br><?php echo e($user->district); ?></td>
                        <td>
                            <?php if($user->status == 0): ?>
                                <span class="btn btn-primary"><?php echo e(__('Inactived')); ?></span>
                            <?php elseif($user->status == 1): ?>
                                <span class="btn btn-success"><?php echo e(__('Actived')); ?></span>
                            <?php elseif($user->status == 2): ?>
                                <span class="btn btn-warning"><?php echo e(__('Suspended')); ?></span>
                            <?php elseif($user->status == 3): ?>
                                <span class="btn btn-danger"><?php echo e(__('Cancelled')); ?></span>
                            <?php endif; ?>
                        </td>
                        <td><a href="<?php echo e(route('usuarios.edit', $user->id)); ?>">Ver</a></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
            <tfoot>
                <tr>
                    <th><?php echo e(__('Username')); ?></th>
                    <th><?php echo e(__('Name')); ?></th>
                    <th><?php echo e(__('Surname')); ?></th>
                    <th><?php echo e(__('DNI')); ?></th>
                    <th><?php echo e(__('E-Mail Address')); ?></th>
                    <th><?php echo e(__('Country')); ?>,&nbsp<?php echo e(__('State')); ?>&nbsp-&nbsp<?php echo e(__('District')); ?></th>
                    <th><?php echo e(__('Status')); ?></th>
                    <th></th>
                </tr>
            </tfoot>
        </table>
    </div>
    
    
    <script type="text/javascript">
        $(document).ready(function() {
            function getLanguage() {
                var lang = $('html').attr('lang');
                if (lang == 'es') {
                    lng = "es-ES";
                } else if (lang == 'en') {
                    lng = "en-GB";
                }
                var result = null;
                var path = 'https://cdn.datatables.net/plug-ins/1.11.5/i18n/';
                result = path + lng + ".json";
                return result;
            }
            // Build Datatable
            $('#datatable').DataTable({
                language: {
                    "url": getLanguage()
                }
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.datatable', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('adminlte::page', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>