<?php $__env->startSection('content'); ?>
<?php if(session('error')): ?>
   <div class="alert alert-danger">
        <?php echo e(session('error')); ?>

   </div>
<?php endif; ?>
    <div class="card bg-black p-0 m-0 border-danger">
        <div class="row">
            
            <div class="card-body col-sm-7 my-auto">
                <div id="carouselExampleInterval" class="carousel slide" data-bs-ride="carousel">
                    <div class="carousel-inner">
                        <div class="carousel-item active" data-bs-interval="1000">
                            <a href="http://www.google.com">
                                <img src="<?php echo e(url('storage/img/shampoo.jpg')); ?>" class="d-block mx-auto" height="380vh">
                            </a>
                        </div>
                        <div class="carousel-item" data-bs-interval="1000">
                            <a href="http://www.google.com">
                                <img src="<?php echo e(url('storage/img/pata.jpg')); ?>" class="d-block mx-auto" height="380vh">
                            </a>
                        </div>
                        <div class="carousel-item" data-bs-interval="1000">
                            <a href="http://www.google.com">
                                <img src="<?php echo e(url('storage/img/dogcorrea.jpg')); ?>" class="d-block mx-auto" height="380vh">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="card-body col-sm-5 my-auto">
                <div class="card bg-black border border-danger">
                    <div class="card-header fw-bold fs-4">
                        <?php echo e(__('Log in')); ?>

                    </div>
                    <div class=" card-body text-white fw-bold">
                        <div class="row my-4">
                            
                            <label for="email" class="col-sm-5 col-form-label">
                                Nombre de la Empresa Ejemplo
                            </label>
                            <img src="<?php echo e(url('storage/img/shampoo.jpg')); ?>" class="img-fluid col-sm-7">
                        </div>
                        
                        <form method="POST" action="<?php echo e(route('login')); ?>">
                            <?php echo e(csrf_field()); ?>

                            <div class="row mb-3 form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                                <label for="name" class="col-sm-5 col-form-label"><?php echo e(__('Username')); ?></label>
                                
                                <div class="col-md-6">
                                    <input id="name" type="text" class="form-control text-danger" name="name"
                                        value="<?php echo e(old('name')); ?>" required autofocus>

                                    <?php if($errors->has('name')): ?>
                                        <span class="fs-6 text-danger">
                                            <?php echo e($errors->first('name')); ?>

                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            
                            <div class="row mb-3 form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                                <label for="password" class="col-sm-5 col-form-label"><?php echo e(__('Password')); ?></label>

                                <div class="col-md-6">
                                    <input id="password" type="password" class="form-control text-danger" name="password"
                                        required autofocus>

                                    <?php if($errors->has('password')): ?>
                                        <span class="fs-6 text-danger">
                                            <?php echo e($errors->first('password')); ?>

                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            
                            <div class="row mb-3 form-group<?php echo e($errors->has('captcha') ? ' has-error' : ''); ?>">
                                <label for="Captcha">
                                    <span class="captcha-img image-fluid">
                                        <?php echo captcha_img(); ?>

                                    </span>
                                </label>

                                <div class="mt-1 col-sm-7">
                                    <input id="captcha" type="text" class="form-control text-danger fs-3 fw-bold"
                                        name="captcha" required autofocus>

                                    <?php if($errors->has('captcha')): ?>
                                        <span class="fs-6 text-danger">
                                            <?php echo e($errors->first('captcha')); ?>

                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            
                            <div class="row mb-3 form-group">
                                <div class="mx-auto">
                                    <button type="submit" class="btn btn-primary">
                                        <?php echo e(__('Login')); ?>

                                    </button>
                                </div>
                            </div>
                            <div>
                                <a class="btn btn-link" href="<?php echo e(route('register')); ?>">
                                    <?php echo e(__('Create a new account')); ?>

                                </a>
                                <a class="btn btn-link" href="<?php echo e(route('password.request')); ?>">
                                    <?php echo e(__('Forgot Your Password?')); ?>

                                </a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>