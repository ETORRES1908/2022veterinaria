<?php $__env->startSection('content'); ?>
    <?php if(session('error')): ?>
        <div class="alert alert-danger">
            <?php echo e(session('error')); ?>

        </div>
    <?php endif; ?>
    <div class="card bg-black">
        <div class="row border border-danger">
            
            <div class="col-lg-7 m-auto">
                <div class="card-body">
                    <div id="carouselExampleInterval" class="carousel slide" data-bs-ride="carousel">
                        <div class="carousel-inner">
                            <?php $__currentLoopData = $banners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="carousel-item <?php if($banner->nombre = 'blogin1.jpeg'): ?> active <?php endif; ?>"
                                    data-bs-interval="1000">
                                    <a href="<?php echo e($banner->url); ?>">
                                        <img src="<?php echo e(asset($banner->ruta)); ?>" class="img-fluid mx-auto d-block">
                                    </a>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-lg-5 my-auto border border-danger">
                <div class="card bg-black">
                    <div class="card-header fw-bold fs-4">
                        <?php echo e(__('Log in')); ?>

                    </div>
                    <div class=" card-body text-white fw-bold">
                        <div class="row mb-3">
                            
                            <label for="ejemplo" class="col-sm-5 col-form-label">
                                Nombre de la Empresa Ejemplo
                            </label>
                            <img src="<?php echo e(url('storage/img/shampoo.jpg')); ?>" class="img-fluid col-sm-7">
                        </div>
                        
                        <form class="text-uppercase" method="POST" action="<?php echo e(route('login')); ?>">
                            <?php echo csrf_field(); ?>

                            <div class="row mb-3 form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                                <label for="name" class="col-sm-5 col-form-label"><?php echo e(__('Username')); ?></label>
                                
                                <div class="col-md-7">
                                    <input id="name" type="text" class="form-control text-danger" name="name"
                                        value="<?php echo e(old('name')); ?>" required autofocus
                                        onKeyPress="if(this.value.length==15) return false;">

                                    <?php if($errors->has('name')): ?>
                                        <span class="fs-6 text-danger">
                                            <?php echo e($errors->first('name')); ?>

                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            
                            <div class="row mb-3 form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                                <label for="password" class="col-sm-5 col-form-label"><?php echo e(__('Password')); ?></label>

                                <div class="col-md-7">
                                    <input id="password" type="password" class="form-control text-danger" name="password"
                                        required autofocus onKeyPress="if(this.value.length==8) return false;">

                                    <?php if($errors->has('password')): ?>
                                        <span class="fs-6 text-danger">
                                            <?php echo e($errors->first('password')); ?>

                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            
                            <div class="mb-3 form-group<?php echo e($errors->has('captcha') ? ' has-error' : ''); ?>">
                                <div class="row">
                                    <label for="Captcha" class="col-xl-12 col-form-label mx-auto text-end">
                                        <?php echo captcha_img(); ?>

                                    </label>
                                    <div class="col-sm-7 m-auto me-0">
                                        <input id="captcha" type="text" class="form-control text-danger fw-bold"
                                            name="captcha" required autofocus placeholder="<?php echo e(__('Result of blast')); ?>">

                                        <?php if($errors->has('captcha')): ?>
                                            <span class="fs-6 text-danger">
                                                <?php echo e($errors->first('captcha')); ?>

                                            </span>
                                        <?php endif; ?>
                                    </div>

                                </div>
                            </div>

                            
                            <div class="text-end mb-3">
                                <input type="submit" class="btn btn-primary mb-3 text-uppercase"
                                    value="<?php echo e(__('Enter')); ?>">
                                <a class="btn btn-success mb-3"
                                    href="<?php echo e(route('register')); ?>"><?php echo e(__('Create your account')); ?></a>
                                <a class="btn btn-secondary mb-3"
                                    href="<?php echo e(route('contact')); ?>"><?php echo e(__('Contact us')); ?></a>
                            </div>
                        </form>

                        
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>