<?php $__env->startSection('content'); ?>
    <?php if(session('error')): ?>
        <div class="alert alert-danger">
            <?php echo e(session('error')); ?>

        </div>
    <?php endif; ?>
    <div class="card bg-black">
        <div class="row border border-danger">
            
            <div class="col-md-7 my-auto">
                <div class="card-body">
                    <div class="carousel slide" data-bs-ride="carousel">
                        <div class="carousel-inner">
                            <?php $__currentLoopData = $banners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="carousel-item <?php if($banner->nombre = 'blogin1.jpeg'): ?> active <?php endif; ?>"
                                    data-bs-interval="1000">
                                    <a href="<?php echo e($banner->url); ?>">
                                        <img src="<?php echo e(asset($banner->ruta)); ?>" class="img-fluid mx-auto d-block">
                                    </a>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="col-md-5 my-auto border border-danger">
                <div class="card bg-black">
                    <div class="card-header fw-bold fs-4">
                        <?php echo e(__('Log in')); ?>

                    </div>
                    <div class=" card-body text-white fw-bold">
                        <div class="row mb-3">
                            
                            <label for="ejemplo" class="col-sm-5 col-form-label">
                                Nombre de la Empresa Ejemplo
                            </label>
                            <img src="<?php echo e(url('storage/img/shampoo.jpg')); ?>" class="img-fluid col-sm-7">
                        </div>
                        
                        <form method="POST" action="<?php echo e(route('login')); ?>">
                            <?php echo csrf_field(); ?>

                            <div class="row mb-3 form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                                <label for="name" class="col-sm-5 col-form-label"><?php echo e(__('Username')); ?></label>
                                
                                <div class="col-md-7">
                                    <input id="name" type="text" class="form-control text-danger" name="name"
                                        value="<?php echo e(old('name')); ?>" required autofocus onKeyPress="if(this.value.length==15) return false;">

                                    <?php if($errors->has('name')): ?>
                                        <span class="fs-6 text-danger">
                                            <?php echo e($errors->first('name')); ?>

                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            
                            <div class="row mb-3 form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                                <label for="password" class="col-sm-5 col-form-label"><?php echo e(__('Password')); ?></label>

                                <div class="col-md-7">
                                    <input id="password" type="password" class="form-control text-danger" name="password"
                                        required autofocus onKeyPress="if(this.value.length==8) return false;">

                                    <?php if($errors->has('password')): ?>
                                        <span class="fs-6 text-danger">
                                            <?php echo e($errors->first('password')); ?>

                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            
                            <div class="mb-3 form-group<?php echo e($errors->has('captcha') ? ' has-error' : ''); ?>">
                                <div class="row">
                                    <div class="col-12 col-lg-8 mb-3">
                                        <label for="Captcha">
                                            <span class="captcha-img image-fluid">
                                                <?php echo captcha_img(); ?>

                                            </span>
                                        </label>
                                    </div>
                                    <div class="col-8 col-sm-7 col-lg-4 justify-content-center mb-3">
                                        <input id="captcha" type="text" class="form-control text-danger fs-3 fw-bold"
                                            name="captcha" required autofocus>
                                        <?php if($errors->has('captcha')): ?>
                                            <span class="fs-6 text-danger">
                                                <?php echo e($errors->first('captcha')); ?>

                                            </span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>

                            
                            <div class="row mb-3 form-group">
                                <div class="mx-auto">
                                    <button type="submit" class="btn btn-primary">
                                        <?php echo e(__('Login')); ?>

                                    </button>
                                </div>
                            </div>
                            <div>
                                <a class="btn btn-link" href="<?php echo e(route('register')); ?>">
                                    <?php echo e(__('Create a new account')); ?>

                                </a>
                                <a class="btn btn-link" href="<?php echo e(route('password.request')); ?>">
                                    <?php echo e(__('Forgot Your Password?')); ?>

                                </a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>