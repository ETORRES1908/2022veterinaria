<?php $__env->startSection('title'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1 class="text-uppercase"><?php echo e($user->nombre); ?> <?php echo e($user->apellido); ?></h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row bg-black" style="padding:10vh">
        <div class="col-md-4">
            <div class="d-flex flex-column align-items-center text-center">
                <img width="200" src="<?php echo e(asset($user->foto)); ?>">
                <div><?php echo e($user->name); ?></div>
                <div><?php echo e($user->email); ?></div>
                <div>
                    <form method="POST" action="<?php echo e(route('Usuarios.update',$user->id)); ?>">
                        <?php echo e(csrf_field()); ?>

                        <button type="submit" class="btn btn-primary"><?php echo e(__('Change status')); ?></button>
                    </form>
                    <form method="POST" action="<?php echo e(url('Usuarios', $user->id)); ?>">
                        <?php echo e(csrf_field()); ?>

                        <label><?php echo e(__('Status')); ?></label>
                        <select class="form-control text-danger" name="active">
                            <option value="1" <?php if($user->active == '1'): ?> selected <?php endif; ?>>
                                <?php echo e(__('Actived')); ?>

                            </option>
                            <option value="0" <?php if($user->active == '0'): ?> selected <?php endif; ?>>
                                <?php echo e(__('Disabled')); ?>

                            </option>
                        </select>
                        <button type="submit" class="btn btn-primary"><?php echo e(__('Change status')); ?></button>
                    </form>
                </div>
            </div>
        </div>
        <div class="col-md-7">
            <div class="p-3 py-5">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <h4 class="text-right"></h4>
                </div>
                <div class="row mt-2">
                    <div class="col-md-6">
                        <label><?php echo e(__('Name')); ?></label>
                        <input type="text" class="form-control" value="<?php echo e($user->nombre); ?>" readonly>
                    </div>
                    <div class="col-md-6">
                        <label><?php echo e(__('Surname')); ?></label>
                        <input type="text" class="form-control" value="<?php echo e($user->apellido); ?>" readonly>
                    </div>
                </div>
                <div class="row mt-3">
                    <div class="col-md-6"><label><?php echo e(__('Disability')); ?></label>
                        <select class="form-control" disabled>
                            <option value="No" <?php if($user->discapacidad == 'No'): ?> selected <?php endif; ?>><?php echo e(__('No')); ?>

                            </option>
                            <option value="Visual" <?php if($user->discapacidad == 'Visual'): ?> selected <?php endif; ?>><?php echo e(__('Visual')); ?>

                            </option>
                            <option value="Fisica" <?php if($user->discapacidad == 'Fisica'): ?> selected <?php endif; ?>><?php echo e(__('Physical')); ?>

                            </option>
                            <option value="Auditiva" <?php if($user->discapacidad == 'Auditiva'): ?> selected <?php endif; ?>>
                                <?php echo e(__('Auditory')); ?></option>
                            <option value="Verbal" <?php if($user->discapacidad == 'Verbal'): ?> selected <?php endif; ?>><?php echo e(__('Verbal')); ?>

                            </option>
                            <option value="Mental" <?php if($user->discapacidad == 'Mental'): ?> selected <?php endif; ?>><?php echo e(__('Mental')); ?>

                            </option>
                        </select>
                    </div>
                    <div class="col-md-6"><label><?php echo e(__('N°DNI')); ?></label>
                        <input type="text" class="form-control" value="<?php echo e($user->dni); ?>" readonly>
                    </div>
                    <div class="col-md-6"><label><?php echo e(__('Galpon')); ?></label>
                        <input type="text" class="form-control" value="<?php echo e($user->galpon); ?>" readonly>
                    </div>
                    <div class="col-md-6"><label> <?php echo e(__('Trainer')); ?></label>
                        <input type="text" class="form-control" value="<?php echo e($user->prepa); ?>" readonly>
                    </div>
                    <div class="col-md-6"><label> <?php echo e(__('Company')); ?></label>
                        <input type="text" class="form-control" value="<?php echo e($user->company); ?>" readonly>
                    </div>
                    <div class="col-md-6"><label> <?php echo e(__('Phone')); ?></label>
                        <input type="text" class="form-control" value="<?php echo e($user->celular); ?>" readonly>
                    </div>
                    <div class="col-md-4"><label> <?php echo e(__('Country')); ?></label>
                        <input type="text" class="form-control" value="<?php echo e($user->country); ?>" readonly>
                    </div>
                    <div class="col-md-4"><label> <?php echo e(__('State')); ?></label>
                        <input type="text" class="form-control" value="<?php echo e($user->state); ?>" readonly>
                    </div>
                    <div class="col-md-4"><label> <?php echo e(__('District')); ?></label>
                        <input type="text" class="form-control" value="<?php echo e($user->district); ?>" readonly>
                    </div>
                    <div class="col-md-7"><label> <?php echo e(__('Direction')); ?></label>
                        <input type="text" class="form-control" value="<?php echo e($user->direction); ?>" readonly>
                    </div>
                    <div class="col-md-5"><label> <?php echo e(__('Job')); ?></label>
                        <input type="text" class="form-control" value="<?php echo e($user->job); ?>" readonly>
                    </div>
                </div>
            </div>
        </div>
    </div>

    
    <style>
        .form-control {
            color: rgb(210, 0, 0)
        }

    </style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>