<?php $__env->startSection('title'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1 class="text-uppercase"><?php echo e($user->nombre); ?> <?php echo e($user->apellido); ?></h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid bg-black">
        <?php if(session('mensaje')): ?>
            <div class="alert alert-success">
                <?php echo e(session('mensaje')); ?>

            </div>
        <?php endif; ?>
        <br>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('chngs')): ?>
            <a class="btn btn-primary" href="<?php echo e(route('usuarios.edit', $user->id)); ?>"><?php echo e(__('Edit')); ?></a>
        <?php endif; ?>
        <div class="row" style="padding:5vh 0 10vh 0;font-size: 1.3em">
            <div class="col-md-5">
                <div class="text-center">
                    <div class="mb">
                        <img width="100%" src="<?php echo e(asset($user->foto)); ?>"><br>
                    </div>
                    <div class="mb"><?php echo e($user->name); ?> (
                        <?php switch ($user->usert) {
                            case 'own':
                                echo __('Owner');
                                break;
                            case 'cls':
                                echo __('Coliseum');
                                break;
                            case 'jdg':
                                echo __('Judge');
                                break;
                            case 'cdk':
                                echo __('Control desk');
                                break;
                            case 'asst':
                                echo __('Assistant');
                                break;
                            case 'ppr':
                                echo __('Preparer');
                                break;
                            case 'amt':
                                echo __('Amateur');
                                break;

                            default:
                                # code...
                                break;
                        } ?>)</div>
                    <div class="mb"><?php echo e($user->email); ?></div><br>
                    <div class="form-group mb">
                        <label class="col-xs-4 col-md-7 control-label"><?php echo e(__('Status') . ' ' . __('Account')); ?>:</label>
                        <div class="col-xs-8 col-md-5">
                            <select class="form-control text-danger" name="status" disabled>
                                <option value="0" <?php if($user->status == '0'): ?> selected <?php endif; ?>>
                                    <?php echo e(__('Inactived')); ?>

                                </option>
                                <option value="1" <?php if($user->status == '1'): ?> selected <?php endif; ?>>
                                    <?php echo e(__('Actived')); ?>

                                </option>
                                <option value="2" <?php if($user->status == '2'): ?> selected <?php endif; ?>>
                                    <?php echo e(__('Suspended')); ?>

                                </option>
                                <option value="3" <?php if($user->status == '3'): ?> selected <?php endif; ?>>
                                    <?php echo e(__('Cancelled')); ?>

                                </option>
                            </select>
                        </div>
                    </div>
                </div>
            </div><br><br>
            <div class="col-md-6 text-uppercase">
                <div class="row">
                    <div class="col-xs-6 mb">
                        <label><?php echo e(__('Name')); ?></label>
                        <input type="text" class="form-control" value="<?php echo e($user->nombre); ?>" readonly>
                    </div>
                    <div class="col-xs-6 mb">
                        <label><?php echo e(__('Surname')); ?></label>
                        <input type="text" class="form-control" value="<?php echo e($user->apellido); ?>" readonly>
                    </div>
                    <div class="col-xs-6">
                        <label><?php echo e(__('Disability')); ?></label>
                        <select class="form-control mb" disabled style="-webkit-appearance: none;">
                            <option value="No" <?php if($user->discapacidad == 'No'): ?> selected <?php endif; ?>>
                                <?php echo e(__('No')); ?>

                            </option>
                            <option value="Visual" <?php if($user->discapacidad == 'Visual'): ?> selected <?php endif; ?>>
                                <?php echo e(__('Visual')); ?>

                            </option>
                            <option value="Fisica" <?php if($user->discapacidad == 'Fisica'): ?> selected <?php endif; ?>>
                                <?php echo e(__('Physical')); ?>

                            </option>
                            <option value="Auditiva" <?php if($user->discapacidad == 'Auditiva'): ?> selected <?php endif; ?>>
                                <?php echo e(__('Auditory')); ?></option>
                            <option value="Verbal" <?php if($user->discapacidad == 'Verbal'): ?> selected <?php endif; ?>>
                                <?php echo e(__('Verbal')); ?>

                            </option>
                            <option value="Mental" <?php if($user->discapacidad == 'Mental'): ?> selected <?php endif; ?>>
                                <?php echo e(__('Mental')); ?>

                            </option>
                        </select>
                    </div>
                    <div class="col-xs-6 mb"><label><?php echo e(__('DNI')); ?></label>
                        <input type="text" class="form-control" value="<?php echo e($user->dni); ?>" readonly>
                    </div>
                    <?php if(isset($user->fdpt)): ?>
                        <div class="col-xs-6 mb text-capitalize text-center center-block">
                            <a target="blank" class="col-form-label text-decoration-none"
                                href="<?php echo e(asset($user->fdpt)); ?>"><?php echo e(__('document') . ' ' . __('Disability')); ?>

                            </a>
                            <iframe id="viewer" src="<?php echo e(asset($user->fdpt)); ?>" frameborder="0" scrolling="no"
                                height="200" width="100%"></iframe>
                        </div>
                    <?php endif; ?>
                    <?php if(isset($user->sdpt)): ?>
                        <div class="col-xs-6 mb text-center">
                            <label><?php echo e(__('Photo') . ' ' . __('Disability')); ?></label>
                            <img class="img-responsive center-block" src="<?php echo e(asset($user->sdpt)); ?>" width="100%">
                        </div>
                    <?php endif; ?>
                    <div class="col-xs-6 mb"><label><?php echo e(__('Galpon')); ?></label>
                        <input type="text" class="form-control" value="<?php echo e($user->galpon); ?>" readonly>
                    </div>
                    <div class="col-xs-6 mb"><label> <?php echo e(__('Preparer')); ?></label>
                        <input type="text" class="form-control" value="<?php echo e($user->prepa); ?>" readonly>
                    </div>
                    <div class="col-xs-6 mb"><label> <?php echo e(__('Operator')); ?></label>
                        <input type="text" class="form-control" value="<?php echo e($user->company); ?>" readonly>
                    </div>
                    <div class="col-xs-6 mb"><label> <?php echo e(__('Phone')); ?></label>
                        <input type="text" class="form-control" value="<?php echo e($user->celular); ?>" readonly>
                    </div>
                    <div class="col-xs-4 mb"><label> <?php echo e(__('Country')); ?></label>
                        <input type="text" class="form-control" value="<?php echo e($user->country); ?>" readonly>
                    </div>
                    <div class="col-xs-8 col-lg-4 mb">
                        <label> <?php echo e(__('State')); ?></label>
                        <input type="text" class="form-control" value="<?php echo e($user->state); ?>" readonly>
                    </div>
                    <div class=" col-lg-4 mb">
                        <label> <?php echo e(__('District')); ?></label>
                        <input type="text" class="form-control" value="<?php echo e($user->district); ?>" readonly>
                    </div>
                    <div class="col-lg-7 mb"><label> <?php echo e(__('Direction')); ?></label>
                        <input type="text" class="form-control" value="<?php echo e($user->direction); ?>" readonly>
                    </div>
                    <div class="col-lg-5 mb"><label> <?php echo e(__('Profession or Trade')); ?></label>
                        <input type="text" class="form-control" value="<?php echo e($user->job); ?>" readonly>
                    </div>
                </div>
            </div>
        </div>
    </div>

    
    <style>
        .form-control {
            color: rgb(210, 0, 0);
        }

        .mb {
            margin-bottom: 1vh;
        }

    </style>
    <script src="<?php echo e(asset('js/jquery-3.6.0.js')); ?>"></script>
    
    <script>
        /* ALERT */
        setTimeout(function() {
            $('.alert').fadeOut('slow');
        }, 5000);
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>